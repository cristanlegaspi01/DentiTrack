<?php
// payment_module.php
// Payments / Receipts admin module adjusted to show only clinic income (no expenses).
// FIX: Updated database connection, implemented the custom receipt style with enhanced service details, and uses payments_api.php for detail fetching.
// NOTE: This code assumes payments_api.php has been updated to exclude 'payer_name' from the DB query.

define('DEBUG', true);
if (DEBUG) { ini_set('display_errors','1'); error_reporting(E_ALL); }

session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

// NOTE: Ensure your database connection file path is correct.
include '../config/db.php'; // expects $conn (mysqli)

function safe($v){ return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }
function refValues($arr){ foreach ($arr as $k => $v) $refs[$k] = &$arr[$k]; return $refs ?? []; }

// helper to check column existence
function column_exists($conn, $table, $column) {
    try {
        $dbNameResult = $conn->query("SELECT DATABASE()");
        if (!$dbNameResult) return false;
        $dbName = $dbNameResult->fetch_row()[0];
        $dbNameResult->free();
    } catch (Throwable $e) {
        return false;
    }
    
    $sql = "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE 
            TABLE_SCHEMA = ? AND 
            TABLE_NAME = ? AND 
            COLUMN_NAME = ? LIMIT 1";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param('sss', $dbName, $table, $column);
        $stmt->execute();
        $res = $stmt->get_result();
        $exists = ($res && $res->num_rows > 0);
        $stmt->close();
        return $exists;
    }
    return false; 
}

$error_messages = [];

// default filters & pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = isset($_GET['limit']) ? max(5, min(100, (int)$_GET['limit'])) : 15;
$offset = ($page - 1) * $limit;

$start_date = trim($_GET['start_date'] ?? '');
$end_date = trim($_GET['end_date'] ?? '');
$status = trim($_GET['status'] ?? '');
$q = trim($_GET['q'] ?? ''); // search term for invoice, payer_name, or email

// allowed statuses (adjust if your schema uses different values)
$allowed_statuses = ['paid','completed','pending','failed','refunded','cancelled'];

// --- COLUMN LIST ---
$requiredCols = [
    'payment_id', 'amount', 'total_amount', 'created_at'
];
$optionalCols = [
    'patient_id', 'service_id', 'service_name', 'supplies_used', 'payer_name', 'email', 
    'payment_method', 'status', 'details', 'invoice_no', 'currency', 'payment_date', 
    'discount_type', 'discount_amount'
];
// -------------------

$availableCols = [];

// Detect columns.
foreach ($requiredCols as $c) {
    if (column_exists($conn, 'payments', $c)) {
        $availableCols[] = $c;
    } else {
        $error_messages[] = "Missing critical payments column: '{$c}'. Listing transactions may fail.";
    }
}
foreach ($optionalCols as $c) {
    if (column_exists($conn, 'payments', $c)) $availableCols[] = $c;
}

// Build SELECT list, mapping detected names back to expected display names
$selectList = [];
foreach ($availableCols as $c) {
    switch ($c) {
        case 'payment_id':
            $selectList[] = "`payment_id` AS `id`";
            break;
        case 'service_id':
            // Use service_id from DB, map to serviceid for consistency with old display code
            $selectList[] = "`service_id` AS `serviceid`";
            break;
        case 'service_name':
             // Map service_name to servicename
            $selectList[] = "`service_name` AS `servicename`";
            break;
        case 'supplies_used':
            // Map supplies_used to supply_used
            $selectList[] = "`supplies_used` AS `supply_used`";
            break;
        default:
            $selectList[] = "`{$c}`";
            break;
    }
}
$selectSQL = $selectList ? implode(', ', $selectList) : '*';

// Determine which date column to use for filtering
$dateCol = null;
if (in_array('created_at', $availableCols, true)) {
    $dateCol = 'created_at';
} elseif (in_array('payment_date', $availableCols, true)) {
    $dateCol = 'payment_date';
}

// Build dynamic WHERE with prepared statement
$where_clauses = [];
$params = [];
$types = '';

if ($dateCol) {
    if ($start_date !== '') {
        $where_clauses[] = "DATE($dateCol) >= ?";
        $types .= 's'; $params[] = $start_date;
    }
    if ($end_date !== '') {
        $where_clauses[] = "DATE($dateCol) <= ?";
        $types .= 's'; $params[] = $end_date;
    }
} else {
    if ($start_date || $end_date) $error_messages[] = "Date filters ignored: No suitable date column present.";
}

if ($status !== '' && in_array(strtolower($status), $allowed_statuses, true) && in_array('status', $availableCols, true)) {
    $where_clauses[] = "LOWER(status) = ?";
    $types .= 's'; $params[] = strtolower($status);
} elseif ($status !== '' && !in_array('status', $availableCols, true)) {
    $error_messages[] = "Status filter ignored: 'status' column not present.";
}

if ($q !== '') {
    $qClauses = [];
    if (in_array('invoice_no', $availableCols, true)) { $qClauses[] = "invoice_no LIKE ?"; $types .= 's'; $params[] = "%$q%"; }
    if (in_array('payer_name', $availableCols, true)) { $qClauses[] = "payer_name LIKE ?"; $types .= 's'; $params[] = "%$q%"; }
    if (in_array('email', $availableCols, true)) { $qClauses[] = "email LIKE ?"; $types .= 's'; $params[] = "%$q%"; }
    if (in_array('patient_id', $availableCols, true)) { 
        if (is_numeric($q)) {
             $qClauses[] = "patient_id = ?"; $types .= 'i'; $params[] = (int)$q;
        }
    }
    
    if ($qClauses) $where_clauses[] = '(' . implode(' OR ', $qClauses) . ')';
    else $error_messages[] = "Search ignored: no invoice/payer/email/patient_id columns present.";
}

$where = '';
if (count($where_clauses)) $where = 'WHERE ' . implode(' AND ', $where_clauses);

// total count for pagination
$total = 0;
$total_sql = "SELECT COUNT(*) AS cnt FROM `payments` $where";
if ($stmt = $conn->prepare($total_sql)) {
    if ($types !== '') {
        $bind_arr = array_merge([$types], $params);
        call_user_func_array([$stmt, 'bind_param'], refValues($bind_arr));
    }
    if (!$stmt->execute()) {
        $error_messages[] = 'Failed to execute count query: ' . $stmt->error;
    } else {
        $res = $stmt->get_result();
        if ($res) {
            $row = $res->fetch_assoc();
            $total = (int)($row['cnt'] ?? 0);
        }
    }
    $stmt->close();
} else {
    $error_messages[] = 'Failed to prepare count query: ' . $conn->error;
}

// fetch transactions using the dynamic select list
$transactions = [];
$orderBy = $dateCol ? "$dateCol DESC" : 'id DESC';
$list_sql = "SELECT $selectSQL FROM `payments` $where ORDER BY $orderBy LIMIT ? OFFSET ?";

try {
    if ($stmt = $conn->prepare($list_sql)) {
        // bind dynamic params + limit + offset
        $bind_params = [];
        $bind_types = $types . 'ii';
        $bind_params[] = $bind_types;
        foreach ($params as $p) $bind_params[] = $p;
        $bind_params[] = $limit;
        $bind_params[] = $offset;
        call_user_func_array([$stmt, 'bind_param'], refValues($bind_params));

        if (!$stmt->execute()) {
            $error_messages[] = 'Failed to execute list query: ' . $stmt->error;
        } else {
            $res = $stmt->get_result();
            if ($res) {
                while ($r = $res->fetch_assoc()) $transactions[] = $r;
            }
        }
        $stmt->close();
    } else {
        $error_messages[] = 'Failed to prepare list query: ' . $conn->error . ' SQL: ' . $list_sql;
    }
} catch (Throwable $e) {
    $error_messages[] = 'Server error while fetching transactions: ' . $e->getMessage();
}

// pagination helpers
$total_pages = $limit > 0 ? ceil($total / $limit) : 1;

// build query strings for links
function build_qs($overrides = []) {
    $base = $_GET;
    // ensure page is not kept if cleared
    if (isset($overrides['page']) && $overrides['page'] === null) unset($base['page']);
    // Remove the 'action' parameter (used for form submission context)
    unset($base['action']); 
    foreach ($overrides as $k=>$v) $base[$k] = $v;
    return http_build_query($base);
}

// financial summary using the detected columns (income only)
$total_revenue = 0.00;
try {
    // Note: Always use total_amount if available, otherwise amount.
    $revenueCol = in_array('total_amount', $availableCols, true) ? 'total_amount' : (in_array('amount', $availableCols, true) ? 'amount' : null);
    
    if ($revenueCol) {
        $Res = $conn->query("SELECT IFNULL(SUM($revenueCol),0) AS total_revenue FROM payments");
        if ($Res) { $row = $Res->fetch_assoc(); $total_revenue = (float)($row['total_revenue'] ?? 0); $Res->free(); }
    } else {
        // Error message already set above if required cols are missing
    }
} catch (Throwable $e) {
    $error_messages[] = 'Revenue query failed: ' . $e->getMessage();
}

$admin_username = $_SESSION['username'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Payments — DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous">
<style>
/* Styling preserved from revised design */
:root{--accent:#0077b6;--accent-2:#0b69ff;--muted:#6b7280;--bg:#eef6ff;--card:#fff;--radius:12px;--shadow:0 8px 24px rgba(2,6,23,0.06)}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Inter,Segoe UI,Arial;background:var(--bg);color:#012a4a;display:flex;min-height:100vh}
.sidebar{width:220px;background:linear-gradient(to bottom,#3399ff,#0066cc);padding:20px 0;color:white;display:flex;flex-direction:column}
.sidebar h2{text-align:center;margin-bottom:30px;font-size:20px;font-weight:700;text-shadow:1px 1px 2px rgba(0,0,0,0.2)}
.sidebar a{display:block;padding:12px 18px;margin:8px 14px;color:#cce0ff;text-decoration:none;border-left:4px solid transparent;font-weight:600;border-radius:8px;transition:all .2s}
.sidebar a:hover,.sidebar a.active{background:rgba(255,255,255,0.08);color:#fff;border-left:4px solid #ffcc00}
.container{flex:1;padding:28px 36px;overflow:auto}
.header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
.header-left h1{margin:0;font-size:22px;color:#004080;display:flex;align-items:center;gap:10px}
.summary-row{display:flex;gap:16px;margin-bottom:18px;flex-wrap:wrap}
.summary-card{background:var(--card);padding:16px;border-radius:var(--radius);box-shadow:var(--shadow);flex:1;min-width:180px}
.summary-card h3{margin:0;font-size:14px;color:var(--muted)}
.summary-card .value{font-size:20px;font-weight:800;color:var(--accent)}
.filters-card{background:var(--card);padding:12px;border-radius:var(--radius);box-shadow:var(--shadow);display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:18px}
.filters-card input[type="date"], .filters-card select, .filters-card input[type="search"]{padding:8px;border-radius:8px;border:1px solid #e6f3ff;background:#f8fcff}
.filters-card .btn{background:var(--accent);color:#fff;padding:8px 12px;border-radius:8px;border:0;cursor:pointer}
.table-card{background:var(--card);padding:14px;border-radius:var(--radius);box-shadow:var(--shadow)}
.table{width:100%;border-collapse:collapse}
.table th, .table td{padding:12px;border-bottom:1px solid #f1f6fb;font-size:14px;text-align:left}
.table th{color:var(--muted);font-weight:700}
.badge{display:inline-block;padding:6px 10px;border-radius:999px;font-weight:700;font-size:13px}
.badge.paid{background:rgba(34,197,94,0.12);color:#16a34a}
.badge.pending{background:rgba(250,204,21,0.12);color:#b45309}
.badge.failed{background:rgba(239,68,68,0.08);color:#dc2626}
.actions{display:flex;gap:8px;justify-content:flex-end}
.pagination{display:flex;gap:8px;align-items:center;margin-top:12px}
.page-link{padding:8px 10px;background:#fff;border-radius:8px;border:1px solid #eef6ff;text-decoration:none;color:#012a4a}
.receipt-modal{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:760px;max-width:96%;background:var(--card);border-radius:12px;box-shadow:0 30px 80px rgba(2,6,23,0.2);z-index:999;display:none;padding:18px}
.modal-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.modal-body{max-height:80vh;overflow:auto}
.close-btn{background:#f3f4f6;border:0;padding:6px 10px;border-radius:8px;cursor:pointer}
.error-banner{background:#fff6f6;border:1px solid #ffd1d1;padding:12px;border-radius:8px;margin-bottom:12px;color:#8a1f11}
.small-muted{color:var(--muted);font-size:13px}
@media (max-width: 980px){.summary-row{flex-direction:column}.filters-card{flex-direction:column;align-items:stretch}.header{flex-direction:column;align-items:flex-start;gap:8px}}
</style>
</head>
<body>
<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="admin_dashboard.php" ><i class="fas fa-home"></i> Dashboard</a>
    <a href="manage_accounts.php"><i class="fas fa-users-cog"></i> Manage Accounts</a>
    <a href="clinic_services_admin.php"><i class="fas fa-tools"></i> Clinic Services</a>
    <a href="generate_reports.php"><i class="fas fa-chart-line"></i> Generate Reports</a>
    <a href="payment_module.php" class="active"><i class="fas fa-money-check-dollar"></i> Payment Module</a>
    <a href="clinic_schedule_admin.php"><i class="fas fa-calendar-check"></i> Clinic Schedule</a>
    <a href="admin_settings.php"><i class="fas fa-gear"></i> System Settings</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<div class="container" role="main">
    <div class="header">
        <div class="header-left">
            <h1><i class="fas fa-money-check-dollar" style="color:var(--accent)"></i> Payments & Receipts</h1>
            <div class="small-muted">Manage transactions and clinic income</div>
        </div>
        <div class="header-right">
            <div class="small-muted">Welcome, <strong><?= safe($admin_username) ?></strong></div>
        </div>
    </div>

    <?php if (!empty($error_messages)): ?>
        <div class="error-banner" role="status" aria-live="polite">
            <strong>Warning:</strong>
            <ul style="margin:8px 0 0 18px;">
                <?php foreach ($error_messages as $em): ?><li><?= safe($em) ?></li><?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="summary-row" role="region" aria-label="Financial summary">
        <div class="summary-card" aria-hidden="false">
            <h3>Clinic Income</h3>
            <div class="value"><?= '$' . number_format($total_revenue, 2) ?></div>
            <div class="small-muted">Total income from payments</div>
        </div>
    </div>

    <div class="filters-card" role="search" aria-label="Filters">
        <form id="filtersForm" method="get" style="display:flex;gap:10px;align-items:center;width:100%" action="payment_module.php">
            <input type="date" name="start_date" value="<?= safe($start_date) ?>" aria-label="Start date">
            <input type="date" name="end_date" value="<?= safe($end_date) ?>" aria-label="End date">
            <select name="status" aria-label="Payment status">
                <option value="">All statuses</option>
                <?php foreach ($allowed_statuses as $s): ?>
                    <option value="<?= safe($s) ?>" <?= strtolower($status) === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                <?php endforeach; ?>
            </select>
            <input type="search" name="q" placeholder="Search invoice, name, email..." value="<?= safe($q) ?>" aria-label="Search">
            <button type="submit" class="btn">Apply Filter</button>

            <div style="margin-left:auto;display:flex;gap:8px">
                <!--<button type="submit" name="action" value="export_excel" class="btn" style="background:green" formtarget="_blank" formaction="export_excel.php">
                    <i class="fas fa-file-excel"></i>&nbsp;Export Excel
                </button>-->
            </div>
        </form>
    </div>

    <div class="table-card" role="table" aria-label="Payments table">
        <table class="table" role="presentation">
            <thead>
                <tr>
                    <th>Invoice / ID / Payer</th>
                    <th>Service</th>
                    <th>Supply used</th>
                    <th style="min-width:120px">Amount</th>
                    <th>Discount</th>
                    <th>Total</th>
                    <th>Date</th>
                    <th style="text-align:right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($transactions) === 0): ?>
                    <tr><td colspan="8" class="small-muted">No transactions found.</td></tr>
                <?php else: ?>
                    <?php foreach ($transactions as $t):
                        $statusKey = isset($t['status']) ? strtolower($t['status']) : 'unknown';
                        $badgeClass = 'badge';
                        if ($statusKey === 'paid' || $statusKey === 'completed') $badgeClass .= ' paid';
                        elseif ($statusKey === 'pending') $badgeClass .= ' pending';
                        elseif ($statusKey === 'failed' || $statusKey === 'refunded' || $statusKey === 'cancelled') $badgeClass .= ' failed';
                        
                        // Use detected date column for display
                        $displayDate = $t['created_at'] ?? $t['payment_date'] ?? ''; 
                        ?>
                        <tr>
                            <td>
                                <strong><?= safe($t['invoice_no'] ?? $t['id']) ?></strong><br>
                                <div class="small-muted">Payer: <?= safe($t['payer_name'] ?? '—') ?></div>
                            </td>
                            <td>
                                <div><strong><?= safe($t['servicename'] ?? '—') ?></strong></div>
                                <div class="small-muted">Service ID: <?= safe($t['serviceid'] ?? '—') ?></div>
                            </td>
                            <td><?= safe($t['supply_used'] ?? '—') ?></td>
                            <td><strong style="color:var(--accent)"><?= '$' . number_format((float)($t['amount'] ?? 0), 2) ?> <?= safe($t['currency'] ?? '') ?></strong></td>
                            <td>
                                <?= isset($t['discount_type']) ? safe($t['discount_type']) : '—' ?>
                                <?php if (isset($t['discount_amount'])): ?>
                                    <div class="small-muted"><?= '$' . number_format((float)$t['discount_amount'], 2) ?></div>
                                <?php endif; ?>
                            </td>
                            <td><strong><?= '$' . number_format((float)($t['total_amount'] ?? ($t['amount'] ?? 0)), 2) ?></strong></td>
                            <td><?= safe($displayDate) ?></td>
                            <td class="actions" style="text-align:right">
                                <button class="btn view-receipt" data-id="<?= (int)$t['id'] ?>" aria-label="View receipt <?= safe($t['invoice_no'] ?? $t['id']) ?>">View</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px">
            <div class="small-muted">Showing <?= ($total === 0) ? 0 : ($offset + 1) ?> - <?= min($total, $offset + count($transactions)) ?> of <?= $total ?> transactions</div>
            <div class="pagination" role="navigation" aria-label="Pagination">
                <?php if ($page > 1): ?>
                    <a class="page-link" href="?<?= build_qs(['page' => $page-1]) ?>">&laquo; Prev</a>
                <?php endif; ?>
                <?php if ($page < $total_pages): ?>
                    <a class="page-link" href="?<?= build_qs(['page' => $page+1]) ?>">Next &raquo;</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div id="receiptModal" class="receipt-modal" role="dialog" aria-modal="true" aria-hidden="true">
    <div class="modal-header">
        <div><strong>Receipt Details</strong></div>
        <div><button id="closeModal" class="close-btn" aria-label="Close receipt">Close</button></div>
    </div>
    <div id="receiptBody" class="modal-body">
        <div class="small-muted">Loading...</div>
    </div>
</div>

<script>
(function(){
    // Helper function for XSS protection in JavaScript
    function safe(v) {
        if (v === null || v === undefined) return '';
        // Basic HTML escaping
        return String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
    }
    
    // Function to format currency (Using PHP currency)
    function formatPeso(amount) {
        // Formats as ₱25,000.00
        return '₱' + parseFloat(amount).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    }

    // Function to parse the complex JSON string in supplies_used
    function parseSupplies(jsonString) {
        try {
            if (typeof jsonString === 'string') {
                 // Check for the specific double array structure: [[{"id":...,"name":...,"qty":...}]]
                 if (jsonString.startsWith('[[') && jsonString.endsWith(']]')) {
                    const innerJson = jsonString.slice(1, -1);
                    const parsed = JSON.parse(innerJson);
                    return `Used: ${parsed.name} (Qty: ${parsed.qty})`;
                 }
                 
                 // Check for a standard array structure: [{"id":...,"name":...,"qty":...}]
                 if (jsonString.startsWith('[') && jsonString.endsWith(']')) {
                    const parsedArray = JSON.parse(jsonString);
                    if (Array.isArray(parsedArray) && parsedArray.length > 0) {
                        return parsedArray.map(item => `${item.name} (Qty: ${item.qty})`).join(', ');
                    }
                 }
            }
        } catch (e) {
            // Parsing failed, return raw string or default
        }
        return safe(jsonString) || 'None';
    }

    async function loadReceipt(id){
        const modal = document.getElementById('receiptModal');
        const body = document.getElementById('receiptBody');
        modal.style.display = 'block';
        modal.setAttribute('aria-hidden', 'false');
        body.innerHTML = '<div class="small-muted" style="text-align:center;">Loading receipt...</div>';
        
        try {
            const res = await fetch('payments_api.php', {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ action: 'detail', id: id })
            });
            const json = await res.json();
            
            if (!res.ok || json.error) {
                body.innerHTML = '<div class="error-banner" style="margin:0;">Error: ' + safe(json.error || 'Unable to fetch receipt details.') + '</div>';
                return;
            }

            const p = json.data || {};
            
            // --- Receipt Data Mapping from API response ---
            // Using p.first_name, which the API populates with the patient's full name.
            const patientName = safe(p.first_name || 'N/A'); 
            
            const serviceName = safe(p.service_name || 'N/A'); 
            const createdAt = safe(p.payment_date || p.created_at || 'N/A');
            const invoiceNo = safe(p.invoice_no || p.payment_id);
            const originalAmount = parseFloat(p.amount || 0); 
            const totalAmountDue = parseFloat(p.total_amount || p.amount || 0); 
            const discountAmount = parseFloat(p.discount_amount || 0);
            const discountType = safe(p.discount_type || 'None');
            const suppliesUsed = parseSupplies(p.supplies_used);
            const cashReceived = parseFloat(p.cash_received || totalAmountDue || 0); 
            const paymentMethod = safe(p.payment_method || 'N/A');
            const paymentStatus = safe(p.status || 'N/A');
            const paymentOption = safe(p.payment_option || 'Full Payment');

            let html = `
                <style>
                    /* Styles for the receipt modal */
                    .receipt-content .row { 
                        display: flex; 
                        justify-content: space-between; 
                        margin: 4px 0; 
                        border-bottom: 1px dotted #ccc; 
                        padding-bottom: 4px;
                        font-size: 14px;
                    }
                    .receipt-content .row strong { font-weight: 600; }
                    .receipt-content table{
                        width:100%;
                        border-collapse:collapse;
                        margin-top: 15px;
                        margin-bottom: 15px;
                    }
                    .receipt-content table th, .receipt-content table td{
                        padding: 10px 8px;
                        text-align: left;
                        font-size: 14px;
                        border-bottom: 1px solid #eee;
                    }
                    .receipt-content table th{
                        background: #f0f8ff;
                        font-weight: 700;
                        color: #0077b6;
                    }
                    .receipt-content table td:last-child, .receipt-content table th:last-child {
                        text-align: right; 
                    }
                    .summary-label {
                        text-align: right;
                        padding-right: 15px;
                        font-size: 14px;
                    }
                    .summary-value {
                        text-align: right;
                        font-weight: bold;
                        font-size: 14px;
                    }
                    .total-bill-line, .cash-received-line {
                        font-size: 1.1rem;
                        font-weight: 800;
                        display: flex;
                        justify-content: space-between;
                        padding: 10px 0;
                        margin-top: 5px;
                    }
                    .total-bill-line {
                        border-top: 2px solid #00c853; 
                        color: #004080;
                    }
                    .cash-received-line {
                        color: #008000; 
                        border-top: 1px solid #008000;
                    }
                    .button-row {
                        display: flex;
                        justify-content: center;
                        gap: 15px;
                        margin-top: 25px;
                    }
                    .btn-print {
                        background: #007bff;
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 8px;
                        cursor: pointer;
                    }
                    .btn-proceed {
                        background: #28a745;
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 8px;
                        cursor: pointer;
                        text-decoration: none;
                        display: inline-block;
                    }
                </style>
                <div class="receipt-content">
                    <h2 style="text-align:center;margin-bottom:25px;color:#004080;">
                        <i class="fas fa-receipt"></i> ${safe(p.receipt_title || 'PAYMENT RECEIPT')}
                    </h2>

                    <div class="row"><strong>Receipt ID:</strong> <span style="font-weight: bold;">${invoiceNo}</span></div>
                    <div class="row"><strong>Patient Name:</strong> <span>${patientName}</span></div>
                    <div class="row"><strong>Payment Date:</strong> <span>${createdAt}</span></div>
                    <div class="row"><strong>Payment Method:</strong> <span>${paymentMethod}</span></div>
                    <div class="row"><strong>Payment Option:</strong> <span>${paymentOption}</span></div>
                    <div class="row" style="border-bottom: none; padding-bottom: 0;"><strong>Payment Status:</strong> <span>${paymentStatus}</span></div>

                    
                    <table>
                        <thead>
                            <tr>
                                <th>Service/Item</th>
                                <th>Unit Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>${serviceName}</td>
                                <td>${formatPeso(originalAmount)}</td>
                                <td>1</td>
                                <td>${formatPeso(originalAmount)}</td>
                            </tr>
                            <tr>
                                <td colspan="4" style="font-size: 12px; color: #6b7280; padding-top: 5px; border-bottom: none;">
                                    * Supplies Used: ${suppliesUsed}
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <div style="text-align: left; margin-top: -10px; margin-bottom: 10px; font-weight: bold; color: #6b7280; font-size: 14px;">
                        --- FINANCIAL SUMMARY ---
                    </div>
                    
                    <div class="row" style="border-bottom: 1px dotted #ccc;">
                        <span class="summary-label">Total Service Cost:</span>
                        <span class="summary-value">${formatPeso(originalAmount)}</span>
                    </div>

                    <div class="row" style="border-bottom: 1px dotted #ccc;">
                        <span class="summary-label">Discount (${discountType}):</span>
                        <span class="summary-value">-${formatPeso(discountAmount)}</span>
                    </div>

                    <div class="total-bill-line">
                        <span>TOTAL AMOUNT DUE:</span>
                        <span>${formatPeso(totalAmountDue)}</span>
                    </div>

                    <div class="cash-received-line">
                        <span>CASH RECEIVED THIS TRANSACTION:</span>
                        <span>${formatPeso(cashReceived)}</span>
                    </div>

                    <div class="button-row no-print">
                        <button id="printReceipt" class="btn-print">
                            <i class="fas fa-print"></i> Print Receipt
                        </button>
                        <a href="#" class="btn-proceed" role="button">
                            <i class="fas fa-arrow-right"></i> Proceed to Payments
                        </a>
                    </div>
                </div>`;
            
            body.innerHTML = html;

            // Print functionality
            document.getElementById('printReceipt').addEventListener('click', function(){
                const printWindow = window.open('', '_blank');
                const printContent = document.querySelector('.receipt-content').innerHTML;
                
                printWindow.document.write(`
                    <html>
                    <head>
                        <title>Receipt ${invoiceNo}</title>
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
                        <style>
                            /* Minimal print styles matching the visual structure */
                            body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;color:#003366;padding:20px;margin:0 auto;max-width:600px;}
                            .receipt-content h2{text-align:center;margin-bottom:20px;color:#004080;}
                            .receipt-content .row{display:flex;justify-content:space-between;margin:4px 0;border-bottom:1px dotted #ccc;padding-bottom:4px;font-size:14px;}
                            .receipt-content .row strong:first-child{font-weight:600;}
                            .receipt-content table{width:100%;border-collapse:collapse;margin-top:15px;margin-bottom:15px;font-size:12px;}
                            .receipt-content table th, .receipt-content table td{padding:8px;text-align:left;border-bottom: 1px solid #eee;}
                            .receipt-content table th{background:#eaf3ff;}
                            .receipt-content table td:last-child, .receipt-content table th:last-child { text-align: right; }
                            .summary-label, .summary-value { font-size: 14px; }
                            .summary-label { text-align: right; padding-right: 15px; }
                            .total-bill-line, .cash-received-line { font-size: 1.1rem !important; font-weight: bold !important; display: flex; justify-content: space-between; padding: 10px 0; margin-top: 5px; }
                            .total-bill-line { border-top: 2px solid #00c853 !important; color: #004080 !important; }
                            .cash-received-line { color: #008000 !important; border-top: 1px solid #008000 !important; }
                            @media print { .no-print { display: none; } }
                        </style>
                    </head>
                    <body>${printContent}</body>
                    </html>
                `);
                printWindow.document.close();
                printWindow.print();
                printWindow.close();
            });

            document.getElementById('closeModal').addEventListener('click', function() {
                document.getElementById('receiptModal').style.display = 'none';
                document.getElementById('receiptModal').setAttribute('aria-hidden', 'true');
            });
            window.addEventListener('click', function(event) {
                if (event.target === document.getElementById('receiptModal')) {
                    document.getElementById('receiptModal').style.display = 'none';
                    document.getElementById('receiptModal').setAttribute('aria-hidden', 'true');
                }
            });
            
        } catch (err) {
            body.innerHTML = '<div class="error-banner" style="margin:0;">Network or server error while fetching receipt.</div>';
            console.error(err);
        }
    }

    document.querySelectorAll('.view-receipt').forEach(btn => {
        btn.addEventListener('click', function(){
            const id = this.getAttribute('data-id');
            if (id) loadReceipt(id);
        });
    });

    document.getElementById('closeModal').addEventListener('click', function() {
        document.getElementById('receiptModal').style.display = 'none';
        document.getElementById('receiptModal').setAttribute('aria-hidden', 'true');
    });

    window.addEventListener('click', function(event) {
        if (event.target === document.getElementById('receiptModal')) {
            document.getElementById('receiptModal').style.display = 'none';
            document.getElementById('receiptModal').setAttribute('aria-hidden', 'true');
        }
    });
})();
</script>
</body>
</html>