<?php
session_start();
// Security check: Redirect non-admins
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

// Configuration includes (assuming paths are correct)
include '../config/db.php';
// NOTE: Make sure 'settings_loader.php' contains the getSetting() function
include '../config/settings_loader.php'; 

$admin_username = $_SESSION['username'];
$message = '';
$message_type = 'success'; // Default type for general success

// Function to safely save a setting using the provided MySQLi connection
function saveSetting($conn, $key, $value) {
    // This function encapsulates the logic for saving/updating a key-value pair in system_settings
    $stmt = $conn->prepare("
        INSERT INTO system_settings (setting_key, setting_value)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
    ");
    $clean_value = trim($value); 
    
    // Bind parameters, execute, and close
    $stmt->bind_param("ss", $key, $clean_value);
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}

// Function to generate time slots for the dropdown
function generate_time_slots() {
    $slots = [];
    $start = strtotime('8:00 AM');
    $end = strtotime('9:00 PM');
    $interval = 30 * 60; // 30 minutes in seconds

    // Add 'CLOSED' option
    $slots['CLOSED'] = 'CLOSED';

    // Generate 30-minute intervals
    for ($time = $start; $time <= $end; $time += $interval) {
        $formatted_time = date('h:i A', $time);
        $slots[$formatted_time] = $formatted_time;
    }
    return $slots;
}
$time_slots = generate_time_slots(); // Generate the slots once

// Handle form submission and save settings
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $upload_dir = '../images/'; // Target directory is 'images' relative to the admin folder's parent

    // --- 1. Handle File Upload (About Us Image) ---
    if (isset($_FILES['about_us_image']) && $_FILES['about_us_image']['error'] === UPLOAD_ERR_OK) {
        $file_tmp_path = $_FILES['about_us_image']['tmp_name'];
        $file_name = $_FILES['about_us_image']['name'];
        $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $new_file_name = 'about_us_image_' . uniqid() . '.' . $file_extension;
        $dest_path = $upload_dir . $new_file_name;
        $image_path_to_save = 'images/' . $new_file_name; // Path relative to project root (used in index.php)

        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($file_extension, $allowed_extensions)) {
            $message = "❌ Error: Only JPG, JPEG, PNG, and GIF files are allowed for the About Us image.";
            $message_type = 'danger';
            goto end_of_post; 
        }
        
        // Ensure upload directory exists
        if (!is_dir($upload_dir)) {
            if (!mkdir($upload_dir, 0777, true)) {
                $message = "❌ Error: Upload directory '../images/' does not exist and could not be created. Check server permissions.";
                $message_type = 'danger';
                goto end_of_post;
            }
        }

        if (move_uploaded_file($file_tmp_path, $dest_path)) {
            // Save the path to the database using the key 'about_us_image'
            if(saveSetting($conn, 'about_us_image', $image_path_to_save)) {
                $message = "✅ About Us Image uploaded and path saved successfully. ";
            } else {
                $message = "⚠️ Warning: Image uploaded, but path failed to save in database. ";
                $message_type = 'warning';
            }
        } else {
            $message = "❌ Error uploading About Us Image. Check folder permissions (../images/). ";
            $message_type = 'danger';
        }
    }

    // --- 2. Handle Regular Settings from $_POST ---
    $all_post_saved = true;
    
    // String to build the clinic hours HTML
    $clinic_hours_html = '<ul style="list-style: none; padding: 0;">';
    $hours_data = []; // Temp storage for hour settings (to generate HTML later)

    foreach ($_POST as $key => $value) {
        // Exclude the submit button
        if ($key === 'save_settings') continue; 
        
        // Save individual settings
        if (!saveSetting($conn, $key, $value)) {
             $all_post_saved = false;
        }

        // Collect clinic hours for generating the HTML setting
        if (strpos($key, 'clinic_hours_') === 0) {
            $day = substr($key, strlen('clinic_hours_'));
            $hours_data[$day] = trim($value);
        }
    }
    
    // --- 3. Generate and Save Clinic Hours HTML (Used by index.php) ---
    if (!empty($hours_data)) {
        // Ensure days are in order: Monday to Sunday
        $ordered_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        
        foreach ($ordered_days as $day) {
            $hour_entry = $hours_data[$day] ?? 'N/A';
            $clinic_hours_html .= "<li><strong>" . ucfirst($day) . ":</strong> " . htmlspecialchars($hour_entry) . "</li>";
        }
        $clinic_hours_html .= '</ul>';

        // Save the generated HTML
        if (!saveSetting($conn, 'clinic_hours_html', $clinic_hours_html)) {
             $all_post_saved = false;
        }
    }
    
    // Finalize message based on outcomes
    if(empty($message)) {
         if ($all_post_saved) {
             $message = "✅ All settings updated successfully!";
         } else {
             $message = "⚠️ Warning: Some settings failed to save in the database. Please check the log.";
             $message_type = 'warning';
         }
    } else {
        // If image message exists, append a general success/warning for other settings
        if ($all_post_saved) {
             $message .= " All other settings updated successfully!";
        } else {
             $message .= " ⚠️ Warning: Other settings update failed or partially completed.";
             // Elevate message type if there was a mixed result
             if($message_type === 'success') $message_type = 'warning';
        }
    }
    
    // Cleanly exit the POST block after all checks
    end_of_post:
}

// Array of common timezones for the select dropdown (Unchanged)
$timezones = [
    'America/New_York' => 'Eastern Time (US)',
    'America/Chicago' => 'Central Time (US)',
    'America/Denver' => 'Mountain Time (US)',
    'America/Los_Angeles' => 'Pacific Time (US)',
    'Europe/London' => 'London (GMT/BST)',
    'Asia/Kolkata' => 'Kolkata (IST)',
    'Asia/Manila' => 'Manila (PHT)', // Common for Philippines
    'Asia/Shanghai' => 'Shanghai (CST)',
    'Australia/Sydney' => 'Sydney (AEST/AEDT)',
];

// Define days of the week for the hours loop (Unchanged)
$days_of_week = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>System Settings - <?= htmlspecialchars(getSetting('system_name','DentiTrack')) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<style>
/* --- General and Layout Styles (Existing) --- */
html { scroll-behavior: smooth; }
body {
    margin: 0;
    font-family: <?= htmlspecialchars(getSetting('font_family', 'Segoe UI')) ?>;
    background: #e6f0ff;
    color: #003366;
    display: flex;
    min-height: 100vh;
}
.sidebar {
    width: 220px;
    background: <?= htmlspecialchars(getSetting('sidebar_bg','#0066cc')) ?>;
    padding: 20px 0;
    color: <?= htmlspecialchars(getSetting('sidebar_text','#ffffff')) ?>;
    display: flex;
    flex-direction: column;
}
.sidebar h2 {
    text-align: center;
    margin-bottom: 30px;
    font-size: 24px;
    font-weight: 700;
    color: <?= htmlspecialchars(getSetting('header_text_color','#ffffff')) ?>;
}
.sidebar a {
    display: block;
    padding: 14px 24px;
    margin: 10px 15px;
    color: <?= htmlspecialchars(getSetting('sidebar_text','#ffffff')) ?>b3;
    text-decoration: none;
    border-left: 4px solid transparent;
    font-weight: 600;
    font-size: 15px;
    border-radius: 6px;
    transition: all 0.3s ease;
}
.sidebar a:hover, .sidebar a.active {
    background-color: rgba(255,255,255,0.2);
    color: #fff;
    border-left: 4px solid <?= htmlspecialchars(getSetting('accent_color','#ffcc00')) ?>;
}
main.main-content {
    flex: 1;
    padding: 40px 60px;
    background: #f8faff;
    overflow-y: auto;
    box-sizing: border-box;
}
.card { border-radius: 15px; box-shadow: 0 8px 20px rgba(0,0,0,0.08); }
.btn-primary { border-radius: 8px; background-color: <?= htmlspecialchars(getSetting('sidebar_bg','#0066cc')) ?>; border: none; }
.btn-primary:hover { 
    background-color: <?= htmlspecialchars(getSetting('accent_color','#ffcc00')) ?>; 
    color: #000;
}
/* New style for status messages */
.alert-danger { background-color: #f8d7da; color: #721c24; border-color: #f5c6cb; }
.alert-warning { background-color: #fff3cd; color: #856404; border-color: #ffeeba; }

/* Custom style for highlighting the selected day */
.highlight-day {
    background-color: #d4edda !important; /* Light green highlight */
    padding: 12px !important;
    border-radius: 8px !important;
    border: 2px solid #155724 !important;
    transition: background-color 0.3s, border 0.3s;
}

/* Improvement: Style for the select dropdowns */
.clinic-hour-select {
    border-color: #0066cc;
    transition: border-color 0.3s;
}
.clinic-hour-select:focus {
    box-shadow: 0 0 0 0.25rem rgba(0, 102, 204, 0.25);
    border-color: #004c99;
}
</style>
</head>
<body>
<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="admin_dashboard.php" ><i class="fas fa-home"></i> Dashboard</a>
    <a href="manage_accounts.php"><i class="fas fa-users-cog"></i> Manage Accounts</a>
    <a href="clinic_services_admin.php"><i class="fas fa-tools"></i> Clinic Services</a>
    <a href="generate_reports.php"><i class="fas fa-chart-line"></i> Generate Reports</a>
    <a href="payment_module.php"><i class="fas fa-money-check-dollar"></i> Payment Module</a>
    <a href="clinic_schedule_admin.php"><i class="fas fa-calendar-check"></i> Clinic Schedule</a>
    <a href="admin_settings.php" class="active"><i class="fas fa-gear"></i> System Settings</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">
    <h1 class="mb-4"><i class="fas fa-gear"></i> System Settings</h1>

    <?php if($message): ?>
        <div class="alert alert-<?= htmlspecialchars($message_type) ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="POST" class="card p-4 bg-white" enctype="multipart/form-data">
        
        <h5 class="mb-3">Appearance Settings</h5>
        <div class="row mb-5">
            <div class="col-md-3 mb-3">
                <label class="form-label">Sidebar Background</label>
                <input type="color" name="sidebar_bg" class="form-control form-control-color" value="<?= htmlspecialchars(getSetting('sidebar_bg')) ?>">
            </div>
            <div class="col-md-3 mb-3">
                <label class="form-label">Sidebar Text</label>
                <input type="color" name="sidebar_text" class="form-control form-control-color" value="<?= htmlspecialchars(getSetting('sidebar_text')) ?>">
            </div>
            <div class="col-md-3 mb-3">
                <label class="form-label">Accent Color</label>
                <input type="color" name="accent_color" class="form-control form-control-color" value="<?= htmlspecialchars(getSetting('accent_color')) ?>">
            </div>
            <div class="col-md-3 mb-3">
                <label class="form-label">Header Text Color</label>
                <input type="color" name="header_text_color" class="form-control form-control-color" value="<?= htmlspecialchars(getSetting('header_text_color')) ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Font Family</label>
                <select name="font_family" class="form-select">
                    <?php
                    $fonts = ['Segoe UI','Roboto','Poppins','Open Sans','Montserrat','Lato','Arial'];
                    $current = getSetting('font_family','Segoe UI');
                    foreach($fonts as $font){
                        $sel = ($font==$current)?'selected':'';
                        echo "<option value='$font' $sel>$font</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">System Name</label>
                <input type="text" name="system_name" class="form-control" value="<?= htmlspecialchars(getSetting('system_name')) ?>">
            </div>
        </div>
        
        <hr class="mb-5">

        <h5 class="mb-4">System Configuration</h5>
        <div class="row mb-4">
            <div class="col-md-6 mb-3">
                <label class="form-label">Default Timezone</label>
                <select name="default_timezone" class="form-select">
                    <?php
                    $current_timezone = getSetting('default_timezone', 'Asia/Manila');
                    foreach ($timezones as $tz_value => $tz_label) {
                        $sel = ($tz_value === $current_timezone) ? 'selected' : '';
                        echo "<option value='".htmlspecialchars($tz_value)."' $sel>".htmlspecialchars($tz_label)."</option>";
                    }
                    ?>
                </select>
                <small class="text-muted">Used for logging and appointment scheduling.</small>
            </div>

            <div class="col-md-6 mb-3">
                <label class="form-label">System Footer Text</label>
                <input type="text" name="footer_text" class="form-control" placeholder="e.g., Copyright © 2025 DentiTrack" value="<?= htmlspecialchars(getSetting('footer_text')) ?>">
                <small class="text-muted">Text that appears at the bottom of all pages.</small>
            </div>
        </div>
        
        <h5 class="mt-5 mb-4">Clinic Contact Information</h5>

        <div class="row mb-4">
            <div class="col-md-12 mb-3">
                <label class="form-label">Clinic Address</label>
                <input type="text" name="clinic_address" class="form-control" placeholder="e.g., 0067 Wakas, Bocaue, Philippines" value="<?= htmlspecialchars(getSetting('clinic_address')) ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Contact Number (Phone)</label>
                <input type="text" name="clinic_phone" class="form-control" placeholder="e.g., 0922 878 7341" value="<?= htmlspecialchars(getSetting('clinic_phone')) ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Clinic Email</label>
                <input type="email" name="clinic_email" class="form-control" placeholder="e.g., danaroxasdental@gmail.com" value="<?= htmlspecialchars(getSetting('clinic_email')) ?>">
            </div>
            </div>

        <h5 class="mt-5 mb-4">Clinic Operating Hours (Weekly Default)</h5>
       
                <small class="text-muted">
                    Pick a date to automatically highlight the corresponding Day/Hours setting below. 
                    Use the dropdown to select the opening time and the closing time separated by a hyphen (e.g., 9:00 AM - 6:00 PM).
                </small>
            </div>
            
            <?php
            // Start of Time Slot Pickers
            
            // Generate all possible open/close slots
            $open_slots = $time_slots;
            unset($open_slots['CLOSED']); // Opening time cannot be CLOSED
            $close_slots = $time_slots; 

            // Loop for the weekly settings
            foreach ($days_of_week as $day) {
                $setting_key = 'clinic_hours_' . $day;
                // Default value matching user request
                $default_hour = ($day === 'sunday') ? 'CLOSED' : '9:00 AM - 6:00 PM'; 
                
                // Fetch current value
                $current_hour = htmlspecialchars(getSetting($setting_key, $default_hour));
                
                // Extract current open and close times (default to CLOSED if format is wrong)
                $current_open = '';
                $current_close = '';
                if ($current_hour === 'CLOSED') {
                    $current_open = 'CLOSED';
                    $current_close = 'CLOSED';
                } elseif (preg_match('/(\d{1,2}:\d{2} [AP]M)\s*-\s*(\d{1,2}:\d{2} [AP]M)/i', $current_hour, $matches)) {
                    $current_open = $matches[1];
                    $current_close = $matches[2];
                }
                
                // Add a unique ID for JavaScript targeting and a custom attribute for the day index
                $day_index = array_search($day, $days_of_week); 
                
                echo "
                <div class='col-md-4 col-lg-3 mb-3' id='day-{$day}' data-day-index='{$day_index}' style='padding: 12px; border-radius: 8px;'>
                    <label class='form-label'>" . ucfirst($day) . " Hours</label>
                    <div class='input-group'>
                        <input type='hidden' name='{$setting_key}' id='{$setting_key}_hidden' value='{$current_hour}'>
                        
                        <select 
                            id='{$setting_key}_open'
                            class='form-select clinic-hour-select' 
                            onchange=\"updateClinicHours('{$setting_key}')\"
                        >";
                        
                        // Option for CLOSED
                        $selected_closed = ($current_open === 'CLOSED') ? 'selected' : '';
                        echo "<option value='CLOSED' $selected_closed>CLOSED</option>";
                        
                        // Options for Open Times
                        foreach($open_slots as $slot_value => $slot_label) {
                            $selected = ($slot_value === $current_open) ? 'selected' : '';
                            echo "<option value='{$slot_value}' $selected>{$slot_value}</option>";
                        }
                        echo "</select>";

                        // Close Time Dropdown
                        echo "
                        <select 
                            id='{$setting_key}_close'
                            class='form-select clinic-hour-select' 
                            onchange=\"updateClinicHours('{$setting_key}')\"
                            " . (($current_open === 'CLOSED') ? 'disabled' : '') . "
                        >";

                        // Options for Close Times
                        foreach($close_slots as $slot_value => $slot_label) {
                            $selected = ($slot_value === $current_close) ? 'selected' : '';
                            echo "<option value='{$slot_value}' $selected>{$slot_value}</option>";
                        }

                        echo "</select>
                    </div>
                </div>";
            }
            // End of Time Slot Pickers
            ?>
        </div>

        <h5 class="mt-5 mb-4">Frontpage 'About Us' Content</h5>
        <div class="row mb-4">
            <div class="col-md-12 mb-3">
                <label class="form-label">About Us Title</label>
                <input type="text" name="about_us_title" class="form-control" placeholder="e.g., Our Mission to Your Smile" value="<?= htmlspecialchars(getSetting('about_us_title')) ?>">
            </div>
            <div class="col-md-12 mb-3">
                <label class="form-label">'About Us' Description Text</label>
                <textarea name="about_us_text" class="form-control" rows="5" placeholder="Enter the description for the About Us section"><?= htmlspecialchars(getSetting('about_us_text')) ?></textarea>
            </div>
            <div class="col-md-12 mb-3">
                <label class="form-label">'About Us' Image (Upload File)</label>
                <input type="file" name="about_us_image" class="form-control">
                <small class="text-muted">
                    Upload a new image (JPG, PNG, GIF). Current Image: 
                    <strong>
                        <?php 
                        $current_path = getSetting('about_us_image', 'images/denti.jpg');
                        echo htmlspecialchars(basename($current_path));
                        ?>
                    </strong>
                </small>
            </div>
        </div>


        <div class="text-end mt-4">
            <button type="submit" name="save_settings" class="btn btn-primary px-4"><i class="fas fa-save"></i> Save Settings</button>
        </div>
    </form>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Helper function to update the hidden input field when a time slot is changed
    function updateClinicHours(settingKey) {
        const openSelect = document.getElementById(settingKey + '_open');
        const closeSelect = document.getElementById(settingKey + '_close');
        const hiddenInput = document.getElementById(settingKey + '_hidden');
        
        if (openSelect.value === 'CLOSED') {
            // If the clinic is closed, set the hidden value to 'CLOSED' and disable the closing time dropdown.
            hiddenInput.value = 'CLOSED';
            closeSelect.disabled = true;
            closeSelect.value = 'CLOSED'; 

        } else {
            // If the clinic is open, enable the closing time dropdown.
            closeSelect.disabled = false;

            // Simple validation: If the selected close time is before or equal to the open time, reset close time.
            if (openSelect.value && closeSelect.value && closeSelect.value !== 'CLOSED') {
                const openTime = new Date('01/01/2000 ' + openSelect.value);
                const closeTime = new Date('01/01/2000 ' + closeSelect.value);
                
                if (closeTime <= openTime) {
                    // Find the next slot after the open time to suggest as default
                    let validOptionFound = false;
                    for (let i = 0; i < closeSelect.options.length; i++) {
                        const optionValue = closeSelect.options[i].value;
                        if (optionValue !== 'CLOSED') {
                            const optionTime = new Date('01/01/2000 ' + optionValue);
                            if (optionTime > openTime) {
                                closeSelect.value = optionValue;
                                validOptionFound = true;
                                break;
                            }
                        }
                    }
                    if (!validOptionFound) {
                        // Fallback to latest time if necessary
                        closeSelect.value = closeSelect.options[closeSelect.options.length - 1].value;
                    }
                }
            }
            
            // Format the final value for saving
            hiddenInput.value = openSelect.value + ' - ' + closeSelect.value;
        }
    }

    // New JavaScript function for the Day Lookup and Highlighting
    function lookupDayAndHighlight() {
        const dateInput = document.getElementById('dateLookup');
        const dayResultSpan = document.getElementById('dayResult');
        const dateValue = dateInput.value;

        // Reset previous highlights
        document.querySelectorAll('.row.mb-4 > div[id^="day-"]').forEach(el => {
            el.classList.remove('highlight-day');
        });

        if (dateValue) {
            // Create a Date object from the input value (YYYY-MM-DD format)
            const date = new Date(dateValue + 'T00:00:00'); 
            
            // Get the day index: 0=Sunday, 1=Monday, ..., 6=Saturday
            let jsDayIndex = date.getDay(); 
            
            // Convert JS index (0-6 starting Sunday) to PHP/Array index (0-6 starting Monday)
            const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
            
            let phpDayIndex;
            if (jsDayIndex === 0) {
                // Sunday (JS 0) is the 7th day (index 6) in the PHP list
                phpDayIndex = 6; 
            } else {
                // Monday (JS 1) becomes index 0, Tuesday (JS 2) becomes index 1, etc.
                phpDayIndex = jsDayIndex - 1; 
            }

            const dayName = days[phpDayIndex];
            
            // Update the result display
            dayResultSpan.textContent = `Selected day: ${dayName.charAt(0).toUpperCase() + dayName.slice(1)}`;

            // Highlight the corresponding input field container
            const targetElement = document.getElementById(`day-${dayName}`);
            if (targetElement) {
                targetElement.classList.add('highlight-day');
                // Scroll the highlighted element into view
                targetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        } else {
            dayResultSpan.textContent = 'Pick a date to see the day\'s name.';
        }
    }
    
    // Initial call to ensure all hidden inputs are correctly set up (especially important for closed days)
    document.addEventListener('DOMContentLoaded', () => {
        const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
        days.forEach(day => {
            const settingKey = 'clinic_hours_' + day;
            const openSelect = document.getElementById(settingKey + '_open');
            
            // Run updateClinicHours on load for any day that is set to 'CLOSED' initially
            if (openSelect && openSelect.value === 'CLOSED') {
                updateClinicHours(settingKey);
            }
        });
    });
</script>
</body>
</html>