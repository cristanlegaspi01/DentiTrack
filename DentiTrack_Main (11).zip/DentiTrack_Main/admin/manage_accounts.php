<?php
session_start();
require_once '../config/db_pdo.php';

// Restrict access to admin only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

$admin_username = $_SESSION['username'];
date_default_timezone_set('Asia/Manila');
$pdo->exec("SET time_zone = '+08:00'");

// Clinic name placeholder for single-clinic context
$current_clinic_name = 'The Clinic'; 

// Alert messages
$alertMessage = '';
if (isset($_GET['created'])) $alertMessage = "✅ Account successfully created.";
if (isset($_GET['updated'])) $alertMessage = "✅ Account updated successfully.";
if (isset($_GET['deleted'])) $alertMessage = "✅ Account deleted successfully.";
if (isset($_GET['error'])) $alertMessage = "⚠️ " . htmlspecialchars($_GET['error']);

// Fetch ALL users for client-side filtering and searching
$sql = "SELECT user_id, username, email, role, created_at, updated_at 
        FROM users 
        ORDER BY created_at DESC";
    
$stmt = $pdo->prepare($sql);
$stmt->execute();
$all_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Accounts - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    html { scroll-behavior: smooth; }
    body {
        margin: 0;
        font-family: 'Segoe UI', Tahoma, sans-serif;
        background: #e6f0ff;
        color: #003366;
        display: flex;
        min-height: 100vh;
    }

    /* ==== SIDEBAR (unchanged) ==== */
    nav.sidebar {
        width: 220px;
        background: linear-gradient(to bottom, #3399ff, #0066cc);
        color: white;
        padding: 20px 0;
        display: flex;
        flex-direction: column;
        box-shadow: 3px 0 10px rgba(0,0,0,0.15);
        position: fixed;
        height: 100%;
        z-index: 10;
    }
    .sidebar h2 {
        text-align: center;
        margin-bottom: 25px;
        font-size: 24px;
        font-weight: 700;
    }
    .sidebar a {
        display: block;
        padding: 14px 24px;
        margin: 8px 15px;
        color: #cce0ff;
        text-decoration: none;
        font-weight: 600;
        font-size: 15px;
        border-left: 4px solid transparent;
        border-radius: 6px;
        transition: all 0.3s ease;
    }
    .sidebar a i { margin-right: 10px; }
    .sidebar a:hover, .sidebar a.active {
        background-color: rgba(255,255,255,0.2);
        color: #fff;
        border-left: 4px solid #ffcc00;
    }

    /* ==== MAIN (unchanged) ==== */
    main {
        flex: 1;
        margin-left: 220px;
        padding: 40px 60px;
        background: #f8faff;
        overflow-y: auto;
        box-sizing: border-box;
        z-index: 1;
    }
    h1 {
        font-size: 2rem;
        color: #004080;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .welcome {
        font-size: 1.1rem;
        margin: 10px 0 20px;
        font-weight: 600;
    }

    .alert {
        margin: 10px 0;
        padding: 12px 16px;
        background: #d4edda;
        color: #155724;
        border-radius: 6px;
        border: 1px solid #c3e6cb;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .create-btn {
        background: linear-gradient(90deg, #007bff, #00bfff);
        color: white;
        padding: 10px 18px;
        font-size: 15px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        transition: 0.3s;
        font-weight: 600;
    }
    .create-btn:hover { background: linear-gradient(90deg, #006ae3, #00a4e4); }

    /* ==== CONTROLS/FILTERS (unchanged) ==== */
    .control-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        gap: 20px;
    }
    .filter-group {
        display: flex;
        gap: 15px;
        align-items: center;
    }
    #roleFilter, #searchInput {
        padding: 10px 12px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 15px;
    }
    .search-container {
        position: relative;
        width: 300px;
    }
    #clearSearch {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #999;
        cursor: pointer;
        display: none; /* Initially hidden */
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    th, td {
        padding: 12px 16px;
        border-bottom: 1px solid #eee;
        text-align: left;
    }
    th {
        background: #dbeaff;
        color: #003366;
        font-weight: 700;
    }
    tr:hover { background: #eef5ff; }

    .edit, .delete {
        border: none;
        padding: 7px 12px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        transition: 0.3s;
    }
    .edit { background: #ffcc00; color: #003366; }
    .edit:hover { background: #ffdb4d; }
    .delete { background: #e74c3c; color: white; }
    .delete:hover { background: #ff6b5a; }

    /* ==== MODALS (CSS kept for completeness) ==== */
    .modal {
        display: none; position: fixed; top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.6);
        justify-content: center; align-items: center;
        z-index: 1000;
    }
    .modal-content {
        background: #fff;
        padding: 30px;
        border-radius: 15px;
        width: 420px;
        max-width: 90%;
        position: relative;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }
    .modal-content h2 {
        margin-bottom: 15px;
        color: #003366;
    }
    .close-modal {
        position: absolute;
        right: 15px; top: 10px;
        font-size: 22px;
        color: #666;
        cursor: pointer;
    }
    label { display: block; margin-top: 10px; font-weight: 600; }
    input[type="text"], input[type="email"], input[type="password"], select {
        padding: 10px;
        font-size: 15px;
        border: 1px solid #ccc;
        border-radius: 6px;
        width: 100%;
        margin-top: 5px;
        transition: border 0.2s;
    }
    input:focus, select:focus {
        outline: none;
        border-color: #3399ff;
    }
    .save-btn {
        background: #28a745;
        color: white;
        padding: 10px 16px;
        border-radius: 6px;
        border: none;
        font-weight: 600;
        cursor: pointer;
    }
    .save-btn:hover { background: #2ecc71; }
    .cancel-btn {
        background: #ccc;
        color: black;
        padding: 10px 16px;
        border-radius: 6px;
        border: none;
        font-weight: 600;
        cursor: pointer;
    }
    .clearfix { display: flex; justify-content: flex-end; margin-top: 20px; gap: 10px; }
    .hidden { display: none; }
</style>
</head>

<body>
<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="admin_dashboard.php" ><i class="fas fa-home"></i> Dashboard</a>
    <a href="manage_accounts.php" class="active"><i class="fas fa-users-cog"></i> Manage Accounts</a>
    <a href="clinic_services_admin.php"><i class="fas fa-tools"></i> Clinic Services</a>
    <a href="generate_reports.php"><i class="fas fa-chart-line"></i> Generate Reports</a>
    <a href="payment_module.php"><i class="fas fa-money-check-dollar"></i> Payment Module</a>
    <a href="clinic_schedule_admin.php"><i class="fas fa-calendar-check"></i> Clinic Schedule</a>
    <a href="admin_settings.php"><i class="fas fa-gear"></i> System Settings</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main>
    <h1><i class="fas fa-users-cog"></i> Manage Accounts</h1>
    <p class="welcome">Welcome, <strong><?= htmlspecialchars($admin_username) ?></strong></p>

    <?php if ($alertMessage): ?>
        <div class="alert"><i class="fas fa-info-circle"></i> <?= $alertMessage ?></div>
    <?php endif; ?>

    <div class="control-bar">
        <button class="create-btn" onclick="openCreateModal()"><i class="fas fa-user-plus"></i> Create New Account</button>
        
        <div class="filter-group">
            <label for="roleFilter">Filter by Role:</label>
            <select id="roleFilter" onchange="filterTable()">
                <option value="all">All Users</option>
                <option value="secretary">Secretaries</option>
                <option value="admin">Admins</option>
                <option value="doctor">Doctors</option>
            </select>

            <div class="search-container">
                <input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search username, email, or role..." title="Type to search accounts">
                <button type="button" id="clearSearch" onclick="clearSearch()"><i class="fas fa-times-circle"></i></button>
            </div>
        </div>
    </div>

    <div class="account-table">
        <h2>All Accounts</h2>
        <?php if (count($all_users) > 0): ?>
            <table id="userTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Created</th>
                        <th>Updated</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="userTableBody">
                    <?php foreach ($all_users as $user): ?>
                        <tr data-role="<?= htmlspecialchars($user['role']) ?>">
                            <td><?= $user['user_id'] ?></td>
                            <td><?= htmlspecialchars($user['username']) ?></td>
                            <td><?= htmlspecialchars($user['email'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($user['role']) ?></td>
                            <td><?= htmlspecialchars($user['created_at']) ?></td>
                            <td><?= htmlspecialchars($user['updated_at']) ?></td>
                            <td>
                                <button class="edit" onclick="openEditModal(
                                    <?= $user['user_id'] ?>, 
                                    '<?= htmlspecialchars(addslashes($user['username'])) ?>', 
                                    '<?= htmlspecialchars(addslashes($user['email'] ?? '')) ?>', 
                                    '<?= htmlspecialchars($user['role']) ?>'
                                )">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="delete" onclick="confirmDelete(<?= $user['user_id'] ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No user accounts found in the system.</p>
        <?php endif; ?>
    </div>

    <div id="createModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeCreateModal()">&times;</span>
            <h2>Create Account</h2>
            <form id="createForm" action="save_account.php" method="POST">
                <label>Username:</label>
                <input type="text" name="username" required>
                <label>Email:</label>
                <input type="email" name="email">
                <label>Password:</label>
                <input type="password" name="password" required>
                <label>Confirm Password:</label>
                <input type="password" name="confirm_password" required>
                <label>Role:</label>
                <select name="role" id="roleSelect" required>
                    <option value="">Select Role</option>
                    <option value="admin">Admin</option>
                    <option value="doctor">Doctor</option>
                    <option value="secretary">Secretary</option>
                </select>

                <div class="clearfix">
                    <button type="button" class="cancel-btn" onclick="closeCreateModal()">Cancel</button>
                    <button type="submit" class="save-btn">Save</button>
                </div>
            </form>
        </div>
    </div>

    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeEditModal()">&times;</span>
            <h2>Edit Account</h2>
            <form id="editForm" action="edit_account.php" method="POST">
                <input type="hidden" name="user_id" id="edit-user_id">
                
                <label>Username:</label>
                <input type="text" name="username" id="edit-username" required>
                
                <label>Email:</label>
                <input type="email" name="email" id="edit-email">
                
                <label>Role:</label>
                <select name="role" id="edit-roleSelect" required>
                    <option value="admin">Admin</option>
                    <option value="doctor">Doctor</option>
                    <option value="secretary">Secretary</option>
                </select>

                <div class="clearfix">
                    <button type="button" class="cancel-btn" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="save-btn">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</main>

<script>
    const userTableBody = document.getElementById('userTableBody');
    const roleFilter = document.getElementById('roleFilter');
    const searchInput = document.getElementById('searchInput');
    const clearSearchBtn = document.getElementById('clearSearch');

    /**
     * Filters the table rows based on the selected role from the dropdown. (Unchanged)
     */
    function filterTable() {
        const selectedRole = roleFilter.value;
        const rows = userTableBody.getElementsByTagName('tr');

        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            const role = row.getAttribute('data-role');
            
            const roleMatches = selectedRole === 'all' || selectedRole === role;

            if (roleMatches) {
                if (row.style.display !== 'none' || searchInput.value.trim() === '') {
                    row.style.display = '';
                }
            } else {
                row.style.display = 'none';
            }
        }
        if (searchInput.value.trim() !== '') {
            searchTable();
        }
    }
    
    /**
     * Filters the table rows based on the text input (live search). (Unchanged)
     */
    function searchTable() {
        const filterText = searchInput.value.toUpperCase().trim();
        const selectedRole = roleFilter.value;
        const rows = userTableBody.getElementsByTagName('tr');

        if (filterText.length > 0) {
            clearSearchBtn.style.display = 'block';
        } else {
            clearSearchBtn.style.display = 'none';
        }

        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            const role = row.getAttribute('data-role');
            
            const roleMatches = selectedRole === 'all' || selectedRole === role;

            const rowText = row.textContent || row.innerText;
            const textMatches = rowText.toUpperCase().indexOf(filterText) > -1;

            if (roleMatches && textMatches) {
                row.style.display = ''; // Show row
            } else {
                row.style.display = 'none'; // Hide row
            }
        }
    }

    /**
     * Clears the search input and resets the table view. (Unchanged)
     */
    function clearSearch() {
        searchInput.value = '';
        clearSearchBtn.style.display = 'none';
        searchTable(); 
        filterTable(); 
    }

    // Modal functions (Create - Unchanged)
    function openCreateModal() {
        document.getElementById('createModal').style.display = 'flex';
    }
    function closeCreateModal() {
        document.getElementById('createModal').style.display = 'none';
        document.getElementById('createForm').reset();
    }

    // Modal functions (Edit - NEW)
    function openEditModal(userId, username, email, role) {
        // Populate the hidden user_id field for form submission
        document.getElementById('edit-user_id').value = userId;
        // Populate the form fields with current user data
        document.getElementById('edit-username').value = username;
        document.getElementById('edit-email').value = email;
        // Select the correct role in the dropdown
        document.getElementById('edit-roleSelect').value = role;
        
        // Display the modal
        document.getElementById('editModal').style.display = 'flex';
    }
    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
        document.getElementById('editForm').reset();
    }

    function confirmDelete(userId) {
        if (confirm('Are you sure you want to delete this account? This action cannot be undone.')) {
            window.location.href = 'delete_account.php?user_id=' + userId;
        }
    }
    
    // Global click handler to close modals when clicking outside
    window.onclick = function(e) {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    }
</script>
</body>
</html>