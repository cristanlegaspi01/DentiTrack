<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    exit("Unauthorized");
}

include '../config/db.php';

$admin_username = $_SESSION['username'];

// Fetch unique services for dropdowns (Appointments) - REVISED
// Now joins 'appointments' with 'services' table on service_id
$services_result = $conn->query("
    SELECT DISTINCT s.service_name AS service 
    FROM appointments a
    JOIN services s ON a.service_id = s.service_id
    ORDER BY service ASC
");
$services = $services_result ? $services_result->fetch_all(MYSQLI_ASSOC) : [];

// Fetch unique patients for dropdowns (Appointments) - REVISED
// Now joins 'appointments' with 'patient' table on patient_id to get 'fullname'
$patients_result = $conn->query("
    SELECT DISTINCT p.fullname AS patient_name 
    FROM appointments a
    JOIN patient p ON a.patient_id = p.patient_id
    ORDER BY patient_name ASC
");
$patients = $patients_result ? $patients_result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Generate Reports - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
body { margin:0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color:#003366; display:flex; min-height:100vh; background:#e6f0ff; }

/* Sidebar (UNCHANGED) */
.sidebar {
    width:220px; background: linear-gradient(to bottom,#3399ff,#0066cc); padding:20px 0; color:white; display:flex; flex-direction:column;
}
.sidebar h2 { text-align:center; margin-bottom:30px; font-size:24px; font-weight:700; }
.sidebar a { display:block; padding:14px 24px; margin:10px 15px; color:#cce0ff; text-decoration:none; border-left:4px solid transparent; font-weight:600; font-size:15px; border-radius:6px; transition: all 0.3s;}
.sidebar a i { margin-right:10px; }
.sidebar a:hover, .sidebar a.active { background-color: rgba(255,255,255,0.2); color:#fff; border-left:4px solid #ffcc00; }

/* Main content */
main.main-content { flex:1; padding:40px 60px; background:#f8faff; overflow-y:auto; box-sizing:border-box; }
h1 { font-size:2.2rem; color:#004080; display:flex; align-items:center; gap:0.5rem; }

/* Report form - Use grid for better layout */
form.report-form { 
    background:white; padding:20px; border-radius:12px; margin-bottom:25px; 
    box-shadow:0 6px 15px rgba(0,0,0,0.08);
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}
.form-group { display: flex; flex-direction: column; }
.form-group label { margin-top:0px; font-weight:600; color:#004080; font-size: 14px;}
.form-group select, .form-group input { 
    padding:8px; width:100%; margin-top:5px; border-radius:6px; 
    border:1px solid #cce0ff; background: #f9fcff;
    box-sizing: border-box;
}

/* Specific filters for appointments */
#appointmentFilters {
    grid-column: 1 / -1; /* Make it span full width */
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    padding-top: 10px;
}
.search-input-container {
    /* Ensures search bar takes a reasonable amount of space */
    grid-column: span 2; 
}
.clear-button-container {
    /* Aligns clear button to the bottom right */
    align-self: flex-end; 
}

/* --- NEW ANALYTICS STYLES --- */
#analyticsSummary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
}
.summary-card {
    background: white;
    padding: 18px;
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.08);
    text-align: center;
    border-bottom: 5px solid #007bff; /* Default color */
    transition: transform 0.2s;
}
.summary-card:hover {
    transform: translateY(-3px);
}
.summary-card h4 {
    margin: 0 0 5px 0;
    font-size: 14px;
    color: #666;
    font-weight: 500;
}
.summary-card p {
    margin: 0;
    font-size: 2.2rem;
    font-weight: 700;
    color: #004080;
}
.card-red { border-bottom-color: #dc3545; }
.card-green { border-bottom-color: #28a745; }
.card-blue { border-bottom-color: #007bff; }
.card-orange { border-bottom-color: #ffc107; }
/* ---------------------------- */


/* Table */
#reportPreview table { width:100%; border-collapse: collapse; background:white; border-radius:10px; overflow:hidden; box-shadow:0 5px 20px rgba(0,0,0,0.08);}
#reportPreview th, #reportPreview td { padding:10px 12px; border-bottom:1px solid #eee; text-align:left; font-size:14px;}
#reportPreview th { background:#007bff; color:white; font-weight:700;} 
#reportPreview tr:hover { background:#eef5ff; }

/* Buttons */
.btn-group {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-bottom: 20px;
}
.btn { padding:10px 18px; border-radius:6px; border:none; cursor:pointer; font-weight:600; transition: background 0.3s;}
.btn-primary { background:#007bff; color:white;}
.btn-primary:hover { background:#0056b3; }
.btn-secondary { background:#6c757d; color:white;}
.btn-secondary:hover { background:#5a6268; }
.btn-danger { background:#dc3545; color:white; }
.btn-danger:hover { background:#c82333; }
.btn-success { background:#28a745; color:white; }
.btn-success:hover { background:#1e7e34; }


/* Hide elements when printing */
@media print {
    /* Set only main content visible */
    body { background: white; }
    .sidebar, .btn-group, .report-form, #analyticsSummary { display: none; }
    main.main-content { padding: 20px; margin: 0; }
    #reportPreview { box-shadow: none; }
    #reportPreview th { background:#f1f1f1 !important; color:#333 !important; }
}
</style>
</head>
<body>

<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="admin_dashboard.php" ><i class="fas fa-home"></i> Dashboard</a>
    <a href="manage_accounts.php"><i class="fas fa-users-cog"></i> Manage Accounts</a>
    <a href="clinic_services_admin.php"><i class="fas fa-tools"></i> Clinic Services</a>
    <a href="generate_reports.php" class="active"><i class="fas fa-chart-line"></i> Generate Reports</a>
    <a href="payment_module.php"><i class="fas fa-money-check-dollar"></i> Payment Module</a>
    <a href="clinic_schedule_admin.php"><i class="fas fa-calendar-check"></i> Clinic Schedule</a>
    <a href="admin_settings.php"><i class="fas fa-gear"></i> System Settings</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">
    <h1><i class="fas fa-chart-line"></i> Reporting</h1>
    <p>Welcome, <strong><?= htmlspecialchars($admin_username) ?></strong></p>

    <form class="report-form" id="reportForm">
        <div class="form-group">
            <label for="report_category">Report Category</label>
            <select name="report_category" id="report_category">
                <option value="appointments">Appointments</option>
                <option value="dental_supplies">Dental Supplies</option>
                <option value="activity_log">User Activity Log</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="start_date">Start Date</label>
            <input type="date" name="start_date" id="start_date">
        </div>
        
        <div class="form-group">
            <label for="end_date">End Date</label>
            <input type="date" name="end_date" id="end_date">
        </div>

        <div class="form-group search-input-container">
            <label for="global_search"><i class="fas fa-magnifying-glass"></i> Search Report Data</label>
            <input type="text" id="global_search" name="global_search" placeholder="Filter by Name, ID, or Keyword..." autocomplete="off">
        </div>
        
        <div id="appointmentFilters">
            <div class="form-group">
                <label for="search_patient">Patient</label>
                <select name="search_patient" id="search_patient">
                    <option value="">All Patients</option>
                    <?php foreach($patients as $p): ?>
                        <option value="<?= htmlspecialchars($p['patient_name']) ?>"><?= htmlspecialchars($p['patient_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="search_service">Service</label>
                <select name="search_service" id="search_service">
                    <option value="">All Services</option>
                    <?php foreach($services as $s): ?>
                        <option value="<?= htmlspecialchars($s['service']) ?>"><?= htmlspecialchars($s['service']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="search_status">Status</label>
                <select name="search_status" id="search_status">
                    <option value="">All</option>
                    <option value="scheduled">Scheduled</option>
                    <option value="completed">Completed</option>
                    <option value="pending">Pending</option>
                    <option value="cancelled">Cancelled</option>
                </select>
            </div>
            <div class="form-group clear-button-container">
                <button type="button" class="btn btn-danger" id="clearFiltersBtn"><i class="fas fa-eraser"></i> Clear All Filters</button>
            </div>
        </div>
        
    </form>
    
    <div class="btn-group">
        <button onclick="window.print()" class="btn btn-secondary"><i class="fas fa-print"></i> Print Report</button>
        <button onclick="exportCSV()" class="btn btn-primary"><i class="fas fa-file-csv"></i> Export to CSV</button>
    </div>

    <div id="analyticsSummary">
        </div>
    
    <div id="reportPreview">
           <p style="text-align: center; color: #555; margin-top: 50px;">Select a report category or apply filters to view data.</p>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const reportForm = document.getElementById('reportForm');
    const categorySelect = document.getElementById('report_category');
    const appointmentFilters = document.getElementById('appointmentFilters');
    const previewDiv = document.getElementById('reportPreview');
    const analyticsDiv = document.getElementById('analyticsSummary'); 
    const clearFiltersBtn = document.getElementById('clearFiltersBtn');

    // Debounce function (unchanged)
    const debounce = (func, delay) => {
        let timeoutId;
        return function(...args) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => func.apply(this, args), delay);
        };
    };

    function updateFilterVisibility(category) {
        appointmentFilters.style.display = (category === 'appointments') ? 'grid' : 'none';
    }

    function fetchReports() {
        const formData = new FormData(reportForm);
        
        // Clear both sections and show loader
        analyticsDiv.innerHTML = '';
        previewDiv.innerHTML = '<p style="text-align: center; color: #007bff; padding: 50px 0;"><i class="fas fa-spinner fa-spin fa-2x"></i><br>Loading data from database...</p>';

        fetch('fetch_reports.php', { 
            method:'POST', 
            body:formData 
        })
        .then(res => res.json()) // IMPORTANT: Expect JSON response now
        .then(data => {
            // Display Analytics and Report HTML from the JSON object
            analyticsDiv.innerHTML = data.analytics_html;
            previewDiv.innerHTML = data.report_html;
        })
        .catch(error => {
            previewDiv.innerHTML = '<p style="text-align: center; color: red; padding: 50px 0;"><i class="fas fa-exclamation-triangle"></i> Error fetching report data. Check console for details.</p>';
            console.error('Fetch error:', error);
        });
    }

    // Debounced version of fetchReports for global search (unchanged)
    const debouncedFetchReports = debounce(fetchReports, 300); 

    function clearFilters() {
        reportForm.reset();
        updateFilterVisibility(categorySelect.value); 
        fetchReports();
    }

    // --- Event Listeners ---
    reportForm.querySelectorAll('select, input[type="date"]').forEach(el => {
        el.addEventListener('change', fetchReports);
    });
    
    document.getElementById('global_search').addEventListener('input', debouncedFetchReports);

    categorySelect.addEventListener('change', function() {
        updateFilterVisibility(this.value);
        fetchReports();
    });

    clearFiltersBtn.addEventListener('click', clearFilters);
    
    reportForm.addEventListener('submit', (e) => e.preventDefault());

    // Initial load
    updateFilterVisibility(categorySelect.value);
    fetchReports();
});

// CSV Export Function (Client-side logic - unchanged)
function exportCSV() {
    const table = document.querySelector('#reportPreview table');
    if(!table) return alert("No tabular data available to export! Please generate a report first.");

    let csv = [];
    const rows = table.querySelectorAll('tr');

    for (const row of rows) {
        const cells = row.querySelectorAll('th, td');
        const rowData = [];
        for (const cell of cells) {
            let text = cell.textContent.trim();
            if (text.includes(',')) text = `"${text}"`;
            rowData.push(text);
        }
        csv.push(rowData.join(','));
    }

    const csvFile = new Blob([csv.join('\n')], { type: 'text/csv' });
    const downloadLink = document.createElement('a');
    downloadLink.download = `DentiTrack_Report_${document.getElementById('report_category').value}_${new Date().toISOString().slice(0, 10)}.csv`;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}
</script>
</body>
</html>