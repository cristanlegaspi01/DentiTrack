<?php
// clinic_schedule_admin.php
// Schedule-only admin UI (separated from services management)
// Sidebar and design preserved from original combined page.
// Added: calendar date picker (flatpickr) for Specific Date Overrides & Leave

session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

include '../config/db.php'; // mysqli $conn
include '../config/settings_loader.php';

$admin_username = $_SESSION['username'];
$message = '';
$doctor_load_error = null;

date_default_timezone_set(getSetting('default_timezone', 'Asia/Manila'));
$days_of_week_full = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];

function parse_date_input_to_sql($input) {
    $val = trim((string)$input);
    if ($val === '') return null;
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $val)) return $val;
    if (preg_match('/^\d{2}\/\d{2}\/\d{4}$/', $val)) {
        list($m,$d,$y) = explode('/',$val);
        if (checkdate((int)$m,(int)$d,(int)$y)) {
            return sprintf('%04d-%02d-%02d',$y,$m,$d);
        }
    }
    $t = strtotime($val);
    if ($t !== false) return date('Y-m-d',$t);
    return null;
}

// safe prepare helper (throws exception on prepare failure)
function prepare_or_throw($sql) {
    global $conn;
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        throw new Exception("MySQL prepare() failed: " . $conn->error . " -- SQL: " . $sql);
    }
    return $stmt;
}

// helper: check table existence to avoid fatal prepare failures
function table_exists($table) {
    global $conn;
    $t = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$t}'");
    return ($res && $res->num_rows > 0);
}

// --- Load doctors ---
$default_doctor_id = 1;
$doctor_id = $_REQUEST['doctor_id'] ?? $default_doctor_id;
$doctor_id = filter_var($doctor_id, FILTER_VALIDATE_INT);

$doctors = [];
try {
    $stmt = prepare_or_throw("SELECT user_id, username FROM users WHERE role = 'doctor' ORDER BY username ASC");
    $stmt->execute();
    $res = $stmt->get_result();
    while ($r = $res->fetch_assoc()) $doctors[$r['user_id']] = htmlspecialchars($r['username']);
    $stmt->close();
} catch (Exception $e) {
    $doctor_load_error = $e->getMessage();
    $doctors = [0 => 'ERROR LOADING DOCTORS'];
}
if (!array_key_exists($doctor_id, $doctors) && !empty($doctors)) $doctor_id = key($doctors);
elseif (empty($doctors)) $doctor_id = 0;

// Load master services (for assignment list) if table exists
$services_master = [];
if (table_exists('services')) {
    try {
        $stmt = prepare_or_throw("SELECT service_id, service_name, price FROM services ORDER BY created_at DESC");
        $stmt->execute();
        $res = $stmt->get_result();
        while ($s = $res->fetch_assoc()) $services_master[] = $s;
        $stmt->close();
    } catch (Exception $e) {
        // non-fatal
    }
}

// doctor_services mapping (if table exists)
$doctor_services_map = [];
if ($doctor_id > 0 && table_exists('doctor_services')) {
    try {
        $stmt = prepare_or_throw("SELECT service_id FROM doctor_services WHERE doctor_id = ?");
        $stmt->bind_param("i",$doctor_id);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) $doctor_services_map[(int)$r['service_id']] = true;
        $stmt->close();
    } catch (Exception $e) {
        // ignore mapping load failure
    }
}

// --- POST handling (schedule-related only) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1) Delete schedule row
    if (isset($_POST['delete_schedule_id'])) {
        $delete_schedule_id = filter_input(INPUT_POST,'delete_schedule_id',FILTER_VALIDATE_INT);
        $current_doctor_id = filter_input(INPUT_POST,'doctor_to_schedule',FILTER_VALIDATE_INT);
        try {
            $stmt = prepare_or_throw("DELETE FROM doctor_schedules WHERE schedule_id = ? AND doctor_id = ?");
            $stmt->bind_param("ii",$delete_schedule_id,$current_doctor_id);
            $stmt->execute();
            $stmt->close();
            $message = "✅ Schedule row deleted.";
            header("Location: clinic_schedule_admin.php?doctor_id=".$current_doctor_id);
            exit();
        } catch (Exception $e) { $message = "❌ Error deleting schedule row: ".htmlspecialchars($e->getMessage()); }
    }

    // 2) Delete exception
    if (isset($_POST['delete_exception_id'])) {
        $delete_id = filter_input(INPUT_POST,'delete_exception_id',FILTER_VALIDATE_INT);
        $current_doctor_id = filter_input(INPUT_POST,'doctor_to_schedule',FILTER_VALIDATE_INT);
        try {
            $stmt = prepare_or_throw("DELETE FROM doctor_availability WHERE availability_id = ? AND doctor_id = ?");
            $stmt->bind_param("ii",$delete_id,$current_doctor_id);
            $stmt->execute();
            $stmt->close();
            $message = "✅ Exception deleted.";
            header("Location: clinic_schedule_admin.php?doctor_id=".$current_doctor_id);
            exit();
        } catch (Exception $e) { $message = "❌ Error deleting exception: ".htmlspecialchars($e->getMessage()); }
    }

    // 3) Main schedule save
    if (isset($_POST['save_schedule'])) {
        $doctor_id = filter_input(INPUT_POST,'doctor_to_schedule',FILTER_VALIDATE_INT);
        try {
            $conn->begin_transaction();

            // A: doctor_config (KEEP THIS SECTION TO UPDATE DOCTOR CONFIG)
            $consult_duration = filter_input(INPUT_POST,'consult_duration',FILTER_VALIDATE_INT) ?: 30;
            $consult_cost = filter_input(INPUT_POST,'consult_cost',FILTER_VALIDATE_FLOAT) ?: 0.0;
            $service_duration = filter_input(INPUT_POST,'service_duration',FILTER_VALIDATE_INT) ?: 60;
            $service_cost = filter_input(INPUT_POST,'service_cost',FILTER_VALIDATE_FLOAT) ?: 0.0;

            $stmt = prepare_or_throw("
                INSERT INTO doctor_config (doctor_id, consult_duration, consult_cost, service_duration, service_cost)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE consult_duration=VALUES(consult_duration), consult_cost=VALUES(consult_cost), service_duration=VALUES(service_duration), service_cost=VALUES(service_cost)
            ");
            $stmt->bind_param("iidid",$doctor_id,$consult_duration,$consult_cost,$service_duration,$service_cost);
            $stmt->execute();
            $stmt->close();

            // B: schedules (delete then insert)
            $stmt = prepare_or_throw("DELETE FROM doctor_schedules WHERE doctor_id = ?");
            $stmt->bind_param("i",$doctor_id);
            $stmt->execute();
            $stmt->close();

            $stmt_ins = prepare_or_throw("INSERT INTO doctor_schedules (doctor_id, day_of_week, start_time, end_time, schedule_type) VALUES (?, ?, ?, ?, 'individual')");
            $working_days_post = $_POST['day_working'] ?? [];

            foreach ($days_of_week_full as $day) {
                $day_key = strtolower($day);
                if (!isset($working_days_post[$day_key])) continue;
                $start_times = $_POST[$day_key.'_start_time'] ?? [];
                $end_times = $_POST[$day_key.'_end_time'] ?? [];
                if (!is_array($start_times)) $start_times = [$start_times];
                if (!is_array($end_times)) $end_times = [$end_times];
                $count = max(count($start_times),count($end_times));
                for ($i=0;$i<$count;$i++){
                    $s = trim($start_times[$i] ?? '');
                    $e = trim($end_times[$i] ?? '');
                    if ($s === '' || $e === '') continue;
                    $s_sql = date('H:i:s', strtotime($s));
                    $e_sql = date('H:i:s', strtotime($e));
                    $stmt_ins->bind_param("isss",$doctor_id,$day_key,$s_sql,$e_sql);
                    $stmt_ins->execute();
                }
            }
            $stmt_ins->close();

            // C: exception
            $edit_avail_id = filter_input(INPUT_POST,'edit_avail_id',FILTER_VALIDATE_INT);
            $raw_date = $_POST['new_avail_date'] ?? '';
            $new_avail_date_sql = parse_date_input_to_sql($raw_date);
            if (!empty($new_avail_date_sql)) {
                $new_avail_start = filter_input(INPUT_POST,'new_avail_start',FILTER_SANITIZE_STRING) ?: '09:00';
                $new_avail_end = filter_input(INPUT_POST,'new_avail_end',FILTER_SANITIZE_STRING) ?: '17:00';
                $new_avail_start = date('H:i:s', strtotime($new_avail_start));
                $new_avail_end = date('H:i:s', strtotime($new_avail_end));
                $new_is_available = filter_input(INPUT_POST,'new_is_available',FILTER_VALIDATE_INT);
                if ($new_is_available === null) $new_is_available = 1;
                $new_reason = filter_input(INPUT_POST,'new_reason',FILTER_SANITIZE_STRING) ?? null;

                if ($edit_avail_id) {
                    $stmt = prepare_or_throw("UPDATE doctor_availability SET available_date=?, start_time=?, end_time=?, is_available=?, reason=? WHERE availability_id=? AND doctor_id=?");
                    $stmt->bind_param("sssisii",$new_avail_date_sql,$new_avail_start,$new_avail_end,$new_is_available,$new_reason,$edit_avail_id,$doctor_id);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    $stmt = prepare_or_throw("
                        INSERT INTO doctor_availability (doctor_id, available_date, start_time, end_time, is_available, reason)
                        VALUES (?, ?, ?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE start_time = VALUES(start_time), end_time = VALUES(end_time), is_available = VALUES(is_available), reason = VALUES(reason)
                    ");
                    $stmt->bind_param("isssis",$doctor_id,$new_avail_date_sql,$new_avail_start,$new_avail_end,$new_is_available,$new_reason);
                    $stmt->execute();
                    $stmt->close();
                }
            }

            // D: doctor_services from schedule form (optional - only if table exists)
            if (table_exists('doctor_services')) {
                $selected_services = $_POST['services_assignment'] ?? [];
                if (!is_array($selected_services)) $selected_services = [$selected_services];
                $clean_ids = [];
                foreach ($selected_services as $sid) { $sid = (int)$sid; if ($sid>0) $clean_ids[$sid] = true; }
                $clean_ids = array_keys($clean_ids);

                $stmt = prepare_or_throw("DELETE FROM doctor_services WHERE doctor_id = ?");
                $stmt->bind_param("i",$doctor_id);
                $stmt->execute();
                $stmt->close();

                if (!empty($clean_ids)) {
                    $stmt = prepare_or_throw("INSERT INTO doctor_services (doctor_id, service_id) VALUES (?, ?)");
                    foreach ($clean_ids as $sid) {
                        $stmt->bind_param("ii",$doctor_id,$sid);
                        $stmt->execute();
                    }
                    $stmt->close();
                }
            }

            $conn->commit();
            $message = "✅ Schedule saved for Dr. " . htmlspecialchars($doctors[$doctor_id] ?? 'N/A') . ".";
            header("Location: clinic_schedule_admin.php?doctor_id=".$doctor_id);
            exit();
        } catch (Exception $e) {
            $conn->rollback();
            $message = "❌ Error saving schedule: ".htmlspecialchars($e->getMessage());
        }
    }
}

// --- Load existing schedule/config/availability for display ---
$loaded_schedules_map = [];
$loaded_consult_duration = 30;
$loaded_consult_cost = 50.00;
$loaded_service_duration = 60;
$loaded_service_cost = 100.00;
$date_exceptions = [];
$date_exceptions_map = [];

if ($doctor_id > 0) {
    try {
        $stmt = prepare_or_throw("SELECT consult_duration, consult_cost, service_duration, service_cost FROM doctor_config WHERE doctor_id = ?");
        $stmt->bind_param("i",$doctor_id);
        $stmt->execute();
        $cfg = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($cfg) {
            $loaded_consult_duration = $cfg['consult_duration'] ?? $loaded_consult_duration;
            $loaded_consult_cost = $cfg['consult_cost'] ?? $loaded_consult_cost;
            $loaded_service_duration = $cfg['service_duration'] ?? $loaded_service_duration;
            $loaded_service_cost = $cfg['service_cost'] ?? $loaded_service_cost;
        }
    } catch (Exception $e) {
        // ignore
    }

    // schedules
    try {
        $stmt = prepare_or_throw("SELECT schedule_id, day_of_week, start_time, end_time FROM doctor_schedules WHERE doctor_id = ? ORDER BY FIELD(day_of_week,'monday','tuesday','wednesday','thursday','friday','saturday','sunday'), start_time ASC");
        $stmt->bind_param("i",$doctor_id);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        foreach ($rows as $r) {
            $d = $r['day_of_week'];
            if (!isset($loaded_schedules_map[$d])) $loaded_schedules_map[$d] = [];
            $loaded_schedules_map[$d][] = ['schedule_id'=>$r['schedule_id'],'start'=>$r['start_time'],'end'=>$r['end_time']];
        }
    } catch (Exception $e) {
        // ignore
    }

    // exceptions
    try {
        $stmt = prepare_or_throw("SELECT availability_id, available_date, start_time, end_time, is_available, reason FROM doctor_availability WHERE doctor_id = ? ORDER BY available_date ASC");
        $stmt->bind_param("i",$doctor_id);
        $stmt->execute();
        $date_exceptions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        foreach ($date_exceptions as $ex) $date_exceptions_map[$ex['available_date']] = $ex;
    } catch (Exception $e) {
        // ignore
    }

    // doctor_services mapping (reload) - optional
    $doctor_services_map = [];
    if (table_exists('doctor_services')) {
        try {
            $stmt = prepare_or_throw("SELECT service_id FROM doctor_services WHERE doctor_id = ?");
            $stmt->bind_param("i",$doctor_id);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($r = $res->fetch_assoc()) $doctor_services_map[(int)$r['service_id']] = true;
            $stmt->close();
        } catch (Exception $e) { /* ignore */ }
    }
}

function get_day_schedule_status($date,$weekly_schedule_map,$exceptions_map) {
    $date_formatted = date('Y-m-d',strtotime($date));
    $day_of_week = strtolower(date('l',strtotime($date)));
    if (isset($exceptions_map[$date_formatted])) {
        $ex = $exceptions_map[$date_formatted];
        if ($ex['is_available'] == 0) return ['status'=>'DAY OFF','start'=>null,'end'=>null,'reason'=>htmlspecialchars($ex['reason'] ?? 'Unavailable')];
        return ['status'=>'Override','start'=>date('H:i',strtotime($ex['start_time'])),'end'=>date('H:i',strtotime($ex['end_time'])),'reason'=>htmlspecialchars($ex['reason'] ?? 'Override Schedule')];
    }
    if (isset($weekly_schedule_map[$day_of_week]) && count($weekly_schedule_map[$day_of_week])>0) {
        $ranges = $weekly_schedule_map[$day_of_week];
        $earliest = null; $latest = null;
        foreach ($ranges as $r) { $s = strtotime($r['start']); $e = strtotime($r['end']); if ($earliest===null || $s<$earliest) $earliest=$s; if ($latest===null||$e>$latest) $latest=$e; }
        return ['status'=>'Working','start'=>date('H:i',$earliest),'end'=>date('H:i',$latest),'reason'=>null];
    }
    return ['status'=>'Rest Day','start'=>null,'end'=>null,'reason'=>null];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Secretary Dashboard - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    html {
        scroll-behavior: smooth;
    }

    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background: #e6f0ff;
        color: #003366;
        height: 100vh;
        display: flex;
    }

    .sidebar {
        width: 220px;
        background: linear-gradient(to bottom, #3399ff, #0066cc);
        padding: 20px;
        color: white;
        box-shadow: 2px 0 10px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
    }

    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        font-weight: 700;
        user-select: none;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }

    .sidebar a {
        display: block;
        padding: 12px 20px;
        margin: 10px 0;
        color: #cce0ff;
        text-decoration: none;
        border-left: 4px solid transparent;
        font-weight: 600;
        transition: background-color 0.3s ease, border-left-color 0.3s ease;
    }
    .sidebar a:hover,
    .sidebar a.active {
        background-color: rgba(255,255,255,0.15);
        color: white;
        border-left: 4px solid #ffcc00;
    }

    .main-content {
        flex: 1;
        padding: 40px;
        background: white;
        overflow-y: auto;
    }

    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }
    header h1 {
        font-size: 2rem;
        color: #004080;
        text-shadow: 1px 1px 2px #a3c2ff;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .welcome {
        font-size: 1.3rem;
        margin-bottom: 2rem;
        font-weight: 600;
    }

    .widgets {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 30px;
    }

    .widget {
        background: #f0f7ff;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        text-align: left;
        cursor: pointer;
        transition: transform 0.3s ease, background-color 0.3s ease;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }
    .widget:hover {
        transform: translateY(-5px);
        background-color: #d9e8ff;
    }

    .widget i {
        font-size: 36px;
        color: #004080;
        margin-bottom: 10px;
    }

    .widget .title {
        font-size: 18px;
        font-weight: 700;
        color: #003366;
    }

    .widget .value {
        font-size: 40px;
        font-weight: 900;
        color: #004080;
    }

    .widget .subtitle {
        font-size: 14px;
        color: #666;
        font-weight: 500;
    }
    
</style>
</head>
<body>
<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="admin_dashboard.php" ><i class="fas fa-home"></i> Dashboard</a>
    <a href="manage_accounts.php"><i class="fas fa-users-cog"></i> Manage Accounts</a>
    <a href="clinic_services_admin.php"><i class="fas fa-tools"></i> Clinic Services</a>
    <a href="generate_reports.php"><i class="fas fa-chart-line"></i> Generate Reports</a>
    <a href="payment_module.php"><i class="fas fa-money-check-dollar"></i> Payment Module</a>
    <a href="clinic_schedule_admin.php" class="active"><i class="fas fa-calendar-check"></i> Clinic Schedule</a>
    <a href="admin_settings.php"><i class="fas fa-gear"></i> System Settings</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>
    <main class="main-content">
        <header>
            <h1><i class="fas fa-calendar-check"></i> Appointments</h1>
        </header>

        
        <?php include '../calendar_function/admin_calendar.php'; ?>
        </div>
    </main>
</body>
</html>
