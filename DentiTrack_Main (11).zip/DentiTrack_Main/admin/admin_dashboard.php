<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

include '../config/db.php'; // expects $conn (mysqli)

// helper
function safe($v) { return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }

// Initialize metrics
$total_users_count = $admin_count = $upcoming_appointments = $clinics_count = 0;
$total_revenue = 0.00;
$total_expenses = 0.00;
$total_net_income = 0.00; // New variable for Net Income
$top_services = [];

if ($conn) {
    // 1) Users counts
    $sql = "SELECT 
                SUM(role IN ('patient','secretary','doctor')) AS total_users_count, 
                SUM(role = 'admin') AS admin_count
            FROM users";
    if ($res = $conn->query($sql)) {
        $row = $res->fetch_assoc();
        $total_users_count = (int)($row['total_users_count'] ?? 0);
        $admin_count = (int)($row['admin_count'] ?? 0);
        $res->free();
    }

    // 2) Clinics count (Still fetched but won't be displayed in the widget row)
    $sql = "SELECT COUNT(*) AS cnt FROM clinics";
    if ($res = $conn->query($sql)) {
        $row = $res->fetch_assoc();
        $clinics_count = (int)($row['cnt'] ?? 0);
        $res->free();
    }

    // 3) Upcoming appointments (from today)
    $sql = "SELECT COUNT(*) AS cnt FROM appointments WHERE appointment_date >= CURDATE()";
    if ($res = $conn->query($sql)) {
        $row = $res->fetch_assoc();
        $upcoming_appointments = (int)($row['cnt'] ?? 0);
        $res->free();
    }

    // 4) Total revenue (payments) - adjust column/table names if your schema differs
    // assumes payments.amount and payments.status (paid/completed)
    $sql = "SELECT IFNULL(SUM(amount),0) AS total_revenue FROM payments WHERE status IN ('paid','completed')";
    if ($res = $conn->query($sql)) {
        $row = $res->fetch_assoc();
        $total_revenue = (float)($row['total_revenue'] ?? 0);
        $res->free();
    }

    // 5) Total expenses - assumes an expenses table with amount column
    $sql = "SELECT IFNULL(SUM(amount),0) AS total_expenses FROM expenses";
    if ($res = $conn->query($sql)) {
        $row = $res->fetch_assoc();
        $total_expenses = (float)($row['total_expenses'] ?? 0);
        $res->free();
    }
    
    // Calculate Net Income (Total Revenue - Total Expenses)
    $total_net_income = $total_revenue - $total_expenses;

    // 6) Top services/procedures in last 30 days based on appointments count
    // The original query correctly bases this on appointments count (COUNT(a.id))
    $sql = "SELECT s.name AS service_name, COUNT(a.id) AS cnt
            FROM appointments a
            LEFT JOIN services s ON a.service_id = s.id
            WHERE a.service_id IS NOT NULL 
            -- WHERE a.appointment_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) -- (You can uncomment this line if you still want the 30-day filter)
            GROUP BY s.id, s.name
            ORDER BY cnt DESC
            LIMIT 5";
    if ($res = $conn->query($sql)) {
        while ($row = $res->fetch_assoc()) {
            $top_services[] = [
                'name' => $row['service_name'] ?? 'Unknown',
                'count' => (int)($row['cnt'] ?? 0)
            ];
        }
        $res->free();
    }
}

// admin username
$admin_username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> Dashboard - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
/* --- STYLES (Unchanged) --- */
html { scroll-behavior: smooth; }
body {
    margin: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #e6f0ff;
    color: #003366;
    display: flex;
    min-height: 100vh;
}
/* Sidebar */
.sidebar {
    width: 220px;
    background: linear-gradient(to bottom, #3399ff, #0066cc);
    padding: 20px 0;
    color: white;
    display: flex;
    flex-direction: column;
}
.sidebar h2 {
    text-align: center;
    margin-bottom: 30px;
    font-size: 24px;
    font-weight: 700;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
}
.sidebar a {
    display: block;
    padding: 14px 24px;
    margin: 10px 15px;
    color: #cce0ff;
    text-decoration: none;
    border-left: 4px solid transparent;
    font-weight: 600;
    font-size: 15px;
    border-radius: 6px;
    transition: all 0.3s ease;
}
.sidebar a i { margin-right: 10px; }
.sidebar a:hover, .sidebar a.active {
    background-color: rgba(255,255,255,0.2);
    color: #fff;
    border-left: 4px solid #ffcc00;
}

main.main-content {
    flex: 1;
    padding: 40px 60px;
    background: #f8faff;
    overflow-y: auto;
    box-sizing: border-box;
}

header h1 {
    font-size: 2.2rem;
    color: #004080;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.widgets {
    display: grid;
    /* Adjusted grid to fit 3 widgets per row instead of 4 */
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); 
    gap: 25px;
    margin-bottom: 40px;
}

.widget {
    background: white;
    padding: 25px 20px;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    text-align: left;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
    gap: 6px;
}
.widget:hover {
    transform: translateY(-6px);
    box-shadow: 0 12px 25px rgba(0,0,0,0.12);
    background: #e0f0ff;
}

.widget i {
    font-size: 45px;
    color: #004080;
}
.widget .title {
    font-size: 18px;
    font-weight: 700;
    color: #003366;
}
.widget .value {
    font-size: 42px;
    font-weight: 900;
    color: #0077b6;
}
.widget .subtitle {
    font-size: 13px;
    color: #555;
    font-weight: 500;
}

.chart-container {
    background:white;
    padding:20px;
    border-radius:12px;
    box-shadow:0 8px 20px rgba(0,0,0,0.08);
    margin-bottom: 20px;
}

.chart-filter label {
    font-weight:600;
    margin-right:5px;
}
.chart-filter input {
    padding:5px;
    margin-right:10px;
    border-radius:5px;
    border:1px solid #ccc;
}
.chart-filter button {
    padding:5px 10px;
    border:none;
    border-radius:5px;
    background:#007bff;
    color:white;
    cursor:pointer;
}
.chart-filter button:hover { background:#006ae3; }

.top-row-extras {
    display: grid;
    grid-template-columns: 1fr 320px;
    gap: 20px;
}

/* Top services card to match existing design */
.services-card {
    background: white;
    padding: 18px;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}
.services-card h4 { margin: 0 0 10px 0; color: #003366; }
.services-list { list-style: none; padding: 0; margin: 0; }
.services-list li { padding: 8px 0; border-bottom: 1px solid #f1f6fb; display:flex; justify-content:space-between; color:#555; }

/* Responsive */
@media(max-width: 768px) {
    main.main-content { padding: 20px; }
    .widgets { grid-template-columns: 1fr 1fr; gap: 20px; }
    .top-row-extras { grid-template-columns: 1fr; }
}
@media(max-width: 480px) {
    .widgets { grid-template-columns: 1fr; gap: 15px; }
}
</style>
</head>
<body>
<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="admin_dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a>
    <a href="manage_accounts.php"><i class="fas fa-users-cog"></i> Manage Accounts</a>
    <a href="clinic_services_admin.php"><i class="fas fa-tools"></i> Clinic Services</a>
    <a href="generate_reports.php"><i class="fas fa-chart-line"></i> Generate Reports</a>
    <a href="payment_module.php"><i class="fas fa-money-check-dollar"></i> Payment Module</a>
    <a href="clinic_schedule_admin.php"><i class="fas fa-calendar-check"></i> Clinic Schedule</a>
    <a href="admin_settings.php"><i class="fas fa-gear"></i> System Settings</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">
    <header>
       
    </header>

    <div class="widgets">
        
        <div class="widget" onclick="location.href='manage_accounts.php'">
            <i class="fas fa-users"></i>
            <div class="title">Total Users</div>
            <div class="value"><?= $total_users_count ?></div>
            <div class="subtitle">Patients, Doctors, Secretaries, Admins </div>
        </div>

        <div class="widget" onclick="location.href='appointments.php'">
            <i class="fas fa-calendar-check"></i>
            <div class="title">Upcoming Appointments</div>
            <div class="value"><?= $upcoming_appointments ?></div>
            <div class="subtitle">Appointments scheduled from today</div>
        </div>

        <div class="widget" onclick="location.href='payment_module.php'">
            <i class="fas fa-sack-dollar"></i>
            <div class="title">Total Revenue</div>
            <div class="value"><?= '₱' . number_format($total_revenue, 2) ?></div>
            <div class="subtitle">Completed patient payments</div>
        </div>
        
        </div>

    <div class="top-row-extras">
        <div class="chart-container">
            <h3>Appointments Analytics</h3>
            <div class="chart-filter" style="margin-bottom:15px;">
                <label for="filterStart">Start Date:</label>
                <input type="date" id="filterStart" name="filterStart">
                <label for="filterEnd" style="margin-left:15px;">End Date:</label>
                <input type="date" id="filterEnd" name="filterEnd">
                <button id="applyFilter"><i class="fas fa-filter"></i> Apply</button>
            </div>
            <canvas id="appointmentsChart" height="100"></canvas>
        </div>

        <div class="services-card">
            <h4>Top Services (Based on Appointments)</h4>
            <?php if (count($top_services)): ?>
                <ul class="services-list">
                    <?php foreach ($top_services as $s): ?>
                        <li>
                            <span><?= safe($s['name']) ?></span>
                            <strong style="color:#0077b6"><?= $s['count'] ?></strong>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <div class="subtitle">No services booked recently.</div>
            <?php endif; ?>

            <hr style="margin:12px 0;border:none;border-top:1px solid #f1f6fb">
            <div>
                <div style="font-size:14px;color:#003366;font-weight:700">Net Income (Revenue - Expenses)</div>
                <div style="font-size:20px;color:#0077b6;font-weight:800"><?= '₱' . number_format($total_net_income, 2) ?></div>
                <div style="font-size:12px;color:#555;margin-top:6px">Expenses: <?= '₱' . number_format($total_expenses, 2) ?></div>
            </div>
        </div>
    </div>

</main>

<script>
let ctx = document.getElementById('appointmentsChart').getContext('2d');
let appointmentsChart = new Chart(ctx, {
    type: 'bar',
    data: { labels: [], datasets: [{ label: 'Appointments', data: [], backgroundColor: '#007bff' }] },
    options: { responsive:true, plugins: { legend: { display: false } } }
});

// Fetch initial chart
function fetchChart(start='', end=''){
    fetch('dashboard_chart_data.php', {
        method: 'POST',
        headers: { 'Content-Type':'application/json' },
        body: JSON.stringify({ start_date:start, end_date:end })
    }).then(res => res.json())
      .then(data => {
          appointmentsChart.data.labels = data.labels;
          appointmentsChart.data.datasets[0].data = data.data;
          appointmentsChart.update();
      }).catch(err => {
          console.error('Chart fetch error', err);
      });
}

// Initial load
fetchChart();

document.getElementById('applyFilter').addEventListener('click', function(){
    const start = document.getElementById('filterStart').value;
    const end = document.getElementById('filterEnd').value;
    fetchChart(start, end);
});
</script>
</body>
</html>