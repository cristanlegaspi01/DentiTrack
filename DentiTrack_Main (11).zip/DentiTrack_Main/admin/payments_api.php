<?php
// payments_api.php
// API endpoint to fetch detailed payment/receipt data by ID for the modal viewer.

define('DEBUG', true);
if (DEBUG) { ini_set('display_errors','1'); error_reporting(E_ALL); }

header('Content-Type: application/json');
session_start();

// Security Check: Only logged-in admins can access this data
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied. Administrator session required.']);
    exit();
}

// NOTE: Ensure your database connection file path is correct.
include '../config/db.php'; // expects $conn (mysqli)

// Function to send a standardized error response and exit
function api_error($message, $code = 400) {
    global $conn;
    if ($conn) $conn->close();
    http_response_code($code);
    echo json_encode(['error' => $message]);
    exit();
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!isset($data['action']) || $data['action'] !== 'detail') {
    api_error('Invalid action specified.');
}

$payment_id = (int)($data['id'] ?? 0);

if ($payment_id <= 0) {
    api_error('Invalid or missing payment ID.', 400);
}

// --- Dynamic Query Construction ---

// Standard required columns based on payment_module.php
$cols = [
    'payment_id', 'amount', 'total_amount', 'created_at',
    'patient_id', 'payer_name', 'email', 'payment_method', 
    'status', 'invoice_no', 'currency', 'payment_date', 
    'discount_type', 'discount_amount',
    // We add fields the receipt viewer expects, even if they aren't in the main table list
    'service_name', 'supplies_used' 
];

// If you have fields for cash received or patient names from another table, 
// you would join them here. For simplicity, we assume all needed fields 
// are in the 'payments' table, and add placeholders for commonly requested fields.

$select_fields = [];
$missing_cols = [];

// Use INFORMATION_SCHEMA check to build a safe SELECT list
// In a real environment, you'd perform this check once on setup.
try {
    $dbNameResult = $conn->query("SELECT DATABASE()");
    $dbName = $dbNameResult ? $dbNameResult->fetch_row()[0] : null;
    $dbNameResult->free();
} catch (Throwable $e) {
    api_error('Database name query failed: ' . $e->getMessage());
}


foreach ($cols as $col) {
    $sql_check = "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE 
                  TABLE_SCHEMA = ? AND 
                  TABLE_NAME = 'payments' AND 
                  COLUMN_NAME = ? LIMIT 1";
    
    if ($stmt_check = $conn->prepare($sql_check)) {
        $stmt_check->bind_param('ss', $dbName, $col);
        $stmt_check->execute();
        $res = $stmt_check->get_result();
        
        if ($res->num_rows > 0) {
            $select_fields[] = "`$col`";
        } else {
            // Add a placeholder/NULL if the column is missing but needed for JSON structure
            $select_fields[] = "NULL AS `$col`";
            $missing_cols[] = $col;
        }
        $stmt_check->close();
    }
}

// Fallback if no specific fields could be confirmed
if (empty($select_fields)) {
     api_error('Failed to confirm any columns in the payments table.', 500);
}

$select_sql = implode(', ', $select_fields);

// --- Main Query Execution ---

$sql = "SELECT $select_sql FROM `payments` WHERE `payment_id` = ?";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param('i', $payment_id);
    
    if (!$stmt->execute()) {
        api_error('Database query failed: ' . $stmt->error, 500);
    }
    
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        // --- Add placeholders for UI fields not guaranteed by the DB schema ---
        // These are required by the JS receipt viewer
        $row['receipt_title'] = 'OFFICIAL PAYMENT RECEIPT';
        // Mocked fields often retrieved from other tables or calculation
        $row['first_name'] = $row['payer_name']; // Use payer_name as first_name placeholder
        $row['last_name'] = '';
        $row['payment_option'] = 'Full Payment'; // Example value
        $row['cash_received'] = $row['total_amount']; // Assume cash received equals total due for simplicity
        // ---------------------------------------------------------------------
        
        // Success: Return the row as JSON
        http_response_code(200);
        echo json_encode(['success' => true, 'data' => $row]);
        
    } else {
        api_error('Payment record not found.', 404);
    }
    
    $stmt->close();
    
} else {
    api_error('Failed to prepare query: ' . $conn->error, 500);
}

$conn->close();

?>