<?php
// clinic_services_admin.php
// Master Services CRUD UI (Standalone - No Doctor Assignment Logic)

session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php'); // <-- FIX APPLIED HERE
    exit();
}

include '../config/db.php'; // mysqli $conn
include '../config/settings_loader.php';

$message = '';
$search_term = $_GET['service_search'] ?? ''; // Get the search term
$upload_dir_base = __DIR__ . '/../uploads/service_images/';
$web_upload_path = 'uploads/service_images/'; // Relative path for web access

// --- Helper Functions ---
/**
 * Prepares a mysqli statement or throws an exception on failure.
 * @param string $sql The SQL query string.
 * @return mysqli_stmt The prepared statement object.
 * @throws Exception If preparation fails.
 */
function prepare_or_throw($sql) {
    global $conn;
    $stmt = $conn->prepare($sql);
    if ($stmt === false) throw new Exception("MySQL prepare() failed: " . $conn->error . " -- SQL: " . $sql);
    return $stmt;
}

/**
 * Checks if a given table exists in the database.
 * @param string $table The name of the table to check.
 * @return bool True if the table exists, false otherwise.
 */
function table_exists($table) {
    global $conn;
    $t = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$t}'");
    return ($res && $res->num_rows > 0);
}

// --- Load and Filter services master (NO doctor assignments) ---
$services_master = [];

if (table_exists('services')) {
    try {
        // Query now selects the new 'image_path' column
        $sql = "
            SELECT 
                service_id, service_name, category, description, price, duration, image_path, status, created_at
            FROM services s
        ";
        
        $params = [];
        $types = "";
        
        // Add WHERE clause if a search term is present
        if (!empty($search_term)) {
            $sql .= " WHERE service_name LIKE ? OR category LIKE ? OR description LIKE ?";
            $search_like = "%" . $search_term . "%";
            $params = [$search_like, $search_like, $search_like];
            $types = "sss";
        }
        
        $sql .= " ORDER BY service_id ASC";

        $stmt = prepare_or_throw($sql);
        
        if (!empty($types)) {
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();
        $res = $stmt->get_result();

        // Load services directly without doctor aggregation
        while ($r = $res->fetch_assoc()) {
            $services_master[] = $r;
        }

        $stmt->close();
    } catch (Exception $e) {
        $message = "Error loading services: " . htmlspecialchars($e->getMessage());
    }
}

// --- POST handling (services CRUD + duplication check) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['service_action'])) {
        $action = $_POST['service_action'];
        
        if ($action === 'save_master_service') {
            $sid = isset($_POST['master_service_id']) ? (int)$_POST['master_service_id'] : 0;
            $name = trim($_POST['master_service_name'] ?? '');
            $category = trim($_POST['master_category'] ?? '');
            $description = trim($_POST['master_description'] ?? '');
            $price = isset($_POST['master_price']) ? (float)$_POST['master_price'] : 0.0;
            $duration = trim($_POST['master_duration'] ?? '');
            $status = (($_POST['master_status'] ?? 'active') === 'active') ? 'active' : 'inactive';
            $delete_image = isset($_POST['delete_current_image']) ? true : false;
            
            $image_path = ''; // Will hold the final path to save to DB

            if ($name === '') {
                $message = "Service name required.";
            } else {
                try {
                    // --- DUPLICATE CHECK LOGIC ---
                    $duplicate_check_sql = "SELECT service_id FROM services WHERE service_name = ? AND service_id != ?";
                    $stmt_check = prepare_or_throw($duplicate_check_sql);
                    $stmt_check->bind_param("si", $name, $sid);
                    $stmt_check->execute();
                    $stmt_check->store_result();
                    
                    if ($stmt_check->num_rows > 0) {
                        $message = "❌ Error: A service with the name **" . htmlspecialchars($name) . "** already exists. Please choose a unique name.";
                        $stmt_check->close();
                    } else {
                        $stmt_check->close();

                        // 1. Fetch existing image path if updating or deleting
                        $existing_image_path = '';
                        if ($sid > 0) {
                            $stmt_old_img = prepare_or_throw("SELECT image_path FROM services WHERE service_id = ?");
                            $stmt_old_img->bind_param("i", $sid);
                            $stmt_old_img->execute();
                            $stmt_old_img->bind_result($existing_image_path);
                            $stmt_old_img->fetch();
                            $stmt_old_img->close();
                            $image_path = $existing_image_path; // Keep existing path by default
                        }

                        // 2. Handle image deletion request
                        if ($delete_image) {
                            // Prepend base directory for filesystem operations
                            $full_old_path = $upload_dir_base . basename($existing_image_path);
                            if (!empty($existing_image_path) && file_exists($full_old_path)) {
                                @unlink($full_old_path); // Use @ to suppress file permission errors
                            }
                            $image_path = ''; // Clear path in DB
                        }

                        // 3. Handle new file upload
                        $uploaded_file = $_FILES['master_service_image'] ?? null;
                        
                        if ($uploaded_file && $uploaded_file['error'] === UPLOAD_ERR_OK) {
                            // Ensure upload directory exists and is writable
                            if (!is_dir($upload_dir_base)) {
                                if (!mkdir($upload_dir_base, 0777, true)) {
                                    throw new Exception("Failed to create upload directory: " . $upload_dir_base);
                                }
                            }

                            $allowed_types = ['image/jpeg', 'image/png', 'image/webp'];
                            if (in_array($uploaded_file['type'], $allowed_types) && $uploaded_file['size'] <= 5000000) { // 5MB limit
                                
                                // Delete old image if a new one is replacing it AND it wasn't already deleted via checkbox
                                if ($sid > 0 && !empty($existing_image_path) && !$delete_image) {
                                    $full_old_path = $upload_dir_base . basename($existing_image_path);
                                    if (file_exists($full_old_path)) {
                                        @unlink($full_old_path); // Use @ to suppress file permission errors
                                    }
                                }
                                
                                // Generate a unique file name
                                $extension = pathinfo($uploaded_file['name'], PATHINFO_EXTENSION);
                                $file_name = uniqid('svc_') . '.' . $extension;
                                $target_file = $upload_dir_base . $file_name;
                                
                                if (move_uploaded_file($uploaded_file['tmp_name'], $target_file)) {
                                    // Store the path relative to the web root in the DB
                                    $image_path = $web_upload_path . $file_name; 
                                } else {
                                    throw new Exception("File upload failed to move file. Check permissions.");
                                }
                            } else {
                                throw new Exception("Invalid file type or size. Only JPG, PNG, WEBP up to 5MB allowed.");
                            }
                        } // End file upload logic

                        // 4. Save/Update Service in DB
                        if ($sid > 0) {
                            // Update existing service
                            $stmt = prepare_or_throw("UPDATE services SET service_name=?, category=?, description=?, price=?, duration=?, status=?, image_path=? WHERE service_id=?");
                            $stmt->bind_param("sssdsssi", $name, $category, $description, $price, $duration, $status, $image_path, $sid);
                            if ($stmt->execute()) $message = "✅ Master service updated successfully.";
                            else $message = "Error updating service: ".$stmt->error;
                            $stmt->close();
                        } else {
                            // Insert new service
                            $stmt = prepare_or_throw("INSERT INTO services (service_name, category, description, price, duration, status, image_path, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
                            $stmt->bind_param("sssdsss", $name, $category, $description, $price, $duration, $status, $image_path);
                            if ($stmt->execute()) $message = "✅ Master service created successfully.";
                            else $message = "Error creating service: ".$stmt->error;
                            $stmt->close();
                        }
                    }
                } catch (Exception $e) {
                    $message = "❌ Service save error: " . htmlspecialchars($e->getMessage());
                }
            }
        }

        if ($action === 'delete_master_service') {
            $sid = isset($_POST['master_service_id']) ? (int)$_POST['master_service_id'] : 0;
            if ($sid > 0) {
                try {
                    // Fetch image path before deletion
                    $stmt_old_img = prepare_or_throw("SELECT image_path FROM services WHERE service_id = ?");
                    $stmt_old_img->bind_param("i", $sid);
                    $stmt_old_img->execute();
                    $stmt_old_img->bind_result($existing_image_path);
                    $stmt_old_img->fetch();
                    $stmt_old_img->close();

                    // Delete from main services table
                    $stmt = prepare_or_throw("DELETE FROM services WHERE service_id = ?");
                    $stmt->bind_param("i",$sid);
                    
                    if ($stmt->execute()) {
                        // Delete the physical image file
                        $full_old_path = $upload_dir_base . basename($existing_image_path);
                        if (!empty($existing_image_path) && file_exists($full_old_path)) {
                            @unlink($full_old_path); // Use @ to suppress file permission errors
                        }

                        // Cleanup assignments in doctor_services table (if it exists)
                        if (table_exists('doctor_services')) {
                            $stmt2 = prepare_or_throw("DELETE FROM doctor_services WHERE service_id = ?");
                            $stmt2->bind_param("i",$sid);
                            $stmt2->execute();
                            $stmt2->close();
                        }
                        $message = "✅ Master service deleted.";
                    } else $message = "Error deleting service: ".$stmt->error;
                    $stmt->close();
                } catch (Exception $e) {
                    $message = "DB error deleting service: " . htmlspecialchars($e->getMessage());
                }
            }
        }
    }
    
    // Redirect after POST to prevent form resubmission and reflect changes
    header("Location: clinic_services_admin.php" . (!empty($search_term) ? "?service_search=" . urlencode($search_term) : ""));
    exit();
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Services - Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    
    /* --- Global & Layout Styles --- */
    body { 
        margin:0; 
        font-family: <?= htmlspecialchars(getSetting('font_family','Inter, sans-serif')) ?>; 
        background:#e6f0ff; 
        color:#003366; 
        display:flex; 
        min-height:100vh; 
    }
    
    /* --- Sidebar Styling (Applying provided gradient + dynamic settings) --- */
    .sidebar { 
        width:235px; /* Increased from 220px to match the provided code's preference but using the defined style */
        /* Applying the requested gradient, overriding dynamic sidebar_bg for this page/element */
        background: linear-gradient(to bottom, #3399ff, #0066cc); 
        padding:20px 12px; 
        color:<?= htmlspecialchars(getSetting('sidebar_text','#ffffff')) ?>; 
        display:flex; 
        flex-direction:column; 
        box-shadow:4px 0 10px rgba(0,0,0,0.1); 
    }
    
 .sidebar h2 {
        text-align: center;
        margin-bottom: 25px;
        font-size: 24px;
        font-weight: 700;
    }
    
    .sidebar a {
        display: block;
        padding: 14px 24px;
        margin: 8px 15px;
        color: #cce0ff;
        text-decoration: none;
        font-weight: 600;
        font-size: 15px;
        border-left: 4px solid transparent;
        border-radius: 6px;
        transition: all 0.3s ease;
    }
    
    .sidebar a i { margin-right: 10px; }
    .sidebar a:hover, .sidebar a.active {
        background-color: rgba(255,255,255,0.2);
        color: #fff;
        border-left: 4px solid #ffcc00;
    }

    
    main.main-content { 
        flex:1; 
        padding:10px 20px; 
        background:#f8faff; 
        overflow:auto; 
    }
    
    .card-panel { 
        background:#fff; 
        padding:20px; 
        border-radius:12px; 
        box-shadow:0 8px 30px rgba(0,0,0,0.05); 
    }

    /* --- REVISED TABLE STYLES (Full Width Optimization) --- */
    .table-clean {
        width: 100%;
        border-collapse: separate; 
        border-spacing: 0 6px; 
    }
    .table-clean thead th {
        background-color: #007bff; 
        color: white;
        border: none;
        padding: 10px 15px; 
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        position: sticky; 
        top: 0;
        z-index: 10;
        white-space: nowrap; 
    }
    .table-clean tbody tr {
        background-color: #ffffff;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        border-radius: 6px; 
        transition: box-shadow 0.2s;
        font-size: 13px;
    }
    .table-clean tbody tr:hover {
        background-color: #f1f7ff; 
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }
    .table-clean tbody td {
        padding: 10px 15px;
        border: none;
        vertical-align: middle;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 150px; 
    }
    /* Description column is now the 5th column (Image is 4th) */
    .table-clean tbody td:nth-child(5) { 
        max-width: 300px; 
        white-space: normal; 
        line-height: 1.3;
        max-height: 40px;
        overflow: hidden;
    }

    .table-clean tbody tr td:first-child { border-top-left-radius: 6px; border-bottom-left-radius: 6px; }
    .table-clean tbody tr td:last-child { border-top-right-radius: 6px; border-bottom-right-radius: 6px; }
    
    .price-highlight {
        font-weight: 700;
        color: #28a745; 
        font-size: 1em;
    }
    
    .row { width: 100%; margin: 0; }
    .col-md-4 { padding-right: 15px; }
    .col-md-8 { width: 66%; }
    .table-responsive { max-height: 70vh; }
    
    .action-buttons-group {
        display: flex;
        gap: 5px; 
        white-space: nowrap;
    }
    
    /* New styles for image preview */
    #currentImagePreview {
        max-width: 100%;
        height: auto;
        border: 1px solid #ccc;
        border-radius: 6px;
        margin-bottom: 10px;
        max-height: 150px; /* Added max height for better form layout */
        object-fit: contain; /* Ensures the image fits without cropping much */
    }
    .service-img-thumb {
        width: 40px;
        height: 40px;
        object-fit: cover;
        border-radius: 4px;
        border: 1px solid #ddd; /* Added border for better visibility */
    }

</style>
</head>
<body>
<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="admin_dashboard.php" ><i class="fas fa-home"></i> Dashboard</a>
    <a href="manage_accounts.php"><i class="fas fa-users-cog"></i> Manage Accounts</a>
    <a href="clinic_services_admin.php" class="active"><i class="fas fa-tools"></i> Clinic Services</a>
    <a href="generate_reports.php"><i class="fas fa-chart-line"></i> Generate Reports</a>
    <a href="payment_module.php"><i class="fas fa-money-check-dollar"></i> Payment Module</a>
    <a href="clinic_schedule_admin.php"><i class="fas fa-calendar-check"></i> Clinic Schedule</a>
    <a href="admin_settings.php"><i class="fas fa-gear"></i> System Settings</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">
    <div class="card-panel">
        <div class="d-flex mb-3 align-items-center">
            <h2 class="me-3"><i class="fas fa-clipboard-list"></i> Master Services Management</h2>
            <a class="btn btn-outline-secondary btn-sm ms-auto" href="manage_accounts.php"><i class="fas fa-user-md"></i> Manage Account</a>
        </div>

        <?php if ($message): ?><div class="alert alert-info"><?= $message ?></div><?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                                        <form method="POST" id="masterServiceForm" class="p-3 border rounded shadow-sm" enctype="multipart/form-data">
                    <h5 class="mb-3"><i class="fas fa-plus-circle"></i> Add / Edit Service</h5>
                    <input type="hidden" name="service_action" value="save_master_service">
                    <input type="hidden" name="master_service_id" id="master_service_id" value="">
                    
                    <div class="mb-2"><label class="form-label small fw-bold">Service Name <span class="text-danger">*</span></label><input type="text" name="master_service_name" id="master_service_name" class="form-control form-control-sm" required></div>
                    <div class="mb-2"><label class="form-label small fw-bold">Category</label><input type="text" name="master_category" id="master_category" class="form-control form-control-sm" placeholder="e.g., General, Orthodontics"></div>
                    <div class="mb-2"><label class="form-label small fw-bold">Description</label><textarea name="master_description" id="master_description" class="form-control form-control-sm" rows="3"></textarea></div>
                    
                    <div class="row g-2">
                        <div class="col-4 mb-2"><label class="form-label small fw-bold">Price (₱)</label><input type="number" step="0.01" name="master_price" id="master_price" class="form-control form-control-sm" value="0.00"></div>
                        <div class="col-4 mb-2"><label class="form-label small fw-bold">Duration</label><input type="text" name="master_duration" id="master_duration" class="form-control form-control-sm" placeholder="e.g., 30 min"></div>
                        <div class="col-4 mb-2"><label class="form-label small fw-bold">Status</label><select name="master_status" id="master_status" class="form-select form-select-sm"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
                    </div>

                                                <div id="imageDisplayContainer" style="display:none; margin-top: 10px;">
                        <label class="form-label small fw-bold">Current Image</label>
                        <img id="currentImagePreview" src="" alt="Service Image">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="1" name="delete_current_image" id="delete_current_image">
                            <label class="form-check-label small" for="delete_current_image">
                                Delete current image on save.
                            </label>
                        </div>
                    </div>

                    <div class="mb-2 mt-3">
                        <label class="form-label small fw-bold">Service Image (JPG/PNG/WEBP, Max 5MB)</label>
                        <input type="file" name="master_service_image" id="master_service_image" class="form-control form-control-sm">
                        <div id="imageHelp" class="form-text small">Upload a new image. Will replace the existing one if present, unless 'Delete current image' is checked.</div>
                    </div>
                                                
                    <div class="d-flex gap-2 mt-3">
                        <button class="btn btn-primary btn-sm" type="submit"><i class="fas fa-save"></i> Save Service</button>
                        <button class="btn btn-outline-secondary btn-sm" type="button" onclick="clearMasterForm()"><i class="fas fa-eraser"></i> New / Clear</button>
                        <button class="btn btn-danger btn-sm ms-auto" type="button" id="deleteMasterBtn" style="display:none;" onclick="deleteMasterService()"><i class="fas fa-trash"></i> Delete</button>
                    </div>
                </form>
            </div>

            <div class="col-md-8">
                <h5 class="mb-3"><i class="fas fa-list-alt"></i> Services Catalog</h5>
                
                <form method="GET" class="mb-3">
                    <div class="input-group input-group-sm">
                        <input type="text" name="service_search" class="form-control" placeholder="Search by name, category, or description..." value="<?= htmlspecialchars($search_term) ?>">
                        <button class="btn btn-outline-primary" type="submit"><i class="fas fa-search"></i></button>
                        <?php if (!empty($search_term)): ?>
                            <a href="clinic_services_admin.php" class="btn btn-outline-danger"><i class="fas fa-times"></i> Clear</a>
                        <?php endif; ?>
                    </div>
                </form>
                
                <div class="table-responsive mb-4" style="overflow-y:auto;">
                    <table class="table table-clean"> 
                        <thead>
                            <tr>
                                <th style="width: 5%;">ID</th> 
                                <th style="width: 15%;">Service Name</th>
                                <th style="width: 10%;">Category</th>
                                <th style="width: 5%;">Image</th>                          <th style="width: 25%;">Description</th>
                                <th style="width: 10%;">Price</th>
                                <th style="width: 10%;">Duration</th>
                                <th style="width: 10%;">Status</th>
                                <th style="width: 10%;">Action</th> 
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if (empty($services_master)): ?>
                                <tr><td colspan="9" class="text-center small text-muted p-4">No services found.</td></tr>
                            <?php else: foreach ($services_master as $svc): 
                                $status_class = $svc['status'] == 'active' ? 'primary' : 'secondary';
                                // Correct image path for display on admin page (it needs to go up one directory from /admin/)
                                $image_url = !empty($svc['image_path']) ? '../' . $svc['image_path'] : 'https://placehold.co/40x40/cccccc/333333?text=N/A';
                            ?>
                                <tr>
                                    <td><?= htmlspecialchars($svc['service_id']) ?></td> 
                                    <td><?= htmlspecialchars($svc['service_name']) ?></td>
                                    <td><?= htmlspecialchars($svc['category']) ?></td>
                                                                    <td><img src="<?= htmlspecialchars($image_url) ?>" class="service-img-thumb" alt="Service Image" onerror="this.onerror=null;this.src='https://placehold.co/40x40/cccccc/333333?text=ERR';"></td>
                                    <td><?= htmlspecialchars($svc['description']) ?></td>
                                    <td class="price-highlight">₱<?= number_format($svc['price'],2) ?></td>
                                    <td><?= htmlspecialchars($svc['duration']) ?></td>
                                    <td><span class="badge bg-<?= $status_class ?>"><?= htmlspecialchars(ucfirst($svc['status'])) ?></span></td>
                                    
                                    <td class="action-col">
                                        <div class="action-buttons-group">
                                            <button class="btn btn-sm btn-outline-primary" type="button" 
                                                onclick='populateMaster(<?= json_encode($svc, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>)'
                                                title="Edit Service Details">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            
                                            <button class="btn btn-sm btn-outline-danger" type="button" 
                                                onclick="if(confirm('Are you sure you want to delete the service: <?= htmlspecialchars($svc['service_name']) ?>? This action cannot be undone.')){ 
                                                                document.getElementById('deleteForm_<?= (int)$svc['service_id'] ?>').submit();
                                                             }"
                                                title="Delete Service">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                        
                                        <form method="POST" id="deleteForm_<?= (int)$svc['service_id'] ?>" style="display:none;">
                                            <input type="hidden" name="service_action" value="delete_master_service">
                                            <input type="hidden" name="master_service_id" value="<?= (int)$svc['service_id'] ?>">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const webUploadPath = '<?= $web_upload_path ?>';

function populateMaster(s){
    // Populate the form fields with data from the selected service (s)
    document.getElementById('master_service_id').value = s.service_id || '';
    document.getElementById('master_service_name').value = s.service_name || '';
    document.getElementById('master_category').value = s.category || '';
    document.getElementById('master_description').value = s.description || '';
    // Format price to 2 decimal places
    document.getElementById('master_price').value = s.price !== null ? parseFloat(s.price).toFixed(2) : '0.00';
    document.getElementById('master_duration').value = s.duration || '';
    document.getElementById('master_status').value = s.status || 'active';
    
    // --- Image Handling in Edit Form ---
    const imageContainer = document.getElementById('imageDisplayContainer');
    const imagePreview = document.getElementById('currentImagePreview');
    const deleteCheckbox = document.getElementById('delete_current_image');
    
    // Clear file input every time
    document.getElementById('master_service_image').value = '';
    deleteCheckbox.checked = false;

    if (s.image_path) {
        // Construct the full URL for the preview (from admin/ to ../uploads/service_images/file.ext)
        const imageUrl = '../' + s.image_path; 
        imagePreview.src = imageUrl;
        imageContainer.style.display = 'block';
    } else {
        imageContainer.style.display = 'none';
        imagePreview.src = '';
    }
    // -------------------------------------

    // Show delete button when editing
    document.getElementById('deleteMasterBtn').style.display = 'inline-block';
    document.getElementById('deleteMasterBtn').dataset.id = s.service_id;
    
    // Scroll to the form
    window.scrollTo({top:0,behavior:'smooth'});
}

function clearMasterForm(){
    // Clear all form fields for adding a new service
    document.getElementById('master_service_id').value = '';
    document.getElementById('master_service_name').value = '';
    document.getElementById('master_category').value = '';
    document.getElementById('master_description').value = '';
    document.getElementById('master_price').value = '0.00';
    document.getElementById('master_duration').value = '';
    document.getElementById('master_status').value = 'active';

    // Clear image fields
    document.getElementById('master_service_image').value = '';
    document.getElementById('imageDisplayContainer').style.display = 'none';
    document.getElementById('currentImagePreview').src = '';
    document.getElementById('delete_current_image').checked = false;

    document.getElementById('deleteMasterBtn').style.display = 'none';
}

function deleteMasterService(){
    const id = document.getElementById('master_service_id').value;
    if (!id || id === '') return;
    // Use the service name from the form (if populated) or simply the ID for the confirmation prompt
    const serviceName = document.getElementById('master_service_name').value;
    
    if (!confirm('Are you sure you want to delete the master service ' + (serviceName ? `"${serviceName}"` : `(ID: ${id})`) + '? This will permanently delete the associated image file and remove all linked data.')) return;
    
    // Submit the hidden delete form associated with the service ID
    const deleteForm = document.getElementById('deleteForm_' + id); 
    if(deleteForm) {
        deleteForm.submit();
    }
}
</script>
</body>
</html>