<section id="contact">
  <h2 class="section-title">Contact Us</h2>
  <div class="contact-container">
    <div class="contact-form">
      <input type="text" name="name" placeholder="Your Name" required>
      <input type="email" name="email" placeholder="Your Email" required>
      <textarea name="message" placeholder="Your Message" required></textarea>
      <button type="submit">Send Message</button>
    </div>
  </div>

  <!-- 📞 Contact Info Below -->
  <div class="contact-info">
    <h3>Clinic Information</h3>
    <p><strong>📍 Address:</strong> 123 Smile Avenue, Bocaue, Bulacan</p>
    <p><strong>📞 Phone:</strong> (044) 123-4567</p>
    <p><strong>📱 Mobile:</strong> 0917-123-4567</p>
    <p><strong>✉️ Email:</strong> dentitrackclinic@gmail.com</p>
    <p><strong>⏰ Clinic Hours:</strong> Mon–Sat: 8:00 AM – 6:00 PM</p>
  </div>
</section>
