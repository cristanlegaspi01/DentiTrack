<div class="about-container">
    <!-- Left: Image -->
    <div class="about-image">
        <img src="images/about.jpg" alt="About Image">
    </div>

    <!-- Right: Text -->
    <div class="about-text-container">
        <h2 class="about-title">About Us</h2>
        <p class="about-text">
            Our company provides the best services for dental care. We specialize in patient records and
            inventory management. We ensure that your visit is smooth and hassle-free with our user-friendly
            management system designed specifically for dental clinics.
        </p>
    </div>
</div>

<!-- Optional: About Form Section -->
<div class="about-form">
    <textarea placeholder="Tell us more about your needs..."></textarea>
</div>
