<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../public/login.php");
    exit;
}

// NOTE: This file (db.php) is assumed to contain the database connection setup.
include '../config/db.php';

$user_id = $_SESSION['user_id'];

// --- DEBUG FUNCTION TO CATCH ERRORS IMMEDIATELY ---
function check_stmt_error($conn, $stmt, $context) {
    if ($stmt === false) {
        // Output the specific MySQL error and stop execution
        die("<h3>Fatal SQL Error in $context:</h3>" . $conn->error);
    }
}
// ----------------------------------------------------


/* ==========================================================
    FETCH FULL NAME FROM patient TABLE
    ========================================================== */
$sql_name = "SELECT first_name, last_name FROM patient WHERE user_id = ?";
$stmt = $conn->prepare($sql_name);
check_stmt_error($conn, $stmt, 'Name Fetch');
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
$patient_name = $res->fetch_assoc();
$stmt->close();

// If no name found (para iwas error)
$full_name = ($patient_name)
    ? htmlspecialchars($patient_name['first_name']) . " " . htmlspecialchars($patient_name['last_name'])
    : "Patient";

/* ==========================================================
    FETCH NEXT APPOINTMENT
    ========================================================== */
$sql_next_appointment = "SELECT appointment_date, appointment_time, status 
                          FROM appointments 
                          WHERE patient_id = ? AND appointment_date >= CURDATE() 
                          ORDER BY appointment_date ASC LIMIT 1";
$stmt = $conn->prepare($sql_next_appointment);
check_stmt_error($conn, $stmt, 'Next Appointment Fetch');
$stmt->bind_param("i", $user_id);
$stmt->execute();
$next_appointment = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* ==========================================================
    COUNT UPCOMING APPOINTMENTS
    ========================================================== */
$sql_upcoming_count = "SELECT COUNT(*) as count 
                          FROM appointments 
                          WHERE patient_id = ? AND appointment_date >= CURDATE()";
$stmt = $conn->prepare($sql_upcoming_count);
check_stmt_error($conn, $stmt, 'Upcoming Appointments Count');
$stmt->bind_param("i", $user_id);
$stmt->execute();
$upcoming_count = $stmt->get_result()->fetch_assoc()['count'];
$stmt->close();

/* ==========================================================
    COUNT ANNOUNCEMENTS
    ========================================================== */
$announcements_count = 0;
// NOTE: Assuming this query is correct as it was in the original code.
$result = $conn->query("SELECT COUNT(*) AS count FROM announcements");
if ($result) {
    $announcements_count = $result->fetch_assoc()['count'];
}

/* ==========================================================
    FETCH LAST DENTAL RECORD 
    (The likely location of your original error: missing 'dental_records' table)
    ========================================================== */
$sql_last_record = "SELECT record_date 
                      FROM dental_records 
                      WHERE patient_id = ? 
                      ORDER BY record_date DESC LIMIT 1";
$stmt = $conn->prepare($sql_last_record);
check_stmt_error($conn, $stmt, 'Last Dental Record Fetch'); // Added error check
$stmt->bind_param("i", $user_id);
$stmt->execute();
$last_record = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* ==========================================================
    COUNT DENTAL RECORDS
    ========================================================== */
$sql_records_count = "SELECT COUNT(*) AS count 
                      FROM dental_records 
                      WHERE patient_id = ?";
$stmt = $conn->prepare($sql_records_count);
check_stmt_error($conn, $stmt, 'Dental Records Count'); // Added error check
$stmt->bind_param("i", $user_id);
$stmt->execute();
$records_count = $stmt->get_result()->fetch_assoc()['count'];
$stmt->close();

/* ==========================================================
    COUNT DOCTOR UPLOADS 
    ========================================================== */
$sql_uploads_count = "SELECT COUNT(*) AS count 
                      FROM patient_files 
                      WHERE patient_id = ?";
$stmt = $conn->prepare($sql_uploads_count);
check_stmt_error($conn, $stmt, 'Doctor Uploads Count'); // Added error check
$stmt->bind_param("i", $user_id);
$stmt->execute();
$uploads_count = $stmt->get_result()->fetch_assoc()['count'];
$stmt->close();

/* ==========================================================
    FETCH SERVICES (Includes image_path and service_id)
    ========================================================== */
$services = [];
$sql_services = "SELECT * FROM services WHERE status = 'active'"; 
$result = $conn->query($sql_services);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $services[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Patient Dashboard - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

<style>
/* |--------------------------------------------------------------------------
| ENHANCED CSS STYLING
|--------------------------------------------------------------------------
*/
/* GLOBAL STYLE (Minor adjustments for font choice) */
html { scroll-behavior: smooth; }
body {
    margin: 0;
    font-family: 'Inter', 'Segoe UI', sans-serif; /* Added 'Inter' as a modern primary font */
    background: #f4f7f9; /* Softer background */
    color: #333;
    height: 100vh;
    display: flex;
}

/* SIDEBAR (Change color gradient and improve link focus) */
.sidebar {
    width: 250px; /* Slightly wider sidebar */
    background: linear-gradient(to top, #0056b3, #007bff); /* Adjusted blue gradient */
    padding: 25px 0; /* Padding adjustment */
    color: white;
    box-shadow: 4px 0 15px rgba(0,0,0,0.2); /* Stronger shadow for depth */
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}
.sidebar h2 {
    text-align: center;
    margin-bottom: 40px;
    font-size: 26px; /* Slightly larger title */
    font-weight: 800;
    color: #ffffff;
    letter-spacing: 1px;
    padding: 0 20px;
}
.sidebar a {
    padding: 15px 30px; /* Increased padding */
    margin-bottom: 8px;
    color: #e0f7ff; /* Lighter color for non-active links */
    text-decoration: none;
    border-left: 5px solid transparent; /* Thicker border on hover/active */
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 15px;
}
.sidebar a:hover {
    background: rgba(255,255,255,0.2);
    border-left: 5px solid #ffaa00; /* Orange highlight on hover */
    color: #fff;
}
.sidebar a.active {
    background: rgba(255,255,255,0.1); /* Subtle active background */
    border-left: 5px solid #ffcc00; /* Bright yellow/gold highlight for active */
    color: #fff;
    font-weight: 600;
}

/* MAIN CONTENT */
.main-content {
    flex: 1;
    padding: 50px 60px; /* Increased overall padding */
    background: #fff; /* Main content is white */
    overflow-y: auto;
}

header h1 {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 2.5rem; /* Larger title */
    color: #004a77;
    border-bottom: 2px solid #e0e0e0;
    padding-bottom: 10px;
    margin-bottom: 20px;
}

.welcome {
    font-size: 1.4rem;
    margin-bottom: 40px;
    color: #555;
    font-weight: 300;
}
.welcome strong {
    font-weight: 600;
    color: #004a77;
}

/* DASHBOARD WIDGETS (Slightly larger and cleaner design) */
.widgets {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); /* Slightly wider min size */
    gap: 30px; /* Increased gap */
    margin-bottom: 50px;
}

.widget {
    background: #ffffff;
    padding: 30px; /* Increased padding */
    border-radius: 12px; /* Softer rounded corners */
    border: 1px solid #dcdcdc; /* Lighter border */
    box-shadow: 0 6px 15px rgba(0,0,0,0.08); /* Better box shadow */
    cursor: pointer;
    transition: all 0.3s ease;
    position: relative; /* For the subtle top border effect */
    overflow: hidden;
}
.widget::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background: #007bff; /* Primary color top bar */
    transition: all 0.3s ease;
}
.widget:hover {
    transform: translateY(-6px); /* More noticeable lift on hover */
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}
.widget:hover::before {
    height: 8px; /* Slightly thicker bar on hover */
}

.widget i {
    font-size: 48px; /* Larger icon */
    margin-bottom: 15px;
    color: #007bff; /* Primary color */
    background: #e6f2ff; /* Light background behind icon */
    padding: 10px;
    border-radius: 50%;
    display: inline-block;
}

.widget .title {
    font-size: 1.1rem; /* Slightly larger title */
    color: #777;
    font-weight: 500;
    margin-bottom: 5px;
}

.widget .value {
    font-size: 3rem; /* Prominent value */
    font-weight: 700;
    color: #004a77;
    line-height: 1;
    margin-bottom: 10px;
}

.widget .subtitle {
    font-size: 1rem;
    color: #666;
    border-top: 1px solid #f0f0f0;
    padding-top: 10px;
}

/* SERVICES SECTION (bottom) */
.services-section {
    margin-top: 60px;
    padding: 50px;
    background: #fcfcfc; /* Very light background for contrast */
    border-radius: 20px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.05);
}

.services-title {
    font-size: 2.2rem;
    color: #004a77;
    font-weight: 700;
    text-align: center;
    margin-bottom: 40px;
}

.services-wrapper {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 30px;
}

/* NEW STYLES FOR CLICKABLE CARD LINK */
.service-card-link {
    text-decoration: none; /* Removes link underline */
    display: block; /* Makes the entire grid cell the clickable area */
}

.service-card {
    background: white;
    padding: 0;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    text-align: center;
    border: 1px solid #eee;
    transition: 0.3s;
    overflow: hidden;
    height: 100%; /* Ensures cards in a row are the same height */
}

.service-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
    border-color: #007bff;
}

.service-card img {
    width: 100%;
    height: 200px; /* Taller image */
    object-fit: cover;
    margin-bottom: 0;
    border-radius: 15px 15px 0 0;
}

.service-content {
    padding: 20px;
}

.service-title {
    font-size: 1.3rem;
    font-weight: 700;
    color: #004a77;
    margin-bottom: 10px;
}

.service-desc {
    font-size: 0.95rem;
    color: #555;
    line-height: 1.5;
}
</style>
</head>

<body>

<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>

    <a href="patient_dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a>
    <a href="patient_appointments.php"><i class="fas fa-calendar-check"></i> Request Consultation</a>
    <a href="patient_records.php"><i class="fas fa-file-medical"></i> Dental Records</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">

<header>
    <h1><i class="fas fa-chart-line"></i> Patient Dashboard</h1>
</header>

<p class="welcome">Welcome back, **<?= $full_name ?>**! We hope you're smiling today.</p>

<div class="widgets">

    <div class="widget" onclick="location.href='patient_appointments.php'">
        <i class="fas fa-calendar-alt"></i>
        <div class="title">Upcoming Appointments</div>
        <div class="value"><?= $upcoming_count ?></div>

        <?php if ($next_appointment): ?>
            <div class="subtitle">
                Next: **<?= htmlspecialchars($next_appointment['appointment_date']) ?>** @ <?= htmlspecialchars($next_appointment['appointment_time']) ?>
            </div>
        <?php else: ?>
            <div class="subtitle">No scheduled appointments</div>
        <?php endif; ?>
    </div>

    <div class="widget" onclick="location.href='patient_records.php'">
        <i class="fas fa-file-medical"></i>
        <div class="title">Total Dental Records</div>
        <div class="value"><?= $records_count + $uploads_count ?></div>
        <div class="subtitle">
            Includes **<?= $uploads_count ?>** Doctor Files | Last record: **<?= $last_record ? htmlspecialchars($last_record['record_date']) : "N/A" ?>**
        </div>
    </div>
    
    <div class="widget">
        <i class="fas fa-bullhorn"></i>
        <div class="title">Clinic Announcements</div>
        <div class="value"><?= $announcements_count ?></div>
        <div class="subtitle">
            Stay updated with clinic news!
        </div>
    </div>
    

</div>
<?php 
// Assuming patient_announcements.php exists and displays the announcements
// NOTE: I recommend creating this file if it doesn't exist, as it's included here.
include '../patient/patient_announcements.php'; 
?>

<div class="services-section">
    <div class="services-title">Explore Our Dental Services 🦷</div>

    <div class="services-wrapper">
        <?php if (!empty($services)): ?>
            <?php foreach ($services as $srv): ?>
                
                <a href="patient_appointments.php?service_id=<?= htmlspecialchars($srv['service_id']) ?>" class="service-card-link">
                    <div class="service-card">
                        
                        <?php 
                        // Path is assumed to be relative to the root, e.g., 'assets/images/service1.jpg'
                        if (!empty($srv['image_path'])): ?>
                            <img src="../<?= htmlspecialchars($srv['image_path']) ?>"
                                alt="<?= htmlspecialchars($srv['service_name']) ?> Image"
                                onerror="this.onerror=null;this.src='../assets/default_service.jpg';"> <?php else: ?>
                            <img src="../assets/default_service.jpg"
                                alt="Default Service Image">
                        <?php endif; ?>

                        <div class="service-content">
                            <div class="service-title">
                                <?= htmlspecialchars($srv['service_name']) ?>
                            </div>

                            <div class="service-desc">
                                <?= htmlspecialchars($srv['description']) ?>
                            </div>
                        </div>

                    </div>
                </a>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="text-align:center; color:#777; font-size: 1.1rem;">
                No services available at the moment. Please check back later!
            </p>
        <?php endif; ?>
    </div>
</div>

</main>
</body>
</html>