<?php
session_start();
// Check if user is logged in AND is a patient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'patient') {
    header('Location: ../public/login.php');
    exit();
}

include '../config/db.php';

// Retrieve the patient's ID from the session for security and filtering
$user_id = $_SESSION['user_id']; 

$patient_files = [];
$patient_recommendations = [];

/* ==========================================================
    1. FETCH DOCTOR UPLOADED FILES (from patient_files)
    ========================================================== */
$sql_files = "SELECT 
                file_name, 
                file_path, 
                uploaded_at AS date, 
                'Doctor File' AS type,
                '' AS description
              FROM patient_files 
              WHERE patient_id = ?";

$stmt = $conn->prepare($sql_files);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_files = $stmt->get_result();

if ($result_files && $result_files->num_rows > 0) {
    while ($row = $result_files->fetch_assoc()) {
        $patient_files[] = $row;
    }
}
$stmt->close();

/* ==========================================================
    2. FETCH DOCTOR RECOMMENDATIONS (from patient_recommendations)
    ========================================================== */
$sql_recommendations = "SELECT 
                          created_at AS date, 
                          recommendation AS description, 
                          'Recommendation' AS type,
                          '' AS file_name,
                          '' AS file_path
                        FROM patient_recommendations 
                        WHERE patient_id = ?";

$stmt = $conn->prepare($sql_recommendations);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_recom = $stmt->get_result();

if ($result_recom && $result_recom->num_rows > 0) {
    while ($row = $result_recom->fetch_assoc()) {
        $patient_recommendations[] = $row;
    }
}
$stmt->close();


/* ==========================================================
    3. COMBINE AND SORT ALL RECORDS
    ========================================================== */
$all_records = array_merge($patient_files, $patient_recommendations);

// Sort the combined array by date in descending order (newest first)
usort($all_records, function($a, $b) {
    return strtotime($b['date']) - strtotime($a['date']);
});

// Helper function to get the file extension for icons
function get_file_icon($file_name) {
    $ext = pathinfo($file_name, PATHINFO_EXTENSION);
    switch (strtolower($ext)) {
        case 'pdf': return 'fas fa-file-pdf text-danger';
        case 'jpg':
        case 'jpeg':
        case 'png': return 'fas fa-file-image text-success';
        case 'doc':
        case 'docx': return 'fas fa-file-word text-primary';
        default: return 'fas fa-file text-secondary';
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Patient Files & Recommendations - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
/* * CSS is structured to match the dashboard design you previously provided. */
    html {
        scroll-behavior: smooth;
    }

    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background: #e6f0ff;
        color: #003366;
        height: 100vh;
        display: flex;
    }

    .sidebar {
        width: 220px;
        background: linear-gradient(to bottom, #3399ff, #0066cc);
        padding: 20px;
        color: white;
        box-shadow: 2px 0 10px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
    }

    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        font-weight: 700;
        user-select: none;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }

    .sidebar a {
        display: block;
        padding: 12px 20px;
        margin: 10px 0;
        color: #cce0ff;
        text-decoration: none;
        border-left: 4px solid transparent;
        font-weight: 600;
        transition: background-color 0.3s ease, border-left-color 0.3s ease;
    }
    .sidebar a:hover,
    .sidebar a.active {
        background-color: rgba(255,255,255,0.15);
        color: white;
        border-left: 4px solid #ffcc00;
    }

    .main-content {
        flex: 1;
        padding: 40px;
        background: white;
        overflow-y: auto;
    }

    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }
    header h1 {
        font-size: 2rem;
        color: #004080;
        text-shadow: 1px 1px 2px #a3c2ff;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .welcome {
        font-size: 1.3rem;
        margin-bottom: 2rem;
        font-weight: 600;
    }
    
    /* --- STYLES FOR TABLE --- */
    .records-container {
        background: #f0f7ff;
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }
    .records-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .records-table th, .records-table td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #cce0ff;
    }
    .records-table th {
        background-color: #0066cc;
        color: white;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 0.9rem;
    }
    .records-table tr:nth-child(even) {
        background-color: #f7faff;
    }
    .records-table tr:hover {
        background-color: #e6f0ff;
    }
    
    .file-link {
        color: #004080;
        text-decoration: none;
        font-weight: 600;
        transition: color 0.2s;
    }
    .file-link:hover {
        color: #ffcc00;
        text-decoration: underline;
    }
    .type-tag {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: 600;
        text-transform: capitalize;
    }
    .tag-file {
        background-color: #e6f7ff;
        color: #0056b3;
    }
    .tag-recommendation {
        background-color: #ffe6cc;
        color: #ff9900;
    }
    .action-button {
        display: inline-block;
        padding: 6px 12px;
        background-color: #007bff;
        color: white;
        border-radius: 5px;
        text-decoration: none;
        font-size: 0.9rem;
        transition: background-color 0.2s;
    }
    .action-button:hover {
        background-color: #0056b3;
    }
    /* Icon color helpers */
    .text-danger { color: #dc3545; }
    .text-success { color: #28a745; }
    .text-primary { color: #007bff; }
    .text-secondary { color: #6c757d; }
    
</style>
</head>
<body>
    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="patient_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="patient_appointments.php"><i class="fas fa-calendar-check"></i> Request Consultation</a>
        <a href="patient_records.php" class="active"><i class="fas fa-file-medical"></i> Dental Records</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>

    <main class="main-content">
        <header>
            <h1><i class="fas fa-paperclip"></i> Doctor's Files & Recommendations</h1>
        </header>

        <p class="welcome">
            This section contains all **files** and **recommendations** shared with you by your doctor.
        </p>

        <div class="records-container">
            <h3>All Items (Sorted by Date)</h3>
            
            <?php if (!empty($all_records)): ?>
                <table class="records-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Details / File Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_records as $record): ?>
                        <tr>
                            <td><?= date('Y-m-d', strtotime($record['date'])) ?></td>
                            <td>
                                <span class="type-tag tag-<?= strtolower(str_replace(' ', '', $record['type'])) ?>">
                                    <?= htmlspecialchars($record['type']) ?>
                                </span>
                            </td>
                            <td>
                                <?php 
                                // Display File icon and link if it's a doctor file
                                if ($record['type'] == 'Doctor File'): ?>
                                    <i class="<?= get_file_icon($record['file_name']) ?> mr-2"></i>
                                    <span class="file-link"><?= htmlspecialchars($record['file_name']) ?></span>
                                <?php 
                                // Display Description for recommendations
                                else: ?>
                                    <?= htmlspecialchars($record['description']) ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($record['type'] == 'Doctor File'): ?>
                                    <a href="../uploads/<?= htmlspecialchars($record['file_path']) ?>" target="_blank" class="action-button">
                                        <i class="fas fa-download"></i> Download/View
                                    </a>
                                <?php elseif ($record['type'] == 'Recommendation'): ?>
                                    <span style="color: #ff9900; font-style: italic;">Read Above</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="padding: 20px; text-align: center; color: #666;">
                    <i class="fas fa-info-circle"></i> No files or recommendations found for your account.
                </div>
            <?php endif; ?>
            
        </div>
    </main>
</body>
</html>