<?php
// services_graph.php
// Plots the monthly usage trend for a specific service within a date range.

// Fallback for environment where include might not work, simulating database connection
// NOTE: This mock section assumes $conn is not set and mimics the database interaction.
if (!isset($conn)) {
    class MockConnection {
        public function prepare($sql) {
            return new MockStatement();
        }
        public function close() {}
        public function query($sql) {
            // Mocking the service fetch for the selection dropdown
            $data = [
                ['service_id' => 1, 'service_name' => 'Dental Cleaning'],
                ['service_id' => 2, 'service_name' => 'Filling (Composite)'],
                ['service_id' => 3, 'service_name' => 'Teeth Whitening'],
                ['service_id' => 4, 'service_name' => 'Root Canal'],
                ['service_id' => 5, 'service_name' => 'Extraction'],
            ];
            return new MockResult($data);
        }
    }

    class MockStatement {
        private $result;
        public function bind_param($types, $start, $end) {}
        public function execute() {
            // Mock data generation for the graph (monthly usage trend for a selected service)
            // This mock ensures that even without a DB, a trend can be shown if service_id > 0
            global $service_id;
            if (isset($service_id) && $service_id > 0) {
                $this->result = [
                    ['payment_month' => date('Y-m', strtotime('-4 months')), 'usage_count' => 10],
                    ['payment_month' => date('Y-m', strtotime('-3 months')), 'usage_count' => 15],
                    ['payment_month' => date('Y-m', strtotime('-2 months')), 'usage_count' => 8],
                    ['payment_month' => date('Y-m', strtotime('-1 months')), 'usage_count' => 20],
                    ['payment_month' => date('Y-m'), 'usage_count' => 12],
                ];
            } else {
                $this->result = [];
            }
        }
        public function get_result() {
            return new MockResult($this->result);
        }
    }

    class MockResult {
        private $data;
        private $index = 0;
        public function __construct($data) {
            $this->data = $data;
        }
        public function fetch_assoc() {
            if ($this->index < count($this->data)) {
                return $this->data[$this->index++];
            }
            return false;
        }
    }
    $conn = new MockConnection();
}


// Helper function for robust date conversion from display format (M d, Y) to DB format (Y-m-d)
function convert_display_to_db_date($display_date) {
    if (empty($display_date)) return null;
    $timestamp = strtotime($display_date);
    if ($timestamp === false) {
        return null;
    }
    return date('Y-m-d', $timestamp);
}


// --- 1. Get User Inputs and Format Dates ---

// Determine the start date for the database query (Y-m-d format)
if (isset($_GET['start_date']) && ($db_date = convert_display_to_db_date($_GET['start_date'])) !== null) {
    $start_date_db = $db_date;
} else {
    $start_date_db = date('Y-m-d', strtotime('-6 months'));
}

// Determine the end date for the database query (Y-m-d format)
if (isset($_GET['end_date']) && ($db_date = convert_display_to_db_date($_GET['end_date'])) !== null) {
    $end_date_db = $db_date;
} else {
    $end_date_db = date('Y-m-d');
}

// --- Validation and Correction: Ensure start date is before end date ---
if (strtotime($start_date_db) > strtotime($end_date_db)) {
    $temp = $start_date_db;
    $start_date_db = $end_date_db;
    $end_date_db = $temp;
}

// Format dates for the text input fields' display value (Month Day, Year)
$start_date_display = date('M d, Y', strtotime($start_date_db));
$end_date_display = date('M d, Y', strtotime($end_date_db));


// --- 2. Get Service ID and List ---
$service_id = isset($_GET['service_id']) ? intval($_GET['service_id']) : 0; 
$service_name = "Select a Service";
$all_services = [];

// Fetch Service List for Selection (Dropdown)
// This query fetches the list of available services
if (isset($conn)) {
    $services_result = $conn->query("SELECT service_id, service_name FROM services ORDER BY service_name ASC");
    if ($services_result) {
        while ($row = $services_result->fetch_assoc()) {
            $all_services[] = $row;
            if ($row['service_id'] == $service_id) {
                $service_name = $row['service_name'];
            }
        }
    }
}


// --- 3. Fetch Usage Data for Selected Item and Date Range ---
$labels = [];
$usage_counts = [];
$max_count = 0;

if ($service_id > 0) {
    // SQL to aggregate count of payments for the selected service per month
    $sql = "SELECT
                DATE_FORMAT(p.payment_date, '%Y-%m') as payment_month,
                COUNT(p.payment_id) as usage_count
            FROM payments p
            WHERE p.service_id = ?
            AND p.payment_date BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY)
            GROUP BY payment_month
            ORDER BY payment_month ASC";

    // Reinitialize statement and execute for the main data fetch
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $service_id, $start_date_db, $end_date_db);
    $stmt->execute();
    $result = $stmt->get_result();

    while($row = $result->fetch_assoc()) {
        $labels[] = date('M Y', strtotime($row['payment_month'] . '-01'));
        $current_count = intval($row['usage_count']);
        $usage_counts[] = $current_count;
        if ($current_count > $max_count) {
            $max_count = $current_count;
        }
    }
}

$conn->close();

$labels_json = json_encode($labels);
$usage_counts_json = json_encode($usage_counts);

// Calculate suggested maximum for the Y-axis range
$y_buffer = max(5, ceil($max_count * 0.1)); 
$suggested_max = $max_count + $y_buffer;
$suggested_max_js = json_encode((int)$suggested_max);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Usage Trend Report</title>
    <!-- Load Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Load jQuery and jQuery UI for custom date picker -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js"></script>
    
    <!-- jQuery UI CSS (Needed for the date picker look) -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">

    <style>
        /* Custom styles for consistency */
        input[type="text"], select {
            border-color: #3B82F6 !important; /* Blue-500 */
        }
        input[type="text"]:focus, select:focus {
            box-shadow: 0 0 0 2px #93C5FD; /* Blue-300 ring */
        }
    </style>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'primary-blue': '#2563EB', // Blue-600
                        'light-blue': '#BFDBFE', // Blue-200
                        'accent-indigo': '#6366F1', // Indigo-500
                    }
                }
            }
        }
    </script>
</head>

<body class="bg-gray-50 font-sans min-h-screen p-4 sm:p-8">

    <div class="max-w-6xl mx-auto space-y-8">
        
        <!-- Header -->
        <h1 class="text-3xl sm:text-4xl font-extrabold text-primary-blue text-center mb-6">
            Service Usage Trend Report
        </h1>

        <!-- Filter Card -->
        <div class="bg-white p-6 md:p-8 rounded-xl shadow-lg border border-light-blue">
            <h2 class="text-xl font-semibold text-gray-700 mb-4">Select Service and Date Range</h2>
            
            <form method="GET" action="../analytics_graph/services_graph.php" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                
                <!-- Service Dropdown -->
                <div class="col-span-1 md:col-span-1">
                    <label for="service_id" class="block text-sm font-medium text-gray-600 mb-1">Select Service:</label>
                    <select name="service_id" id="service_id" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-accent-indigo focus:border-accent-indigo transition duration-150">
                        <option value="0" <?php echo ($service_id == 0) ? 'selected' : ''; ?>>-- Select Service --</option>
                        <?php foreach ($all_services as $service): ?>
                            <option value="<?php echo $service['service_id']; ?>" 
                                    <?php echo ($service['service_id'] == $service_id) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($service['service_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <!-- Start Date -->
                <div class="col-span-1 md:col-span-1">
                    <label for="start_date" class="block text-sm font-medium text-gray-600 mb-1">Start Date:</label>
                    <input 
                        type="text" 
                        name="start_date" 
                        id="start_date" 
                        value="<?php echo htmlspecialchars($start_date_display); ?>" 
                        required 
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-accent-indigo focus:border-accent-indigo transition duration-150"
                    >
                </div>
                
                <!-- End Date -->
                <div class="col-span-1 md:col-span-1">
                    <label for="end_date" class="block text-sm font-medium text-gray-600 mb-1">End Date:</label>
                    <input 
                        type="text" 
                        name="end_date" 
                        id="end_date" 
                        value="<?php echo htmlspecialchars($end_date_display); ?>" 
                        required 
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-accent-indigo focus:border-accent-indigo transition duration-150"
                    >
                </div>
                
                <!-- Button -->
                <div class="col-span-1 md:col-span-1">
                    <button 
                        type="submit" 
                        class="w-full px-6 py-2 bg-accent-indigo text-white font-bold rounded-lg shadow-md hover:bg-indigo-600 transition duration-150 ease-in-out transform hover:scale-[1.02]"
                    >
                        View Trend
                    </button>
                </div>
            </form>
        </div>

        <!-- Chart Card -->
        <div class="bg-white p-6 md:p-8 rounded-xl shadow-lg border border-light-blue">
            <h2 class="text-2xl font-semibold text-gray-800 mb-4">
                Monthly Usage for: <?php echo htmlspecialchars($service_name); ?>
            </h2>
            
            <div class="h-96 w-full">
                <?php if ($service_id > 0 && count($usage_counts) > 0): ?>
                    <!-- Chart.js Canvas -->
                    <canvas id="ServicesChart"></canvas>
                <?php elseif ($service_id == 0): ?>
                    <p class="text-center text-lg text-gray-500 py-10">
                        Please select a service and a date range to view the usage trend.
                    </p>
                <?php else: ?>
                    <p class="text-center text-lg text-gray-500 py-10">
                        No usage data found for **<?php echo htmlspecialchars($service_name); ?>** in the selected date range.<br>
                        (From <?php echo $start_date_display; ?> to <?php echo $end_date_display; ?>)
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Chart.js Script & Datepicker Initialization -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const chartSuggestedMax = <?php echo $suggested_max_js; ?>;
        const primaryColor = 'rgba(239, 68, 68, 1)'; // Red-500
        const lightFillColor = 'rgba(239, 68, 68, 0.6)'; // Red-500 with opacity

        // Initialize jQuery UI Datepickers
        $(function() {
            // Set the date format to Month Day, Year (e.g., Nov 15, 2025)
            const dateFormat = "M d, yy";

            $("#start_date").datepicker({ dateFormat: dateFormat });
            $("#end_date").datepicker({ dateFormat: dateFormat });
        });

        // Only initialize the chart if data is present
        if (<?php echo json_encode($service_id > 0 && count($usage_counts) > 0); ?>) {
            const servicesConfig = {
                type: 'bar',
                data: {
                    labels: <?php echo $labels_json; ?>,
                    datasets: [{
                        label: 'Total Times Used',
                        data: <?php echo $usage_counts_json; ?>,
                        backgroundColor: lightFillColor,
                        borderColor: primaryColor,
                        borderWidth: 1,
                        borderRadius: 4, 
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            labels: { font: { size: 14 } }
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                        }
                    },
                    scales: {
                        x: {
                            title: { 
                                display: true, 
                                text: 'Month and Year',
                                color: '#4B5563'
                            },
                            grid: {
                                display: false
                            }
                        },
                        y: { 
                            beginAtZero: true, 
                            title: { 
                                display: true, 
                                text: 'Usage Count',
                                color: '#4B5563'
                            }, 
                            suggestedMax: chartSuggestedMax,
                            ticks: {
                                precision: 0 // Ensure ticks are integers
                            },
                            grid: {
                                color: '#E5E7EB'
                            }
                        }
                    }
                }
            };
            const ctx = document.getElementById('ServicesChart');
            if (ctx) {
                new Chart(ctx, servicesConfig);
            }
        }
    </script>

</body>
</html>