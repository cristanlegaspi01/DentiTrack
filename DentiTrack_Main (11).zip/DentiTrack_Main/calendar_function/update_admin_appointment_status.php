<?php
// Must ensure the connection file is included
require_once 'calendar_conn.php'; 

// This dedicated endpoint handles the POST request from the admin calendar's modal buttons.
// It allows for full flexibility in status changes (e.g., Declined back to Pending).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Sanitize and retrieve input data
    $appointment_id = $_POST['appointment_id'] ?? null;
    $new_status = $_POST['status'] ?? null;

    // 2. Input Validation
    if (!$appointment_id || !$new_status) {
        http_response_code(400);
        die("Error: Missing appointment ID or status.");
    }
    
    // Ensure the new status is one of the expected values (admin can set all of them)
    $allowed_statuses = ['pending', 'approved', 'declined'];
    if (!in_array($new_status, $allowed_statuses)) {
        http_response_code(400);
        die("Error: Invalid status value provided: " . htmlspecialchars($new_status));
    }

    try {
        // 3. Prepare the SQL statement for a direct update
        $stmt = $pdo->prepare("UPDATE appointments SET status = :status WHERE appointment_id = :id");
        
        $stmt->bindParam(':status', $new_status);
        $stmt->bindParam(':id', $appointment_id);
        
        $stmt->execute();

        if ($stmt->rowCount()) {
            echo "Appointment status successfully updated to " . ucfirst($new_status) . ".";
        } else {
            // This case handles when the status is already what the user clicked (e.g., Pending -> Pending)
            echo "Update acknowledged, but no change detected (status may have been the same, or ID not found).";
        }

    } catch (PDOException $e) {
        // 4. Error Handling
        http_response_code(500);
        echo "Database error: " . $e->getMessage();
    }
} else {
    http_response_code(405);
    echo "Method not allowed. Use POST.";
}
?>