<?php
require_once '../calendar_function/calendar_conn.php';
header('Content-Type: application/json');

$date = $_GET['date'] ?? '';
$search = trim($_GET['search'] ?? ''); // optional patient search

if (empty($date)) {
    echo json_encode(['status' => 'error', 'message' => 'No date provided.']);
    exit;
}

/*
 * Fetch all appointments for the selected date,
 * excluding cancelled and declined ones.
 * Ordered: Pending → Approved.
 * If 'search' is provided, filter by patient_name (case-insensitive).
 */
$query = "
    SELECT 
        appointment_id,
        patient_name,
        email,
        contact_number,
        gender,
        age,
        service,
        appointment_date,
        appointment_time,
        start_time,
        end_time,
        comments,
        status,
        created_at,
        updated_at
    FROM appointments
    WHERE appointment_date = ?
      AND status IN ('pending', 'approved')
";

$params = [$date];

// Add search filter if provided
if (!empty($search)) {
    $query .= " AND LOWER(patient_name) LIKE ?";
    $params[] = '%' . strtolower($search) . '%';
}

// Order results: pending first, then approved, sorted by time
$query .= " ORDER BY FIELD(status, 'pending', 'approved'), appointment_time ASC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($appointments)) {
        echo json_encode([
            'status' => 'empty',
            'message' => 'No appointments found for this date.'
        ]);
        exit;
    }

    // Format for JSON response
    $formatted = [];
    foreach ($appointments as $a) {
        $formatted[] = [
            'appointment_id' => $a['appointment_id'],
            'patient_name'   => $a['patient_name'],
            'email'          => $a['email'],
            'contact_number' => $a['contact_number'],
            'gender'         => $a['gender'],
            'age'            => $a['age'],
            'service'        => $a['service'],
            'appointment_date' => $a['appointment_date'],
            'appointment_time' => $a['appointment_time'],
            'start_time'     => $a['start_time'],
            'end_time'       => $a['end_time'],
            'comments'       => $a['comments'],
            'status'         => ucfirst(strtolower($a['status'])),
            'created_at'     => $a['created_at'],
            'updated_at'     => $a['updated_at']
        ];
    }

    echo json_encode([
        'status' => 'success',
        'date' => $date,
        'appointments' => $formatted
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database query failed: ' . $e->getMessage()
    ]);
}
?>
