<?php
// Ensure session is started to potentially use session data later
session_start();
require_once 'calendar_conn.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

// Get the required fields from the data sent from the patient_calendar.php form
$user_id          = $data['user_id'] ?? 0;
$service_id       = $data['service_id'] ?? NULL;
$appointment_date = $data['appointment_date'] ?? NULL;
$appointment_time = $data['appointment_time'] ?? NULL;
$comments         = $data['comments'] ?? '';

// Basic Validation
if (
    $user_id <= 0 || 
    empty($service_id) || 
    empty($appointment_date) || 
    empty($appointment_time)
) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields (User ID, Service, Date, or Time).']);
    exit;
}

try {
    // Sanitize and prepare data
    $user_id          = (int)$user_id;
    $service_id       = (int)$service_id;
    $appointment_date = $appointment_date;
    $comments         = htmlspecialchars($comments);

    /* --------------------------------------------------------
       1. TIME PARSING: Convert 'HH:MM AM - HH:MM PM' to TIME format
    -------------------------------------------------------- */
    $timeParts = explode(' - ', $appointment_time);
    
    if (count($timeParts) === 2) {
        $start_time_str = trim($timeParts[0]);
        $end_time_str = trim($timeParts[1]);

        // Convert the string time (e.g., '9:00 AM') to MySQL TIME format (e.g., '09:00:00')
        $start_time = date('H:i:s', strtotime($start_time_str));
        $end_time   = date('H:i:s', strtotime($end_time_str));
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid appointment time format.']);
        exit;
    }


    /* --------------------------------------------------------
       2. DUPLICATE CHECK: Prevent double booking
       Checks against 'booked' (confirmed future) and 'completed' (past slots).
    -------------------------------------------------------- */
    // Note: We check the original appointment_time string since it uniquely defines the slot
    $check = $pdo->prepare("
        SELECT COUNT(*) 
        FROM appointments 
        WHERE appointment_date = ? 
        AND appointment_time = ? 
        AND status IN ('booked', 'completed')
    ");
    $check->execute([$appointment_date, $appointment_time]);
    $exists = $check->fetchColumn();

    if ($exists > 0) {
        echo json_encode([
            'status' => 'error',
            'message' => 'This time slot is already occupied. Please select another time.'
        ]);
        exit;
    }

    /* --------------------------------------------------------
       3. INSERT APPOINTMENT: Use user_id and service_id, status='booked'
    -------------------------------------------------------- */
    $stmt = $pdo->prepare("
        INSERT INTO appointments 
        (user_id, service_id, appointment_date, appointment_time, start_time, end_time, comments, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'booked')
    ");
    
    $stmt->execute([
        $user_id,
        $service_id,
        $appointment_date,
        $appointment_time,
        $start_time,
        $end_time,
        $comments
    ]);
    
    echo json_encode(['status' => 'success', 'message' => 'Appointment successfully booked!']);
    
} catch (PDOException $e) {
    // Catch database errors
    error_log("Appointment Insertion Error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Database error during submission.']);
}
?>