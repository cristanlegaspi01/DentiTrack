<?php
require_once 'calendar_conn.php';

$id = $_POST['appointment_id'] ?? null;
$status = $_POST['status'] ?? null;

if (!$id || !$status) {
    http_response_code(400);
    echo "Missing data";
    exit;
}

$query = "UPDATE appointments SET status = ?, updated_at = NOW() WHERE appointment_id = ?";
$stmt = $pdo->prepare($query);
$stmt->execute([$status, $id]);

echo "Success";
?>
