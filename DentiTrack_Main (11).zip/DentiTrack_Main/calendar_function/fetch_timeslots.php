<?php
require_once 'calendar_conn.php';
header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_GET['date']) || empty($_GET['date'])) {
    echo json_encode(['error' => 'Missing date parameter']);
    exit;
}

$date = $_GET['date'];

try {
    // Fetch both pending and approved appointments for the date
    $stmt = $pdo->prepare("
        SELECT appointment_time, start_time, end_time, status
        FROM appointments
        WHERE appointment_date = ?
        AND status IN ('Approved','Pending')
    ");
    $stmt->execute([$date]);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Map slotLabel => status ('approved' or 'pending')
    $occupiedMap = [];

    foreach ($appointments as $appt) {
        $status = strtolower($appt['status']); // 'approved' or 'pending'

        // Use start_time / end_time if available
        if (!empty($appt['start_time']) && !empty($appt['end_time'])) {
            $displayStart = date("g:i A", strtotime($appt['start_time']));
            $displayEnd   = date("g:i A", strtotime($appt['end_time']));
            $label = $displayStart . ' - ' . $displayEnd;
            $occupiedMap[$label] = $status;
            continue;
        }

        // Otherwise parse appointment_time
        if (!empty($appt['appointment_time'])) {
            $raw = trim($appt['appointment_time']);
            $parts = preg_split('/\s*[-–]\s*|\s+to\s+/i', $raw);
            if (count($parts) >= 2) {
                $startRaw = trim($parts[0]);
                $endRaw = trim($parts[1]);

                $tsStart = strtotime($startRaw);
                $tsEnd = strtotime($endRaw);

                if ($tsStart !== false && $tsEnd !== false) {
                    $label = date("g:i A", $tsStart) . ' - ' . date("g:i A", $tsEnd);
                    $occupiedMap[$label] = $status;
                    continue;
                }
            }
            $occupiedMap[$raw] = $status;
        }
    }

    // Build standard hourly slots between 08:00 and 17:00 (8AM - 5PM)
    $slots = [];
    for ($h = 8; $h < 17; $h++) {
        $startTs = strtotime(sprintf('%02d:00:00', $h));
        $endTs   = strtotime(sprintf('%02d:00:00', $h + 1));

        $displayStart = date("g:i A", $startTs);
        $displayEnd   = date("g:i A", $endTs);
        $label = $displayStart . ' - ' . $displayEnd;

        if (isset($occupiedMap[$label])) {
            $status = $occupiedMap[$label];
            $slots[] = [
                'time' => $label,
                'status' => $status,
                'label' => 'Occupied – ' . ucfirst($status)
            ];
        } else {
            $slots[] = [
                'time' => $label,
                'status' => 'available',
                'label' => 'Available'
            ];
        }
    }

    echo json_encode($slots);

} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
