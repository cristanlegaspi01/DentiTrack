<?php
require_once '../calendar_function/calendar_conn.php';
header('Content-Type: application/json');

$events = [];

/* ------------------------------------------
   FETCH GROUPED APPOINTMENTS BY DATE & STATUS
------------------------------------------- */
$query = "
    SELECT appointment_date, LOWER(status) AS status, COUNT(*) AS total
    FROM appointments
    WHERE status IN ('pending', 'approved', 'cancelled')
    GROUP BY appointment_date, status
";
$stmt = $pdo->query($query);

/* ------------------------------------------
   STATUS COLORS FOR CALENDAR LEGEND
------------------------------------------- */
$statusColors = [
    'pending'  => '#FFD966',  // yellow
    'approved' => '#4A90E2',  // blue
    'cancelled' => '#FF6F61', // red/orange
];

/* ------------------------------------------
   COMBINE COUNTS FOR SAME DATE & STATUS
------------------------------------------- */
$grouped = [];

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $date   = $row['appointment_date'];
    $status = ucfirst($row['status']);
    $count  = (int)$row['total'];

    if (!isset($grouped[$date])) {
        $grouped[$date] = [];
    }
    if (!isset($grouped[$date][$status])) {
        $grouped[$date][$status] = 0;
    }

    $grouped[$date][$status] += $count;
}

/* ------------------------------------------
   BUILD EVENTS ARRAY FOR CALENDAR DISPLAY
------------------------------------------- */
foreach ($grouped as $date => $statuses) {
    foreach ($statuses as $status => $count) {
        if ($count <= 0) continue;

        $color = $statusColors[strtolower($status)] ?? '#CCCCCC';

        $events[] = [
            'title' => "$status: $count",
            'start' => $date,
            'color' => $color,
            'textColor' => 'black',
            'display' => 'block',
            'extendedProps' => [
                'status' => $status,
                'count'  => $count
            ]
        ];
    }
}

/* ------------------------------------------
   FETCH DOCTOR REST DAYS
------------------------------------------- */
$queryRest = "
    SELECT available_date, reason
    FROM doctor_availability
    WHERE is_available = 0
";
$stmtRest = $pdo->query($queryRest);

while ($row = $stmtRest->fetch(PDO::FETCH_ASSOC)) {
    $events[] = [
        'title' => 'Rest Day',
        'start' => $row['available_date'],
        'color' => '#8FD19E',
        'textColor' => 'black',
        'display' => 'block',
        'extendedProps' => [
            'status' => 'Rest Day',
            'reason' => $row['reason']
        ]
    ];
}

/* ------------------------------------------
   RETURN JSON RESPONSE
------------------------------------------- */
echo json_encode($events);
?>
