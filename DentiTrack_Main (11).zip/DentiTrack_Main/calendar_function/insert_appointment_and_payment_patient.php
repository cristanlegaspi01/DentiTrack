<?php
// File: calendar_function/insert_appointment_and_payment_patient.php

require_once '../calendar_function/calendar_conn.php'; 
header('Content-Type: application/json');

// =======================================================
// 1. SMTP Configuration and PHPMailer Setup
// =======================================================
require '../phpmailer-master/src/PHPMailer.php';
require '../phpmailer-master/src/SMTP.php';
require '../phpmailer-master/src/Exception.php';
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

define('CONF_SMTP_USER', 'dentitrack2025@gmail.com');
define('CONF_SMTP_PASS', 'gpmennmjrynhujzq');

// Receive booking data
$data = $_POST;

// --------------------
// APPOINTMENT FIELDS
// --------------------
$user_id          = $data['user_id'] ?? 0;
$service_id       = $data['service_id'] ?? NULL;
$appointment_date = $data['appointment_date'] ?? NULL;
$appointment_time = $data['appointment_time'] ?? NULL;
$comments         = $data['comments'] ?? '';

// --------------------
// FIXED: Get REAL patient_id from DB
// --------------------
$getPatient = $pdo->prepare("SELECT patient_id FROM patient WHERE user_id = ?");
$getPatient->execute([$user_id]);
$patient_id = $getPatient->fetchColumn();

if (!$patient_id) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Patient record not found for this user.'
    ]);
    exit;
}

// --------------------
// PAYMENT FIELDS
// --------------------
$primary_method   = $data['primary_method'] ?? 'Walk-in'; 
$discount_type    = $data['discount_type'] ?? 'None'; 
$submitted_amount = number_format(floatval($data['amount_paid'] ?? 0.00), 2, '.', ''); 
$payment_type     = $data['payment_type'] ?? 'Full'; 

// INSTALLMENT FIELDS
$installment_term = intval($data['installment_term'] ?? 0); 
$monthly_payment  = number_format(floatval($data['monthly_payment'] ?? 0.00), 2, '.', ''); 

// Uploaded proof file
$uploaded_file = $_FILES['uploaded_proof_image'] ?? null;

// Required Field Validation
if (
    $user_id <= 0 ||
    empty($service_id) ||
    empty($appointment_date) ||
    empty($appointment_time)
) {
    echo json_encode(['status' => 'error', 'message' => 'Missing or invalid required fields.']);
    exit;
}

// Validate payment proof
if ($uploaded_file === null || $uploaded_file['error'] !== UPLOAD_ERR_OK) {
    if ($uploaded_file && $uploaded_file['error'] === UPLOAD_ERR_NO_FILE) {
        echo json_encode(['status' => 'error', 'message' => 'Payment proof image is required.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'File upload failed.']);
    }
    exit;
}

$target_file = null;

try {
    // Sanitize comments
    $comments = htmlspecialchars($comments);

    // Get service details
    $serviceStmt = $pdo->prepare("SELECT price, service_name, duration FROM services WHERE service_id = ?");
    $serviceStmt->execute([$service_id]);
    $service = $serviceStmt->fetch(PDO::FETCH_ASSOC);

    if (!$service) {
        throw new Exception("Service not found.");
    }

    $full_price   = floatval($service['price']);
    $service_name = $service['service_name'];
    $durationText = $service['duration'];

    // --------------------
    // DISCOUNT LOGIC
    // --------------------
    $discount_rate = 0.00;
    if (strpos($discount_type, 'Loyalty') !== false)  $discount_rate = 0.10;
    if (strpos($discount_type, 'Health') !== false)   $discount_rate = 0.15;

    $discount_amount = round($full_price * $discount_rate, 2);
    $final_price_after_discount = number_format($full_price - $discount_amount, 2, '.', '');

    $deposit_amount = $submitted_amount;
    $remaining_balance = 0.00;
    $payment_amount_for_db = 0.00;

    // --------------------
    // PAYMENT LOGIC
    // --------------------
    if ($deposit_amount >= $final_price_after_discount) {
        $payment_option = 'full';
        $payment_status_db = 'paid';
        $booking_option_label = 'Full Payment';
        $payment_amount_for_db = $final_price_after_discount;
    } else {
        $payment_option = 'installment';
        $payment_status_db = 'pending';
        $remaining_balance = round($final_price_after_discount - $deposit_amount, 2);
        $payment_amount_for_db = $remaining_balance;

        if ($primary_method === 'Walk-in') {
            $booking_option_label = 'Downpayment';
        } else {
            $booking_option_label = 'Installment';
        }
    }

    // --------------------
    // IMAGE UPLOAD
    // --------------------
    $upload_dir = '../uploads/payment_proofs/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

    $ext = pathinfo($uploaded_file['name'], PATHINFO_EXTENSION);
    $new_filename = uniqid('proof_') . "." . $ext;
    $target_file = $upload_dir . $new_filename;
    $proof_image_path = 'uploads/payment_proofs/' . $new_filename;

    move_uploaded_file($uploaded_file['tmp_name'], $target_file);

    // --------------------
    // TIME PARSING
    // --------------------
    list($start_label, $end_label) = explode(' - ', $appointment_time);
    $start_time = date('H:i:s', strtotime($start_label));

  $minutes = 60;
if (preg_match('/(\d+)\s*minutes?/i', $durationText, $m)) {
    $minutes = (int)$m[1];
} elseif (preg_match('/(\d+)\s*hours?/i', $durationText, $m)) {
    $minutes = (int)$m[1] * 60;
}


    $end_time = date('H:i:s', strtotime($start_time) + ($minutes * 60));

    // Check for existing appointment
    $check = $pdo->prepare("
        SELECT COUNT(*) FROM appointments 
        WHERE appointment_date = ? 
        AND appointment_time = ? 
        AND status IN ('booked','completed')
    ");
    $check->execute([$appointment_date, $appointment_time]);
    
    if ($check->fetchColumn() > 0) {
        unlink($target_file);
        echo json_encode(['status' => 'error', 'message' => 'Time slot already booked.']);
        exit;
    }

    // --------------------
    // INSERT APPOINTMENT
    // --------------------
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        INSERT INTO appointments 
        (user_id, patient_id, service_id, appointment_date, appointment_time, start_time, end_time, comments, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'booked')
    ");
    $stmt->execute([
        $user_id,
        $patient_id,
        $service_id,
        $appointment_date,
        $appointment_time,
        $start_time,
        $end_time,
        $comments
    ]);

    $appointment_id = $pdo->lastInsertId();

    // --------------------
    // INSERT PAYMENT
    // --------------------
    $payment_stmt = $pdo->prepare("
        INSERT INTO payments 
        (user_id, amount, patient_id, service_id, discount_type, discount_amount, total_amount, 
         payment_method, booking_option, payment_option, downpayment, appointment_id, proof_image, 
         payment_date, status, installment_term, monthly_payment)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), ?, ?, ?)
    ");

    $payment_stmt->execute([
        $user_id,
        $payment_amount_for_db,
        $patient_id,
        $service_id,
        $discount_type,
        $discount_amount,
        $final_price_after_discount,
        $primary_method,
        $booking_option_label,
        $payment_option,
        $deposit_amount,
        $appointment_id,
        $proof_image_path,
        $payment_status_db,
        ($payment_option === 'installment' ? $installment_term : 0),
        ($payment_option === 'installment' ? $monthly_payment : 0.00)
    ]);

    // Update balance if needed
    if ($payment_option === 'installment' && $remaining_balance > 0) {
        $update_balance = $pdo->prepare("UPDATE patient SET outstanding_balance = outstanding_balance + ? WHERE patient_id = ?");
        $update_balance->execute([$remaining_balance, $patient_id]);
    }

    $pdo->commit();

    // --------------------
    // SEND EMAIL CONFIRMATION
    // --------------------
$patient_query = $pdo->prepare("
    SELECT u.email, 
           CONCAT(p.first_name, ' ', p.last_name) AS full_name
    FROM users u
    JOIN patient p ON u.user_id = p.user_id
    WHERE u.user_id = ?
");
$patient_query->execute([$user_id]);
$pdata = $patient_query->fetch(PDO::FETCH_ASSOC);

$patient_email     = $pdata['email'] ?? '';
$patient_fullname  = $pdata['full_name'] ?? 'Patient';

if ($patient_email) {
    try {
        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = CONF_SMTP_USER;
        $mail->Password = CONF_SMTP_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom(CONF_SMTP_USER, 'DentiTrack Clinic');
        $mail->addAddress($patient_email, $patient_fullname);

        $mail->isHTML(true);
        $mail->Subject = "Appointment Submitted for Verification";

        $formatted_date = date('F j, Y', strtotime($appointment_date));
        $formatted_time = date('h:i A', strtotime($start_time));
        $payment_status_display = ucfirst($payment_status_db);

        $mail->Body = "
            <h2>Appointment Submitted!</h2>
            <p>Dear {$patient_fullname}, your booking has been submitted for verification.</p>
            <ul>
                <li><strong>Service:</strong> {$service_name}</li>
                <li><strong>Date:</strong> {$formatted_date}</li>
                <li><strong>Time:</strong> {$formatted_time}</li>
                <li><strong>Payment Status:</strong> {$payment_status_display}</li>
            </ul>
            <p>You will receive another email after verification.</p>
        ";

        $mail->send();

    } catch (Exception $emailError) {
        error_log("EMAIL ERROR: " . $emailError->getMessage());
    }
}

    echo json_encode([
        'status' => 'success',
        'message' => 'Appointment successfully booked and payment submitted for verification!'
    ]);
    exit;

} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if (isset($target_file) && file_exists($target_file)) unlink($target_file);

    echo json_encode([
        'status' => 'error',
        'message' => 'SQL ERROR: ' . $e->getMessage()
    ]);
    exit;

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if (isset($target_file) && file_exists($target_file)) unlink($target_file);

    echo json_encode([
        'status' => 'error',
        'message' => 'ERROR: ' . $e->getMessage()
    ]);
    exit;
}
?>
