<?php
require_once '../calendar_function/calendar_conn.php';
header('Content-Type: application/json');

/*
 * This script fetches appointments for the FullCalendar display.
 * It is modified to aggregate (group) multiple appointments 
 * on the same day by their status (Approved, Pending, Declined) 
 * to prevent calendar clutter and show a count (e.g., "Approved (2)").
 */

// NOTE: Since this is the Admin calendar, we fetch all statuses 
// (Pending, Approved, Declined, Rest Day) to be displayed on the calendar.
$query = "
    SELECT 
        appointment_date, 
        status, 
        COUNT(appointment_id) AS count
    FROM 
        appointments
    WHERE
        status IN ('approved', 'pending', 'declined', 'rest day')
    GROUP BY 
        appointment_date, status
    ORDER BY 
        appointment_date ASC, status ASC
";

try {
    $stmt = $pdo->query($query);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $events = [];
    foreach ($results as $row) {
        $status = strtolower($row['status']);
        $count = (int)$row['count'];
        $date = $row['appointment_date'];
        
        // Determine color and title based on status
        $color = '#808080'; // Default gray
        $title = ucfirst($status);

        switch ($status) {
            case 'pending':
                $color = '#FFD966';
                $title = "Pending";
                break;
            case 'approved':
                $color = '#4A90E2';
                $title = "Approved";
                break;
            case 'declined':
                $color = '#E57373';
                $title = "Declined";
                break;
            case 'rest day':
                $color = '#8FD19E';
                $title = "Rest Day";
                break;
        }

        // Add count to the title if there's more than one
        $displayTitle = $title . ($count > 1 ? " ({$count})" : "");

        // Create the aggregated event object for FullCalendar
        $events[] = [
            'title' => $displayTitle,
            'start' => $date,
            // 'allDay' is true by default for dayGrid view
            'color' => $color,
            'textColor' => ($status === 'pending' || $status === 'rest day') ? 'black' : 'white',
            // Use extendedProps to pass the raw status back for CSS class
            'extendedProps' => [
                'status' => $status
            ],
            // Ensure the event is non-editable
            'editable' => false,
            'display' => 'list-item' // Ensures it shows in the list view inside the day
        ];
    }

    echo json_encode($events);

} catch (PDOException $e) {
    // In a real application, log this error instead of echoing it directly
    error_log("Database Error: " . $e->getMessage()); 
    echo json_encode([]); // Return an empty array on error
}
?>