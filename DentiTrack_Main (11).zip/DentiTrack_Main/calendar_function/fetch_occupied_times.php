<?php
require_once '../calendar_function/calendar_conn.php';

$date = $_GET['date'] ?? '';
if (!$date) {
  echo json_encode([]);
  exit;
}

$stmt = $conn->prepare("SELECT appointment_time, status FROM appointments WHERE appointment_date = ?");
$stmt->execute([$date]);
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$data = [];
foreach ($result as $row) {
  $data[] = [
    'time' => $row['appointment_time'],
    'status' => ucfirst($row['status'])
  ];
}

echo json_encode($data);
?>
