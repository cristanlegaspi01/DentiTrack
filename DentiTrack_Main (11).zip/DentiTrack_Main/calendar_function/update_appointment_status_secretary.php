<?php
require_once 'calendar_conn.php';

// =======================================================
// 1. SMTP Configuration and PHPMailer Setup
// =======================================================
// Include PHPMailer files (adjust paths if needed)
require '../phpmailer-master/src/PHPMailer.php';
require '../phpmailer-master/src/SMTP.php';
require '../phpmailer-master/src/Exception.php';
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// IMPORTANT CONFIGURATION: SMTP Credentials 
define('CONF_SMTP_USER', 'dentitrack2025@gmail.com');       // Your Gmail address
define('CONF_SMTP_PASS', 'gpmennmjrynhujzq');             // Your Gmail App Password
// =======================================================

date_default_timezone_set('Asia/Manila');
header('Content-Type: application/json');

// 2. Get POST data
$appointment_id = $_POST['appointment_id'] ?? null;
$new_status_raw = $_POST['status'] ?? null;
$updated_at = date('Y-m-d H:i:s'); // Timestamp the update

// 3. Validate essential parameters
if (empty($appointment_id) || empty($new_status_raw)) {
    echo json_encode([
        'status' => 'error', 
        'message' => 'Missing appointment ID or new status. Cannot update status.'
    ]);
    exit;
}

// Sanitize and validate the status value
$valid_statuses = ['booked', 'completed', 'cancelled', 'declined'];
$new_status = strtolower($new_status_raw);

if (!in_array($new_status, $valid_statuses)) {
    echo json_encode([
        'status' => 'error', 
        'message' => 'Invalid status provided.'
    ]);
    exit;
}

try {
    // 4. Pre-Update Fetch for Email Details 
    $fetch_query = "
        SELECT 
            a.status AS current_status, a.appointment_date, a.start_time, 
            p.email AS patient_email, 
            p.username AS patient_name, 
            d.username AS doctor_name     
        FROM appointments a
        LEFT JOIN users p ON a.patient_id = p.user_id
        LEFT JOIN users d ON a.user_id = d.user_id
        WHERE a.appointment_id = ? LIMIT 1
    ";
    $fetch_stmt = $pdo->prepare($fetch_query);
    $fetch_stmt->execute([$appointment_id]);
    $appointment_details = $fetch_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$appointment_details) {
        echo json_encode(['status' => 'error', 'message' => 'Appointment ID not found in database.']);
        exit;
    }

    $patient_email = $appointment_details['patient_email'];
    $patient_name = $appointment_details['patient_name'];
    $current_status = $appointment_details['current_status'];

    // Prevent unnecessary DB writes (status is already the same)
    if ($current_status === $new_status) {
        echo json_encode(['status' => 'error', 'message' => "Appointment ID {$appointment_id} status is already " . ucfirst($new_status) . "."]);
        exit;
    }

    // 5. Execute the SQL Update Statement
    $update_query = "
        UPDATE appointments
        SET 
            status = ?, 
            updated_at = ?
        WHERE appointment_id = ?
    ";

    $update_stmt = $pdo->prepare($update_query);
    $update_stmt->execute([$new_status, $updated_at, $appointment_id]);

    // 6. Check for success and send email
    if ($update_stmt->rowCount() > 0) {
        
        $email_message = "";
        $status_display = ucfirst($new_status);

        if ($patient_email) {
            $full_datetime = $appointment_details['appointment_date'] . ' ' . $appointment_details['start_time'];
            $appointment_date = date('F j, Y', strtotime($full_datetime));
            $appointment_time = date('h:i A', strtotime($full_datetime));

            try {
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = CONF_SMTP_USER;
                $mail->Password = CONF_SMTP_PASS;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;
                
                $mail->setFrom(CONF_SMTP_USER, 'DentiTrack Clinic');
                $mail->addAddress($patient_email, $patient_name);

                $mail->isHTML(true);
                $mail->Subject = "DentiTrack Appointment Status Update: " . $status_display;

                // Compose email body based on status
                if ($new_status === 'booked') {
                    // *** UPDATED: Professional confirmation message, removed doctor name ***
                    $body = "<h2>✅ Appointment Confirmed at DentiTrack Clinic</h2>
                    <p>Dear **{$patient_name}**, your appointment has been successfully **CONFIRMED** (Booked) at our clinic.</p>
                    <p><strong>Appointment Details:</strong></p>
                    <ul>
                        <li><strong>Date:</strong> {$appointment_date}</li>
                        <li><strong>Time:</strong> {$appointment_time}</li>
                    </ul>
                    <p>Kindly arrive 10 minutes prior to your scheduled time. We look forward to serving you!</p>";
                } elseif ($new_status === 'completed') {
                    // *** UPDATED: Removed doctor name ***
                    $body = "<h2>✅ Appointment Completed</h2>
                    <p>Thank you for visiting DentiTrack Clinic.</p>
                    <p>Your appointment on **{$appointment_date}** has been marked as **COMPLETED**.</p>
                    <p>We look forward to assisting you with your future dental needs.</p>";
                } elseif ($new_status === 'cancelled' || $new_status === 'declined') {
                    // *** UPDATED: Slight refinement for professionalism ***
                    $body = "<h2>❌ Appointment {$status_display}</h2>
                    <p>We regret to inform you that your appointment for **{$appointment_date}** at **{$appointment_time}** has been **{$status_display}**.</p>
                    <p>Please contact DentiTrack Clinic during business hours to reschedule or for any inquiries.</p>";
                } else {
                     $body = "<h2>i Appointment Status Changed</h2><p>Your appointment has been updated to the status: **$status_display**.</p>";
                }
                
                $mail->Body = $body;
                $mail->send();
                $email_message = " Email notification sent.";

            } catch (Exception $e) {
                $email_message = " Failed to send email. Mailer Error: " . $mail->ErrorInfo;
            }
        } else {
            $email_message = " Warning: Patient email address not found; skipping notification.";
        }
        
        echo json_encode([
            'status' => 'success', 
            'message' => "Appointment ID {$appointment_id} successfully marked as " . $status_display . "." . $email_message
        ]);

    } else {
        echo json_encode([
            'status' => 'error', 
            'message' => "Appointment ID {$appointment_id} not found or status is already " . ucfirst($current_status) . "."
        ]);
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error', 
        'message' => 'DB error: Unable to update status. ' . $e->getMessage()
    ]);
}
?>