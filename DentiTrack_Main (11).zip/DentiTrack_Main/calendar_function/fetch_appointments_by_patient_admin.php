<?php
require_once 'calendar_conn.php';
header('Content-Type: application/json');

$patient = trim($_GET['patient'] ?? '');
$date = trim($_GET['date'] ?? ''); 

if (empty($patient)) {
    echo json_encode(['status'=>'error','message'=>'No patient search provided.']);
    exit;
}

/* * Fetches appointments by patient name search.
 * Searches across first_name, last_name, and full name (concatenated).
 */
$query = "
    SELECT 
        a.appointment_id, 
        p.first_name, p.middle_name, p.last_name, p.contact_number, p.gender, 
        u.email, 
        s.service_name, 
        a.appointment_date, a.appointment_time, a.start_time, a.end_time, a.comments, a.status, 
        a.created_at, a.updated_at
    FROM 
        appointments a
    JOIN 
        patient p ON a.user_id = p.user_id 
    JOIN 
        users u ON a.user_id = u.user_id 
    LEFT JOIN 
        services s ON a.service_id = s.service_id 
    WHERE 
        LOWER(p.first_name) LIKE ? OR 
        LOWER(p.last_name) LIKE ? OR
        LOWER(CONCAT(p.first_name, ' ', p.last_name)) LIKE ?
";

$search_term = '%' . strtolower($patient) . '%';
$params = [$search_term, $search_term, $search_term];

// Optional date filter
if (!empty($date)) {
    $query .= " AND a.appointment_date = ?";
    $params[] = $date;
}

$query .= " ORDER BY a.appointment_date DESC, a.start_time ASC";


try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($results)) {
        echo json_encode(['status'=>'empty','appointments'=>[],'message'=>'No appointments found.']);
        exit;
    }

    $formatted = [];
    foreach ($results as $a) {
        $fullName = trim($a['first_name'] . ' ' . (empty($a['middle_name']) ? '' : $a['middle_name'] . ' ') . $a['last_name']);
        
        $formatted[] = [
            'appointment_id' => $a['appointment_id'],
            'patient_name'   => $fullName,
            'email'          => $a['email'],
            'contact_number' => $a['contact_number'],
            'gender'         => $a['gender'],
            'service'        => $a['service_name'] ?? 'N/A',
            'appointment_date' => $a['appointment_date'],
            'appointment_time' => $a['appointment_time'],
            'start_time'     => $a['start_time'],
            'end_time'       => $a['end_time'],
            'comments'       => $a['comments'],
            'status'         => ucfirst(strtolower($a['status'])),
            'created_at'     => $a['created_at'],
            'updated_at'     => $a['updated_at']
        ];
    }

    echo json_encode(['status'=>'success','appointments'=>$formatted]);

} catch (PDOException $e) {
    error_log("DB Error in fetch_appointments_by_patient_admin: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}