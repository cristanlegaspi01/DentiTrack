<?php
require_once 'calendar_conn.php';

header('Content-Type: application/json');

// Check if "date" or "id" is provided
if (isset($_GET['date'])) {
    $date = $_GET['date'];

    // Fetch all appointments for that date
    $stmt = $pdo->prepare("SELECT * FROM appointments WHERE appointment_date = ?");
    $stmt->execute([$date]);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch doctor availability for that date
    $stmt2 = $pdo->prepare("SELECT * FROM doctor_availability WHERE available_date = ?");
    $stmt2->execute([$date]);
    $availability = $stmt2->fetch(PDO::FETCH_ASSOC);

    // Build response
    echo json_encode([
        'status' => 'success',
        'appointments' => $appointments,
        'availability' => $availability
    ]);
    exit;
}

// Fallback: fetch by appointment ID
if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];

    $stmt = $pdo->prepare("SELECT * FROM appointments WHERE appointment_id = ?");
    $stmt->execute([$id]);
    $appointment = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($appointment) {
        echo json_encode(['status' => 'success', 'data' => $appointment]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Appointment not found']);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'No date or ID provided']);
?>
