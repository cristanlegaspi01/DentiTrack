<?php
require_once '../calendar_function/calendar_conn.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if (
    !empty($data['patient_name']) && 
    !empty($data['email']) && 
    !empty($data['contact_number']) && 
    !empty($data['service']) && 
    !empty($data['appointment_date']) && 
    !empty($data['appointment_time'])
) {
    $patient_name = htmlspecialchars($data['patient_name']);
    $email = htmlspecialchars($data['email']);
    $contact_number = htmlspecialchars($data['contact_number']);
    $gender = isset($data['gender']) ? htmlspecialchars($data['gender']) : '';
    $age = isset($data['age']) ? (int)$data['age'] : NULL;
    $service = htmlspecialchars($data['service']);
    $appointment_date = $data['appointment_date'];
    $appointment_time = $data['appointment_time'];
    $comments = isset($data['comments']) ? htmlspecialchars($data['comments']) : '';

    /* --------------------------------------------------------
       Prevent duplicate booking (same date + time)
    -------------------------------------------------------- */
    $check = $pdo->prepare("
        SELECT COUNT(*) 
        FROM appointments 
        WHERE appointment_date = ? 
        AND appointment_time = ? 
        AND status IN ('Pending', 'Approved')
    ");
    $check->execute([$appointment_date, $appointment_time]);
    $exists = $check->fetchColumn();

    if ($exists > 0) {
        echo json_encode([
            'status' => 'error',
            'message' => 'This time slot is already booked. Please select another time.'
        ]);
        exit;
    }

    /* --------------------------------------------------------
       Insert appointment as Pending
    -------------------------------------------------------- */
    $stmt = $pdo->prepare("
        INSERT INTO appointments 
        (patient_name, email, contact_number, gender, age, service, appointment_date, appointment_time, comments, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')
    ");
    
    $stmt->execute([
        $patient_name,
        $email,
        $contact_number,
        $gender,
        $age,
        $service,
        $appointment_date,
        $appointment_time,
        $comments
    ]);
    
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
}
?>
