-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2025 at 05:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dentitrack_main`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor_availability`
--

CREATE TABLE `doctor_availability` (
  `availability_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `available_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `is_available` tinyint(1) DEFAULT 1,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_availability`
--

INSERT INTO `doctor_availability` (`availability_id`, `doctor_id`, `available_date`, `start_time`, `end_time`, `is_available`, `reason`, `created_at`, `updated_at`) VALUES
(1, 3, '2025-10-28', '09:00:00', '17:00:00', 1, 'Regular clinic hours', '2025-10-25 16:11:24', '2025-10-25 16:11:24'),
(3, 3, '2025-10-30', '08:00:00', '12:00:00', 1, 'Morning appointments only', '2025-10-25 16:11:24', '2025-10-25 16:11:24'),
(5, 4, '2025-11-01', '00:00:00', '23:59:59', 0, 'Personal leave', '2025-10-25 16:11:24', '2025-10-25 16:11:24'),
(6, 4, '2025-11-02', '09:00:00', '15:00:00', 1, 'Available half-day', '2025-10-25 16:11:24', '2025-10-25 16:11:24'),
(10, 4, '2025-10-29', '00:00:00', '23:59:59', 0, 'Personal leave', '2025-10-28 15:37:16', '2025-10-28 15:37:16'),
(11, 4, '2025-10-30', '00:00:00', '23:59:59', 1, 'Personal leave', '2025-10-28 15:37:21', '2025-10-28 15:49:41'),
(12, 4, '2025-10-31', '00:00:00', '23:59:59', 1, 'Personal leave', '2025-10-28 15:40:11', '2025-10-28 16:07:26'),
(13, 4, '2025-10-30', '00:00:00', '23:59:59', 1, 'Personal leave', '2025-10-28 15:40:21', '2025-10-28 15:49:41'),
(14, 4, '2025-10-30', '00:00:00', '23:59:59', 1, 'Personal leave', '2025-10-28 15:41:28', '2025-10-28 15:49:41'),
(15, 4, '2025-10-30', '00:00:00', '23:59:59', 1, 'Personal leave', '2025-10-28 15:44:10', '2025-10-28 15:49:41'),
(16, 4, '2025-10-30', '00:00:00', '23:59:59', 1, 'null', '2025-10-28 15:45:20', '2025-10-28 15:49:41'),
(17, 4, '2025-10-30', '00:00:00', '23:59:59', 1, 'a', '2025-10-28 15:45:28', '2025-10-28 15:49:41'),
(18, 4, '2025-10-30', '00:00:00', '23:59:59', 1, 'Personal leave', '2025-10-28 15:49:38', '2025-10-28 15:49:41'),
(19, 4, '2025-10-30', '00:00:00', '23:59:59', 0, 'pagod na', '2025-10-28 15:54:56', '2025-10-28 15:54:56'),
(20, 4, '2025-10-31', '00:00:00', '23:59:59', 1, 'asd', '2025-10-28 16:00:58', '2025-10-28 16:07:26'),
(21, 4, '2025-10-31', '00:00:00', '23:59:59', 0, 'qwe', '2025-10-28 16:07:30', '2025-10-28 16:07:30'),
(22, 4, '2025-10-23', '00:00:00', '23:59:59', 1, '123', '2025-10-28 16:15:15', '2025-10-28 16:15:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor_availability`
--
ALTER TABLE `doctor_availability`
  ADD PRIMARY KEY (`availability_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor_availability`
--
ALTER TABLE `doctor_availability`
  MODIFY `availability_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `doctor_availability`
--
ALTER TABLE `doctor_availability`
  ADD CONSTRAINT `doctor_availability_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
