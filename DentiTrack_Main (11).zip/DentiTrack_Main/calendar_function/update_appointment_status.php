<?php
require_once 'calendar_conn.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit;
}

$appointment_id = $_POST['appointment_id'] ?? '';
$status         = strtolower(trim($_POST['status'] ?? ''));
$new_time       = $_POST['new_time'] ?? '';

if (empty($appointment_id) || empty($status)) {
    echo json_encode(['status' => 'error', 'message' => 'Missing appointment_id or status.']);
    exit;
}

// ✅ Allowed statuses: now includes declined & cancelled
$valid_statuses = ['pending', 'approved', 'declined', 'cancelled', 'rest'];
if (!in_array($status, $valid_statuses)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid status value.']);
    exit;
}

// Build SQL with optional new_time update
$sql = "UPDATE appointments SET status = ?, updated_at = NOW()";
$params = [$status];

if (!empty($new_time)) {
    $sql .= ", appointment_time = ?";
    $params[] = $new_time;
}

$sql .= " WHERE appointment_id = ?";
$params[] = $appointment_id;

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    // Custom messages based on new status
    $message = match ($status) {
        'approved'  => 'Appointment approved successfully.',
        'declined'  => 'Appointment declined.',
        'cancelled' => 'Appointment cancelled successfully.',
        'pending'   => 'Appointment marked as pending.',
        'rest'      => 'Rest day updated.',
        default     => 'Status updated successfully.'
    };

    echo json_encode([
        'status' => 'success',
        'message' => $message,
        'new_status' => $status
    ]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
