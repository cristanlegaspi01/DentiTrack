<?php
require_once 'calendar_conn.php';
header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_GET['date']) || empty($_GET['date'])) {
    echo json_encode(['error' => 'Missing date parameter']);
    exit;
}

$date = $_GET['date'];

// Get the required duration (in minutes) for the service, default to 60 (1 hour)
$durationMinutes = isset($_GET['duration']) ? (int)$_GET['duration'] : 60;
if ($durationMinutes <= 0) $durationMinutes = 60;

try {
    /* --------------------------------------------------------
       1. FETCH OCCUPIED SLOTS (The Appointments)
    -------------------------------------------------------- */
    $stmt = $pdo->prepare("
        SELECT start_time, end_time, status
        FROM appointments
        WHERE appointment_date = ?
        AND status IN ('booked', 'completed')
        ORDER BY start_time
    ");
    $stmt->execute([$date]);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Convert times to seconds since midnight for scheduling math
    $occupiedBlocks = [];
    foreach ($appointments as $appt) {
        $startSeconds = strtotime($appt['start_time']) - strtotime('TODAY');
        $endSeconds   = strtotime($appt['end_time']) - strtotime('TODAY');
        
        if ($endSeconds > $startSeconds) {
            $occupiedBlocks[] = [
                'start' => $startSeconds,
                'end'   => $endSeconds,
                'status' => strtolower($appt['status'])
            ];
        }
    }

    // Sort occupied blocks by start time
    usort($occupiedBlocks, function($a, $b) {
        return $a['start'] <=> $b['start'];
    });

    /* --------------------------------------------------------
       2. DEFINE CLINIC AVAILABILITY (5:00 AM to 8:00 PM)
    -------------------------------------------------------- */
    $clinicStartSeconds = strtotime('05:00:00') - strtotime('TODAY'); // 5:00 AM
    $clinicEndSeconds   = strtotime('20:00:00') - strtotime('TODAY'); // 8:00 PM (20:00 military time)
    $requiredSeconds    = $durationMinutes * 60;

    /* --------------------------------------------------------
       3. CALCULATE FREE TIME BLOCKS (Continuous free intervals)
    -------------------------------------------------------- */
    $freeBlocks = [];
    $currentTime = $clinicStartSeconds;
    
    foreach ($occupiedBlocks as $block) {
        // If there is a gap between the current time and the start of the occupied block
        if ($block['start'] > $currentTime) {
            $freeBlocks[] = [
                'start' => $currentTime,
                'end'   => $block['start']
            ];
        }
        // Move current time past the end of the occupied block
        $currentTime = max($currentTime, $block['end']);
    }

    // Add the final free block from the last occupied time to the clinic end time
    if ($currentTime < $clinicEndSeconds) {
        $freeBlocks[] = [
            'start' => $currentTime,
            'end'   => $clinicEndSeconds
        ];
    }


    /* --------------------------------------------------------
       4. GENERATE DYNAMIC SLOTS from Free Blocks
       Slots are exactly $requiredSeconds long, starting at the 
       beginning of the free block or after the last booked slot.
    -------------------------------------------------------- */
    $slots = [];

    foreach ($freeBlocks as $freeBlock) {
        $slotStart = $freeBlock['start'];
        $slotEnd = $freeBlock['end'];

        // Iterate through the free block, slicing it into slots of the required duration
        while (($slotStart + $requiredSeconds) <= $slotEnd) {
            $currentSlotEnd = $slotStart + $requiredSeconds;

            // Format times for display and storage (e.g., 1:30 PM - 2:00 PM)
            $timeStartFormatted = date('g:i A', $slotStart + strtotime('TODAY'));
            $timeEndFormatted   = date('g:i A', $currentSlotEnd + strtotime('TODAY'));
            $label = $timeStartFormatted . ' - ' . $timeEndFormatted;

            $slots[] = [
                'time'   => $label,
                'status' => 'available',
                'label'  => $label . ' • Available',
            ];

            // Move to the next potential start time by the required duration
            $slotStart += $requiredSeconds; 
        }
    }
    
    /* --------------------------------------------------------
       5. ADD OCCUPIED BLOCKS back for display
    -------------------------------------------------------- */
    foreach ($occupiedBlocks as $block) {
        $timeStartFormatted = date('g:i A', $block['start'] + strtotime('TODAY'));
        $timeEndFormatted   = date('g:i A', $block['end'] + strtotime('TODAY'));
        $label = $timeStartFormatted . ' - ' . $timeEndFormatted;

        $slots[] = [
            'time'   => $label,
            'status' => $block['status'],
            'label'  => $label . ' • ' . ucfirst($block['status'])
        ];
    }
    
    // Sort all slots (available and occupied) by start time
    usort($slots, function($a, $b) {
        // Extract start time from the label for comparison
        $aTime = strtotime(explode(' - ', $a['time'])[0]);
        $bTime = strtotime(explode(' - ', $b['time'])[0]);
        return $aTime <=> $bTime;
    });

    echo json_encode($slots);

} catch (PDOException $e) {
    error_log("Timeslot Fetch Error: " . $e->getMessage());
    echo json_encode(['error' => 'Database error while fetching slots.']);
}
?>