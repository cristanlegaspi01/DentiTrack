<?php
require_once '../config/db_pdo.php';

try {
  $stmt = $pdo->query("SELECT appointment_id, patient_name, service, appointment_date, appointment_time, status FROM appointments");
  $appointments = [];
  
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $color = ($row['status'] == 'approved') ? '#28a745' : (($row['status'] == 'declined') ? '#dc3545' : '#ffc107');

    $appointments[] = [
      'id' => $row['appointment_id'],
      'title' => $row['patient_name'] . ' - ' . ucfirst($row['status']),
      'start' => $row['appointment_date'],
      'color' => $color,
      'extendedProps' => [
        'service' => $row['service'],
        'time' => $row['appointment_time']
      ]
    ];
  }

  echo json_encode($appointments);
} catch (PDOException $e) {
  echo json_encode([]);
}
?>
