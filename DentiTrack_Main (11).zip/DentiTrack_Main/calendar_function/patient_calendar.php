<?php
// File: patient_calendar.php

require_once '../calendar_function/calendar_conn.php';

// --- START: Data Fetching and Duration Parsing ---

// --- IMPORTANT: Use your actual session variable here ---

$user_id = $_SESSION['user_id'] ?? 0;

if ($user_id == 0) {
    // In a live environment, you might redirect here:
    // header('Location: ../public/login.php');
    die("Access denied. Please log in to book an appointment.");
}

$patientDetails = [];
$services = [];
$jsServiceDurations = []; // Array to pass service_id => duration_minutes to JavaScript

try {
    // 1. Fetch Patient Details
    $stmt = $pdo->prepare("
        SELECT 
            u.user_id, 
            p.fullname AS full_name, 
            p.email, 
            p.contact_number, 
            p.gender
        FROM users u
        INNER JOIN patient p ON u.user_id = p.user_id
        WHERE u.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $patientDetails = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$patientDetails) {
        die("Error: Could not retrieve patient details for user ID {$user_id}. Ensure this user has an entry in the 'patient' table.");
    }

    // 2. Fetch all available services and calculate duration in minutes
    $servicesStmt = $pdo->query("
        SELECT service_id, service_name, duration, price
        FROM services 
        WHERE status = 'Active'
        ORDER BY service_name
    ");
    $services = $servicesStmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($services as $service) {
        $durationText = $service['duration'];
        $minutes = 60; // Default to 60 minutes (1 hour) if parsing fails
        
        if (preg_match('/(\d+)\s*minutes?/i', $durationText, $m)) {
            $minutes = (int)$m[1];
        } elseif (preg_match('/(\d+)\s*hours?/i', $durationText, $m)) {
            $minutes = (int)$m[1] * 60;
        } elseif (is_numeric($durationText)) {
            $minutes = (int)$durationText;
        }
        
        $jsServiceDurations[(int)$service['service_id']] = $minutes;
    }

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}

// --- END: Data Fetching and Duration Parsing ---
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>DentiTrack | Patient Calendar</title>

<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
/* (Keep your CSS styles here as they were provided in previous turns) */
.calendar-title {
    text-align: center;
    color: #333;
    margin-bottom: 10px;
}
.legend {
    display: flex;
    justify-content: center;
    gap: 15px;
    margin-bottom: 15px;
}
.legend-item { display: flex; align-items: center; gap: 6px; }
.color-box { width: 18px; height: 18px; border-radius: 3px; }

#calendar {
    max-width: 900px;
    margin: 0 auto;
    background: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

/* Calendar search bar */
#calendarSearch {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-bottom: 15px;
}
#calendarSearch select, #calendarSearch input {
    padding: 6px;
    border-radius: 6px;
    border: 1px solid #ccc;
}
#calendarSearch button {
    background-color: #0d6efd;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 6px;
    cursor: pointer;
}
#calendarSearch button:hover {
    background-color: #0b5ed7;
}

/* -------------------------------------------
    CALENDAR EVENT STATUS CLASSES
------------------------------------------- */
.status-booked { background-color: #4A90E2 !important; color: white !important; }
.status-completed { background-color: #32CD32 !important; color: black !important; }
.status-restday { background-color: #8FD19E !important; color: black !important; }

.fc-day-today {
    background-color: #e0e0e0 !important;
    color: #000 !important;
    font-weight: 600;
    border: 2px solid #b0b0b0 !important;
    border-radius: 6px;
}

/* Modal layout: left = form, right = timeslots */
.modal-body {
    display: flex;
    gap: 18px;
}
.modal-body .form-column { flex: 2; }
.modal-body .slots-column { flex: 1; border-left: 1px solid #eee; padding-left: 12px; }

/* -------------------------------------------
    TIMESLOT VISUALS (in the modal)
------------------------------------------- */
.slot {
    padding: 8px 10px;
    margin-bottom: 8px;
    border-radius: 8px;
    text-align: center;
    font-weight: 600;
}

#slotList {
    max-height: 400px; 
    overflow-y: auto;  
    padding-right: 10px; 
}

.slot.available { background: #f1f1f1; color: #111; cursor: pointer; }
.slot.booked { background: #CCE5FF; color: #004085; }
.slot.completed { background: #D4EDDA; color: #155724; }
.slot.restday { background: #8FD19E; color: #000; } 
.slot.selected { outline: 2px solid #0d6efd; }

/* hide slots panel when not populated */
.slots-empty { color: #888; text-align:center; padding: 20px 10px; }

/* Payment Section Styles */
.payment-section { border: 1px solid #0d6efd; padding: 15px; border-radius: 8px; background: #f7faff; }
.payment-section h5 { margin-top: 0; }

@media (max-width: 900px) {
    .modal-body { flex-direction: column; }
    .modal-dialog { max-width: 95%; }
}
</style>
</head>
<body>

<h2 class="calendar-title">🦷 Patient Appointment Calendar</h2>

<div id="calendarSearch">
    <select id="searchYear"></select>
    <select id="searchMonth">
        <option value="">Month</option>
        <option value="0">January</option>
        <option value="1">February</option>
        <option value="2">March</option>
        <option value="3">April</option>
        <option value="4">May</option>
        <option value="5">June</option>
        <option value="6">July</option>
        <option value="7">August</option>
        <option value="8">September</option>
        <option value="9">October</option>
        <option value="10">November</option>
        <option value="11">December</option>
    </select>
    <input type="number" id="searchDay" placeholder="Day" min="1" max="31" style="width:80px;">
    <button id="goToDate">Go</button>
</div>

<div class="legend">
    <div class="legend-item"><div class="color-box" style="background:#4A90E2;"></div> Booked</div>
    <div class="legend-item"><div class="color-box" style="background:#32CD32;"></div> Completed</div>
    <div class="legend-item"><div class="color-box" style="background:#8FD19E;"></div> Rest Day</div>
</div>

<div id="calendar"></div>

<div class="modal fade" id="appointmentModal" tabindex="-1" aria-labelledby="appointmentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="appointmentForm" enctype="multipart/form-data" method="POST"> 
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="appointmentModalLabel">Book Appointment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="form-column">
                        
                        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($patientDetails['user_id']); ?>">
                        
                        <div class="mb-2">
                            <label class="form-label">Patient:</label>
                            <p class="form-control-static fw-bold mb-0">
                                <?php echo htmlspecialchars($patientDetails['full_name']); ?> 
                                (<?php echo htmlspecialchars($patientDetails['email']); ?> | 
                                <?php echo htmlspecialchars($patientDetails['contact_number']); ?> | 
                                <?php echo htmlspecialchars($patientDetails['gender']); ?>)
                            </p>
                        </div>
                        
                        <div class="mb-2">
                            <label class="form-label">Service</label>
                            <select name="service_id" id="service_id_select" class="form-select" required onchange="togglePaymentForms()">
                                <option value="">Select Service (Duration - Price)</option>
                                <?php foreach ($services as $service): ?>
                                    <option value="<?php echo htmlspecialchars($service['service_id']); ?>" data-price="<?php echo htmlspecialchars($service['price']); ?>">
                                        <?php echo htmlspecialchars($service['service_name']); ?> (<?php echo htmlspecialchars($service['duration']); ?> - ₱<?php echo htmlspecialchars(number_format($service['price'], 2)); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-2"><label class="form-label">Appointment Date</label><input type="date" name="appointment_date" id="appointment_date" class="form-control" readonly required></div>
                        
                        <div class="mb-2"><label class="form-label">Appointment Time</label><select name="appointment_time" id="appointment_time" class="form-select" required></select></div>
                        
                        <hr>

                        <div class="mb-2">
                            <label class="form-label">Discount Type</label>
                            <select name="discount_type" id="discount_type_select" class="form-select" onchange="togglePaymentForms()">
                                <option value="None">None</option>
                                <option value="Loyalty Card (10%)">Loyalty Card (10%)</option>
                                <option value="Health Card (15%)">Health Card (15%)</option>
                            </select>
                        </div>
                        <hr>
                        <div class="mb-2 text-end">
                            <label class="form-label fw-bold">Price Before Discount:</label>
                            <span id="price_before_discount_display" class="fw-bold">₱0.00</span>
                        </div>
                        <div class="mb-2 text-end">
                            <label class="form-label fw-bold text-danger">Total Discount:</label>
                            <span id="discount_amount_display" class="fw-bold text-danger">₱0.00</span>
                        </div>
                        <div class="mb-2 text-end">
                            <label class="form-label fw-bold text-primary">Total Amount Due:</label>
                            <span id="final_price_display" class="fw-bold text-primary fs-5">₱0.00</span>
                            <input type="hidden" id="final_price_hidden" name="final_price_hidden" value="0.00">
                        </div>
                        <hr>
                        
                        <div class="mb-3 payment-section">
                            <h5 class="text-primary text-center">Payment Options</h5>
                            
                            <div class="d-flex justify-content-around mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="primary_method" id="walkInRadio" value="Walk-in" onchange="togglePaymentForms()" checked>
                                    <label class="form-check-label fw-bold" for="walkInRadio">Walk-in Payment (Downpayment)</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="primary_method" id="onlineRadio" value="Online" onchange="togglePaymentForms()">
                                    <label class="form-check-label fw-bold" for="onlineRadio">Online Payment</label>
                                </div>
                            </div>
                            
                            <div id="walk-in-form-group">
                                <div class="mb-2">
                                    <label class="form-label" for="downpayment_walkin">Downpayment Amount (₱) (Min. amount must be paid for booking)</label>
                                    <input type="number" name="amount_paid" id="downpayment_walkin" class="form-control" step="0.01" min="0" value="0.00" required>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label">Image Proof of Downpayment</label>
                                    <input type="file" name="payment_proof" id="proof_walkin" class="form-control" accept="image/*" required>
                                </div>
                            </div>
                            
                            <div id="online-form-group" style="display: none;">
                                <div class="mb-2">
                                    <label class="form-label">Online Payment Option</label>
                                    <select name="payment_type" id="payment_type_select" class="form-select" onchange="togglePaymentForms()">
                                        <option value="Full">Full Payment</option>
                                        <option value="Installment">Installment</option>
                                    </select>
                                </div>
                                
                                <div class="mb-2" id="online-downpayment-group" style="display: none;">
                                    <label class="form-label">Downpayment Amount (₱)</label>
                                    <input type="number" name="amount_paid_online_hidden" id="downpayment_online" class="form-control" step="0.01" min="0" value="0.00" oninput="calculateInstallment()"> 
                                </div>

                                <div class="mb-2" id="installment-term-group" style="display: none;">
                                    <label class="form-label">Installment Term</label>
                                    <select id="installment_term_select" name="installment_term" class="form-select" onchange="calculateInstallment()">
                                        <option value="1">1 month</option>
                                        <option value="2">2 months</option>
                                        <option value="3">3 months</option>
                                        <option value="6">6 months</option>
                                        <option value="12">12 months (1 Year)</option>
                                        <option value="24">24 months (2 Years)</option>
                                        <option value="36">36 months (3 Years)</option>
                                    </select>
                                </div>

                                <div class="mb-2" id="monthly-payment-group" style="display: none;">
                                    <label class="form-label">Monthly Payment (₱)</label>
                                    <input type="number" id="monthly_payment_input" name="monthly_payment" class="form-control" step="0.01" value="0.00" readonly>
                                </div>

                                <div class="mb-2">
                                    <label class="form-label" id="online_proof_label">Image Proof of Full Payment</label>
                                    <input type="file" name="payment_proof_online" id="proof_online" class="form-control" accept="image/*">
                                </div>
                            </div>
                        </div>
                        <div class="mb-2"><label class="form-label">Comments</label><textarea name="comments" class="form-control" rows="2" placeholder="Optional..."></textarea></div>
                    </div>
                    
                    <div class="slots-column">
                        <h6 id="slotsForDateTitle" class="mb-2 text-center">Select a date to view slots</h6>
                        <div id="slotList" class="slots-empty">No date selected</div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary w-100">Submit Appointment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const calendarEl = document.getElementById('calendar');
    const modalEl = document.getElementById('appointmentModal');
    const modal = new bootstrap.Modal(modalEl);
    const slotListEl = document.getElementById('slotList');
    const appointmentDateInput = document.getElementById('appointment_date');
    const appointmentTimeSelect = document.getElementById('appointment_time');
    const slotsForDateTitle = document.getElementById('slotsForDateTitle');
    const appointmentForm = document.getElementById('appointmentForm');
    
    const serviceSelect = document.getElementById('service_id_select');
    
    // Payment Elements
    const walkInGroup = document.getElementById('walk-in-form-group');
    const onlineGroup = document.getElementById('online-form-group');
    const paymentTypeSelect = document.getElementById('payment_type_select');
    const onlineProofLabel = document.getElementById('online_proof_label');
    
    // Discount Elements
    const discountSelect = document.getElementById('discount_type_select');
    const finalPriceHiddenInput = document.getElementById('final_price_hidden');
    const priceBeforeDiscountDisplay = document.getElementById('price_before_discount_display');
    const discountAmountDisplay = document.getElementById('discount_amount_display');
    const finalPriceDisplay = document.getElementById('final_price_display');

    // Specific inputs for managing required attribute and name
    const proofWalkinInput = document.getElementById('proof_walkin');
    const downpaymentWalkinInput = document.getElementById('downpayment_walkin'); 
    const proofOnlineInput = document.getElementById('proof_online');
    const downpaymentOnlineInput = document.getElementById('downpayment_online'); 
    const onlineDownpaymentGroup = document.getElementById('online-downpayment-group'); 

    // Installment Elements
    const installmentTermGroup = document.getElementById('installment-term-group');
    const monthlyPaymentGroup = document.getElementById('monthly-payment-group');
    const installmentTermSelect = document.getElementById('installment_term_select');
    const monthlyPaymentInput = document.getElementById('monthly_payment_input');

    // Service durations passed from PHP
    const SERVICE_DURATIONS = <?php echo json_encode($jsServiceDurations); ?>;

    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        selectable: true,
        events: '../calendar_function/fetch_appointments_patient.php',
        select: async function(info) {
            const date = info.startStr;
            const today = new Date().toISOString().split('T')[0];
            if (date < today) { alert("You cannot book an appointment on a past date."); return; }

            const restDays = calendar.getEvents().filter(e => (e.extendedProps.status && e.extendedProps.status.toLowerCase() === 'rest day' && e.startStr === date));
            if (restDays.length > 0) { alert("This day is marked as a doctor's rest day."); return; }
            
            const selectedServiceId = serviceSelect.value;
            const duration = SERVICE_DURATIONS[selectedServiceId] || 60; 

            appointmentDateInput.value = date;
            appointmentTimeSelect.innerHTML = '';
            await loadSlotsIntoModal(date, duration);
            modal.show();
        },
        eventDidMount: function(info) {
            const status = (info.event.extendedProps.status || '').toLowerCase();
            if (status === 'booked') info.el.classList.add('status-booked');
            else if (status === 'completed') info.el.classList.add('status-completed');
            else if (status === 'rest day') info.el.classList.add('status-restday');
        },
        eventContent: function(arg) {
            const status = arg.event.extendedProps.status;
            const count = arg.event.extendedProps.count; 

            let contentHtml;
            if (status === 'Rest Day') {
                contentHtml = `<div style="font-weight:700; font-size:0.95rem; text-align:center;">${status}</div>`;
            } else if ((status === 'Booked' || status === 'Completed' || status === 'Pending_payment') && count > 0) {
                contentHtml = `<div style="font-weight:700; font-size:0.95rem; text-align:center;">${status}: ${count}</div>`;
            } else {
                contentHtml = `<div style="font-weight:700; font-size:0.95rem; text-align:center;">${arg.event.title}</div>`;
            }
            
            return { html: contentHtml };
        }
    });
    calendar.render();

    modalEl.addEventListener('hidden.bs.modal', function () {
        slotListEl.innerHTML = '<div class="slots-empty">No date selected</div>';
        appointmentTimeSelect.innerHTML = '';
        slotsForDateTitle.textContent = 'Select a date to view slots';
        appointmentForm.reset();
        togglePaymentForms(); 
        setupInputFocus(downpaymentWalkinInput, '0.00'); // Re-apply focus fix
        setupInputFocus(downpaymentOnlineInput, '500.00'); // Re-apply focus fix
    });
    
    serviceSelect.addEventListener('change', async function() {
        const selectedDate = appointmentDateInput.value;
        const selectedServiceId = this.value;
        
        appointmentTimeSelect.innerHTML = '';
        
        if (selectedDate) {
            const duration = SERVICE_DURATIONS[selectedServiceId] || 60;
            await loadSlotsIntoModal(selectedDate, duration);
        }
        togglePaymentForms(); 
    });

    // --- Installment Calculation Function ---
    window.calculateInstallment = function() {
        const finalPriceStr = finalPriceHiddenInput.value;
        const finalAmount = parseFloat(finalPriceStr) || 0;
        const downpayment = parseFloat(downpaymentOnlineInput.value) || 0;
        const term = parseInt(installmentTermSelect.value) || 1;
        
        const remainingBalance = finalAmount - downpayment;
        
        if (remainingBalance > 0 && term > 0) {
            const monthly = remainingBalance / term;
            monthlyPaymentInput.value = monthly.toFixed(2);
        } else {
            monthlyPaymentInput.value = '0.00';
        }
    }
    // --- END Installment Calculation Function ---
    
    // --- UPDATED Payment Form Toggling & Calculation Logic ---
    window.togglePaymentForms = function() {
        const primaryMethod = document.querySelector('input[name="primary_method"]:checked')?.value;
        const paymentType = paymentTypeSelect.value;
        const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
        
        // --- 1. DISCOUNT AND FINAL PRICE CALCULATION ---
        let basePrice = selectedOption && selectedOption.value ? parseFloat(selectedOption.getAttribute('data-price')) : 0;
        const discountType = discountSelect.value;
        let discountRate = 0;
        
        if (discountType.includes('Loyalty Card')) discountRate = 0.10;
        else if (discountType.includes('Health Card')) discountRate = 0.15;
        
        let discountAmount = basePrice * discountRate;
        let finalPrice = basePrice - discountAmount;
        
        // Update Display Fields
        priceBeforeDiscountDisplay.textContent = `₱${basePrice.toFixed(2)}`;
        discountAmountDisplay.textContent = `₱${discountAmount.toFixed(2)}`;
        finalPriceDisplay.textContent = `₱${finalPrice.toFixed(2)}`;
        finalPriceHiddenInput.value = finalPrice.toFixed(2); 
        // --- END CALCULATION ---

        // 2. Reset all required attributes/names for a clean slate
        proofWalkinInput.removeAttribute('required');
        downpaymentWalkinInput.removeAttribute('required');
        downpaymentWalkinInput.name = 'amount_paid_walkin_hidden'; 
        proofOnlineInput.removeAttribute('required');
        downpaymentOnlineInput.removeAttribute('required');
        downpaymentOnlineInput.name = 'amount_paid_online_hidden'; 
        
        // Reset installment fields
        installmentTermGroup.style.display = 'none';
        monthlyPaymentGroup.style.display = 'none';
        
        // Set default values if empty
        if (downpaymentWalkinInput.value === '') downpaymentWalkinInput.value = '0.00';
        if (downpaymentOnlineInput.value === '') downpaymentOnlineInput.value = '500.00'; 
        
        // NOTE: File input value clearing is tricky due to security restrictions. We rely on the name switch.
        
        if (primaryMethod === 'Walk-in') {
            walkInGroup.style.display = 'block';
            onlineGroup.style.display = 'none';
            
            // Walk-in requirements (Downpayment)
            proofWalkinInput.setAttribute('required', 'required');
            downpaymentWalkinInput.setAttribute('required', 'required');
            downpaymentWalkinInput.name = 'amount_paid'; 
            
        } else { // primaryMethod === 'Online'
            walkInGroup.style.display = 'none';
            onlineGroup.style.display = 'block';
            
            if (paymentType === 'Full') {
                // Online: Full Payment
                onlineDownpaymentGroup.style.display = 'none';
                onlineProofLabel.textContent = `Image Proof of Full Payment (₱${finalPrice.toFixed(2)})`;
                proofOnlineInput.setAttribute('required', 'required');
                
                // Pass the FULL final price amount to the server in the generic 'amount_paid' field
                downpaymentWalkinInput.name = 'amount_paid'; 
                downpaymentWalkinInput.value = finalPrice.toFixed(2); 
                downpaymentWalkinInput.removeAttribute('required'); 

            } else if (paymentType === 'Installment') { 
                // Online: Installment (Downpayment)
                onlineDownpaymentGroup.style.display = 'block'; 
                onlineProofLabel.textContent = 'Image Proof of Downpayment (Min. amount must be paid for booking)';
                proofOnlineInput.setAttribute('required', 'required');
                downpaymentOnlineInput.setAttribute('required', 'required');
                
                // Show installment fields
                installmentTermGroup.style.display = 'block';
                monthlyPaymentGroup.style.display = 'block';

                // Use the online downpayment input for the final submission name
                downpaymentOnlineInput.name = 'amount_paid';
                
                calculateInstallment();
            }
        }
    }


    // loadSlotsIntoModal function (Existing)
    async function loadSlotsIntoModal(date, durationMinutes = 60) {
        slotListEl.innerHTML = '<div class="slots-empty">Loading slots...</div>';
        appointmentTimeSelect.innerHTML = '';
        
        const url = `../calendar_function/fetch_timeslots_patient.php?date=${encodeURIComponent(date)}&duration=${durationMinutes}`;
        
        try {
            const res = await fetch(url);
            if (!res.ok) throw new Error('Network error');
            const slots = await res.json();
            const d = new Date(date);
            slotsForDateTitle.textContent = d.toDateString();
            if (!Array.isArray(slots) || slots.length === 0) {
                slotListEl.innerHTML = '<div class="slots-empty">No available slots in the 5AM - 8PM window.</div>';
                return;
            }
            slotListEl.innerHTML = '';
            
            const isHourlyDefault = durationMinutes === 60 && !serviceSelect.value;

            slots.forEach(slot => {
                const label = slot.time_label || slot.time || '';
                const status = (slot.status || '').toLowerCase(); 
                const div = document.createElement('div');
                div.classList.add('slot', status);
                
                let displayLabel = label;
                if(status === 'available') {
                    displayLabel += isHourlyDefault ? ' • Standard Slot' : ` • Available (${durationMinutes} min)`;
                } else if(status === 'booked') displayLabel += ' • Booked';
                else if(status === 'completed') displayLabel += ' • Completed';
                else if(status === 'restday') displayLabel += ' • Rest Day';

                div.textContent = displayLabel;

                if (status === 'available') {
                    div.addEventListener('click', function () {
                        appointmentTimeSelect.innerHTML = '';
                        const opt = document.createElement('option');
                        opt.value = label;
                        opt.textContent = label;
                        appointmentTimeSelect.appendChild(opt);
                        document.querySelectorAll('#slotList .slot').forEach(s => s.classList.remove('selected'));
                        div.classList.add('selected');
                    });
                }
                slotListEl.appendChild(div);
            });
            const hasAvailable = slots.some(s => (s.status || '').toLowerCase() === 'available');
            if (!hasAvailable) appointmentTimeSelect.innerHTML = '<option value="">No available times</option>';
        } catch (err) {
            slotListEl.innerHTML = '<div class="slots-empty">Failed to load slots.</div>';
            appointmentTimeSelect.innerHTML = '<option value="">Error</option>';
        }
    }

    // --- CRITICAL CHANGE: Form Submission Handler (File Renaming Fix) ---
    appointmentForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        
        // Re-run calculation before submission to ensure hidden fields and names are correctly set
        togglePaymentForms(); 

        const primaryMethod = document.querySelector('input[name="primary_method"]:checked').value;
        const paymentType = document.getElementById('payment_type_select').value;
        
        // -------------------------------------------------------------------
        // 🔥 FIX: RENAME THE ACTIVE FILE INPUT TO A CONSISTENT NAME FOR SUBMISSION
        // -------------------------------------------------------------------
        let activeFileInput;
        let unusedFileInput;

        if (primaryMethod === 'Walk-in') {
            activeFileInput = proofWalkinInput;      
            unusedFileInput = proofOnlineInput;      
        } else { // primaryMethod === 'Online'
            activeFileInput = proofOnlineInput;      
            unusedFileInput = proofWalkinInput;      
        }

        // Temporarily rename the active input to a consistent name
        const originalActiveName = activeFileInput.name;
        const originalUnusedName = unusedFileInput.name;
        
        activeFileInput.name = 'uploaded_proof_image';
        // Temporarily rename the unused input to ensure it's ignored
        unusedFileInput.name = 'unused_proof_image'; 
        
        // Now create FormData with the new, clean names
        const formData = new FormData(this);
        
        // Restore original names immediately after creating FormData
        activeFileInput.name = originalActiveName; 
        unusedFileInput.name = originalUnusedName; 
        
        // Also explicitly remove the 'unused' image field from the FormData
        formData.delete('unused_proof_image');
        // -------------------------------------------------------------------
        
        // --- CLEAN UP UNUSED AMOUNT/INSTALLMENT FIELDS (Existing logic) ---
        if (primaryMethod === 'Walk-in') {
            formData.delete('payment_type'); 
            formData.delete('amount_paid_online_hidden'); 
            formData.delete('installment_term');
            formData.delete('monthly_payment');

        } else { // primaryMethod === 'Online'
            formData.delete('amount_paid_walkin_hidden'); 
            
            if (paymentType === 'Full') {
                formData.delete('installment_term');
                formData.delete('monthly_payment');
            }
        }
        
        // --- END CLEAN UP ---
        
        if (!formData.get('appointment_time')) { alert('Please select an available time.'); return; }
        if (!formData.get('service_id')) { alert('Please select a service.'); return; } 

        
        try {
            const res = await fetch('../calendar_function/insert_appointment_and_payment_patient.php', {
                method: 'POST', 
                body: formData // Send as FormData for file upload
            });
            const resp = await res.json();
            if (resp.status === 'success') {
                alert('✅ Appointment successfully booked! Payment details received. Status is now pending verification.');
                modal.hide();
                calendar.refetchEvents();
            } else alert('❌ ' + (resp.message || 'Unable to submit.'));
        } catch (err) { alert('❌ Submission failed.'); }
    });

    // ------------------------------------------------------------------
    // Helper function to clear 0.00/500.00 on focus and restore on blur
    // ------------------------------------------------------------------
    function setupInputFocus(inputElement, defaultValue) {
        inputElement.addEventListener('focus', function() {
            if (this.value === defaultValue) {
                this.value = '';
            }
        });
        inputElement.addEventListener('blur', function() {
            if (this.value === '') {
                this.value = defaultValue;
                // Re-calculate installment if this is the online downpayment field
                if (this.id === 'downpayment_online') {
                    calculateInstallment();
                }
            }
        });
    }
    
    // Initial call to set form state correctly
    togglePaymentForms();

    // Apply the focus/blur fix immediately after initial togglePaymentForms runs
    setupInputFocus(downpaymentWalkinInput, '0.00');
    setupInputFocus(downpaymentOnlineInput, '500.00'); 
    // ------------------------------------------------------------------


    // 🔍 Calendar Search Bar Logic (Existing)
    const yearSelect = document.getElementById('searchYear');
    const monthSelect = document.getElementById('searchMonth');
    const dayInput = document.getElementById('searchDay');
    const goButton = document.getElementById('goToDate');

    const currentYear = new Date().getFullYear();
    for (let y = currentYear - 2; y <= currentYear + 2; y++) {
        const opt = document.createElement('option');
        opt.value = y; opt.textContent = y;
        if (y === currentYear) opt.selected = true;
        yearSelect.appendChild(opt);
    }

    goButton.addEventListener('click', function () {
        const y = yearSelect.value;
        const m = monthSelect.value;
        const d = dayInput.value;
        if (y && m !== "" && d) {
            const targetDate = new Date(y, m, d);
            calendar.gotoDate(targetDate);
        } else if (y && m !== "") {
            const targetDate = new Date(y, m);
            calendar.gotoDate(targetDate);
        } else {
            alert("Please select at least a year and month.");
        }
    });
});
</script>
</body>
</html>