<?php
// FILE: ../calendar_function/email_helpers.php
require_once '../config/db_pdo.php';
// Corrected paths (up two levels) to access libraries and configuration files in the project root
require '../phpmailer-master/src/PHPMailer.php';
require '../phpmailer-master/src/SMTP.php';
require '../phpmailer-master/src/Exception.php';
require '../vendor/autoload.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__ . "/..");
$dotenv->load();


date_default_timezone_set("Asia/Manila");

// Centralized SMTP Configuration function
function configureMailer() {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = $_ENV['SMTP_USER']; 
    $mail->Password   = $_ENV['SMTP_PASS']; 
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->setFrom($_ENV['SMTP_USER'], 'DentiTrack Clinic');
    $mail->isHTML(true);
    return $mail;
}

/**
 * Sends a generic appointment confirmation email (for Approval/Declined/Cancelled).
 * @param array $data Appointment and patient details.
 * @param string $type 'Approved', 'Declined', or 'Cancelled'.
 * @return bool True on success, False on failure.
 */
function sendAppointmentEmail($data, $type) {
    try {
        $mail = configureMailer();
        $mail->addAddress($data['email'], $data['patient_name']);
        
        $date = date("F j, Y", strtotime($data['appointment_date']));
        $time = date("h:i A", strtotime($data['appointment_time']));

        switch ($type) {
            case 'Approved':
                $mail->Subject = 'Appointment Approved - DentiTrack';
                $mail->Body    = "
                    <h3>Dear {$data['patient_name']}, Your appointment has been Approved!</h3>
                    <p>We are pleased to confirm your dental appointment with DentiTrack.</p>
                    <p><strong>Details:</strong><br>Date: {$date}<br>Time: {$time}<br>Service: {$data['service']}</p>";
                break;
            case 'Declined':
                $mail->Subject = 'Appointment Status - DentiTrack';
                $mail->Body    = "<h3>Dear {$data['patient_name']}, your appointment request for {$date} has been Declined.</h3>";
                break;
            case 'Cancelled':
                $mail->Subject = 'Appointment Cancelled - DentiTrack';
                $mail->Body    = "<h3>Dear {$data['patient_name']}, your appointment for {$date} at {$time} has been Cancelled.</h3>";
                break;
            default: return false;
        }

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email sending error ($type): " . $e->getMessage());
        return false;
    }
}

/**
 * Sends an appointment reminder email.
 * @param array $data Appointment and patient details.
 * @return bool True on success, False on failure.
 */
function sendReminderEmail($data) {
    try {
        $mail = configureMailer();
        $mail->addAddress($data['email'], $data['patient_name']);
        
        $date = date("F j, Y", strtotime($data['appointment_date']));
        $time = date("h:i A", strtotime($data['appointment_time']));
        $service = $data['service'];

        $mail->Subject = '⏰ Gentle Reminder: Upcoming Appointment with DentiTrack';
        $mail->Body    = "
            <h3>Hi {$data['patient_name']}, this is a friendly reminder!</h3>
            <p>You have a scheduled appointment coming up soon.</p>
            <p><strong>Appointment Details:</strong></p>
            <ul>
                <li><strong>Date:</strong> {$date}</li>
                <li><strong>Time:</strong> {$time}</li>
                <li><strong>Service:</strong> {$service}</li>
            </ul>
            <p>We look forward to seeing you!</p>
            <p style='font-size: 12px; color: #888;'>This is an automated reminder.</p>
        ";
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Reminder email sending error: " . $e->getMessage());
        return false;
    }
}

/**
 * Sends an OTP email (included for completeness/reusability).
 */
function sendOtpEmail($email, $otp, $name = 'User') {
    try {
        $mail = configureMailer();
        $mail->addAddress($email, $name);
        $mail->Subject = 'DentiTrack Password Reset OTP';
        $mail->Body = "<h3>Your OTP code is: <b>$otp</b></h3><p>Expires in 10 minutes.</p>";
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("OTP email sending error: " . $e->getMessage());
        return false;
    }
}
?>