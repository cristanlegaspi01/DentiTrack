-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2025 at 05:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dentitrack_main`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` varchar(50) NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `status` enum('pending','approved','declined','rest') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `patient_name`, `email`, `contact_number`, `gender`, `age`, `service`, `appointment_date`, `appointment_time`, `start_time`, `end_time`, `comments`, `status`, `created_at`, `updated_at`) VALUES
(1, 'tonton', 'tonton@gmail.com', '09123456789', 'Male', 32, 'Tooth Extraction', '2025-10-01', '2pm-3pm', '14:00:00', '15:00:00', 'sakit ipin ko ehh', 'approved', '2025-10-28 10:04:48', '2025-10-28 16:53:43'),
(3, 'johntony', 'johnthony@gmail.com', '09123456789', 'Female', 69, 'Braces', '2025-10-01', '4pm-5pm', '16:00:00', '17:00:00', 'nangangagat kasi ako ng bakla', 'approved', '2025-10-28 13:11:23', '2025-10-28 16:53:43'),
(4, '123321', '123@gmail.com', '09123456789', 'Male', 120, 'Tooth Extraction', '2025-10-04', '5pm-6pm', '17:00:00', '18:00:00', '123', 'approved', '2025-10-28 14:54:15', '2025-10-28 16:53:43'),
(5, 'johndrei', 'johndrei@gmail.com', '09123456789', 'Female', 120, 'Dental Cleaning', '2025-10-04', '5pm-6pm', '17:00:00', '18:00:00', '123', 'pending', '2025-10-28 16:07:14', '2025-10-28 16:53:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
