<?php
// Must ensure the connection file is included
require_once 'calendar_conn.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Sanitize and retrieve input data
    $appointment_id = $_POST['appointment_id'] ?? null;
    $new_status = $_POST['status'] ?? null;

    // 2. Input Validation
    if (!$appointment_id || !$new_status) {
        http_response_code(400);
        die("Error: Missing appointment ID or status.");
    }
    
    // FINAL REVISION: Use the actual ENUM values from the 'appointments' table.
    $allowed_statuses = ['booked', 'completed', 'cancelled', 'rest'];
    
    if (!in_array(strtolower($new_status), $allowed_statuses)) {
        http_response_code(400);
        die("Error: Invalid status value provided: " . htmlspecialchars($new_status) . ". Allowed are: " . implode(', ', $allowed_statuses) . ".");
    }

    try {
        // 3. Prepare the SQL statement for a direct update
        $stmt = $pdo->prepare("UPDATE appointments SET status = :status WHERE appointment_id = :id");
        
        $db_status = strtolower($new_status);
        $stmt->bindParam(':status', $db_status);
        $stmt->bindParam(':id', $appointment_id);
        
        $stmt->execute();

        if ($stmt->rowCount()) {
            // Display 'Booking' instead of 'booked' in the success message
            $display_status = ($db_status === 'booked') ? 'Booking' : ucfirst($db_status);
            echo "Appointment status successfully updated to " . $display_status . ".";
        } else {
            echo "Update acknowledged, but no change detected (status may have been the same, or ID not found).";
        }

    } catch (PDOException $e) {
        // 4. Error Handling
        http_response_code(500);
        die("Database Error: " . $e->getMessage());
    }
} else {
    http_response_code(405);
    die("Method Not Allowed.");
}
?>