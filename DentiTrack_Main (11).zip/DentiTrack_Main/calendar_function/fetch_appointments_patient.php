<?php
// File: fetch_appointments_patient.php
require_once 'calendar_conn.php';
header('Content-Type: application/json');

$events = [];

/* ------------------------------------------
   STATUS COLORS FOR CALENDAR LEGEND
   (ADDED 'pending_payment')
------------------------------------------- */
$statusColors = [
    'booked'            => '#4A90E2',  // Blue color for Booked
    'completed'         => '#32CD32',  // Lime Green for Completed
    'cancelled'         => '#FF6F61', // Red/Orange color for Cancelled
    'pending_payment'   => '#FFB74D', // Orange color for Pending Payment (NEW)
];

/* ------------------------------------------
   FETCH GROUPED APPOINTMENTS BY DATE
   (UPDATED TO INCLUDE 'pending_payment')
------------------------------------------- */
$query = "
    SELECT 
        appointment_date, 
        CASE 
            WHEN LOWER(status) = 'booked' THEN 'booked' 
            WHEN LOWER(status) = 'completed' THEN 'completed'
            WHEN LOWER(status) = 'cancelled' THEN 'cancelled'
            WHEN LOWER(status) = 'pending_payment' THEN 'pending_payment' -- NEW
            ELSE 'other'
        END AS display_status, 
        COUNT(*) AS total
    FROM appointments
    WHERE LOWER(status) IN ('booked', 'completed', 'cancelled', 'pending_payment') -- UPDATED
    GROUP BY appointment_date, display_status
";
$stmt = $pdo->query($query);

/* ------------------------------------------
   COMBINE COUNTS FOR SAME DATE & STATUS
------------------------------------------- */
$grouped = [];

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $date = $row['appointment_date'];
    $status = $row['display_status'];
    $total = (int)$row['total'];
    
    if (!isset($grouped[$date])) {
        $grouped[$date] = [];
    }
    $grouped[$date][$status] = $total;
}

/* ------------------------------------------
   FORMAT EVENTS FOR FULLCALENDAR
------------------------------------------- */
foreach ($grouped as $date => $statuses) {
    foreach ($statuses as $status => $count) {
        if ($count <= 0) continue;

        $color = $statusColors[strtolower($status)] ?? '#CCCCCC';
        
        // Use white text for dark backgrounds, black for light backgrounds.
        $textColor = (in_array(strtolower($status), ['booked', 'cancelled', 'pending_payment'])) ? 'white' : 'black'; 

        $events[] = [
            'title' => ucwords(str_replace('_', ' ', $status)) . ": $count",
            'start' => $date,
            'color' => $color,
            'textColor' => $textColor, 
            'display' => 'block',
            'extendedProps' => [
                'status' => $status,
                'count'  => $count
            ]
        ];
    }
}

/* ------------------------------------------
   FETCH DOCTOR REST DAYS 
------------------------------------------- */
$queryRest = "
    SELECT available_date, reason
    FROM doctor_availability
    WHERE is_available = 0
";
$stmtRest = $pdo->query($queryRest);

while ($row = $stmtRest->fetch(PDO::FETCH_ASSOC)) {
    $events[] = [
        'title' => 'Rest Day',
        'start' => $row['available_date'],
        'color' => '#8FD19E',
        'textColor' => 'black',
        'display' => 'background',
        'extendedProps' => [
            'status' => 'rest_day',
            'reason' => $row['reason']
        ]
    ];
}

echo json_encode($events);