<?php
require_once '../calendar_function/calendar_conn.php';

$name = $_GET['name'] ?? '';
$showAll = isset($_GET['showAll']) ? (int)$_GET['showAll'] : 0;
$today = date('Y-m-d');

if ($name === '') { echo json_encode([]); exit; }

$sql = "SELECT appointment_id, patient_name, service, appointment_date, appointment_time
        FROM appointments
        WHERE status = 'Approved' AND patient_name LIKE ?";
$params = ["%$name%"];

if (!$showAll) {
  $sql .= " AND appointment_date >= ?";
  $params[] = $today;
}

$stmt = $conn->prepare($sql);
$stmt->execute($params);
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
