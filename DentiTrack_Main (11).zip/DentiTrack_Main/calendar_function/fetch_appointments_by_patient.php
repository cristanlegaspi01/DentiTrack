<?php
require_once '../calendar_function/calendar_conn.php';
header('Content-Type: application/json');

$date = trim($_GET['date'] ?? '');    // optional now
$search = trim($_GET['search'] ?? '');

// If no search provided, return error
if (empty($search)) {
    echo json_encode(['status'=>'error','message'=>'No patient search provided.']);
    exit;
}

// Build base query
$query = "
    SELECT 
        appointment_id,
        patient_name,
        email,
        contact_number,
        gender,
        age,
        service,
        appointment_date,
        appointment_time,
        start_time,
        end_time,
        comments,
        status,
        created_at,
        updated_at
    FROM appointments
    WHERE LOWER(patient_name) LIKE ?
";

// parameters
$params = ['%' . strtolower($search) . '%'];

// If date provided, filter by date
if (!empty($date)) {
    $query .= " AND appointment_date = ?";
    $params[] = $date;
}

// Exclude declined/cancelled? (optional) — include all statuses so secretary can manage them
// Order by date desc then time asc
$query .= " ORDER BY appointment_date DESC, appointment_time ASC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($results)) {
        echo json_encode(['status'=>'empty','message'=>'No appointments found.']);
        exit;
    }

    $formatted = [];
    foreach ($results as $a) {
        $formatted[] = [
            'appointment_id' => $a['appointment_id'],
            'patient_name'   => $a['patient_name'],
            'email'          => $a['email'],
            'contact_number' => $a['contact_number'],
            'gender'         => $a['gender'],
            'age'            => $a['age'],
            'service'        => $a['service'],
            'appointment_date' => $a['appointment_date'],
            'appointment_time' => $a['appointment_time'],
            'start_time'     => $a['start_time'],
            'end_time'       => $a['end_time'],
            'comments'       => $a['comments'],
            'status'         => ucfirst(strtolower($a['status'])),
            'created_at'     => $a['created_at'],
            'updated_at'     => $a['updated_at']
        ];
    }

    echo json_encode(['status'=>'success','appointments'=>$formatted]);

} catch (PDOException $e) {
    echo json_encode(['status'=>'error','message'=>'Database error: '.$e->getMessage()]);
}
?>
