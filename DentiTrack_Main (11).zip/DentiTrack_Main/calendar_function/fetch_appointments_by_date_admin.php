<?php
require_once 'calendar_conn.php';
header('Content-Type: application/json');

$date = $_GET['date'] ?? '';

if (empty($date)) {
    echo json_encode(['status' => 'error', 'message' => 'No date provided.']);
    exit;
}

/*
 * Fetches appointments for a specific date. 
 * Joins appointments (a), patient (p), users (u), and services (s) using user_id.
 */
$query = "
    SELECT 
        a.appointment_id, 
        p.first_name, p.middle_name, p.last_name, p.contact_number, p.gender, 
        u.email, 
        s.service_name, 
        a.appointment_date, a.appointment_time, a.start_time, a.end_time, a.comments, a.status, 
        a.created_at, a.updated_at
    FROM 
        appointments a
    JOIN 
        patient p ON a.user_id = p.user_id 
    JOIN 
        users u ON a.user_id = u.user_id 
    LEFT JOIN 
        services s ON a.service_id = s.service_id 
    WHERE 
        a.appointment_date = ?
    ORDER BY 
        a.start_time ASC
";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute([$date]);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($appointments)) {
        echo json_encode([
            'status' => 'empty',
            'appointments' => [],
            'message' => 'No appointments found for this date.'
        ]);
        exit;
    }

    // Format for JSON response
    $formatted = [];
    foreach ($appointments as $a) {
        $fullName = trim($a['first_name'] . ' ' . (empty($a['middle_name']) ? '' : $a['middle_name'] . ' ') . $a['last_name']);
        
        $formatted[] = [
            'appointment_id' => $a['appointment_id'],
            'patient_name'   => $fullName,
            'email'          => $a['email'],
            'contact_number' => $a['contact_number'],
            'gender'         => $a['gender'],
            'service'        => $a['service_name'] ?? 'N/A', 
            'appointment_date' => $a['appointment_date'],
            'appointment_time' => $a['appointment_time'],
            'start_time'     => $a['start_time'],
            'end_time'       => $a['end_time'],
            'comments'       => $a['comments'],
            'status'         => ucfirst(strtolower($a['status'])),
            'created_at'     => $a['created_at'],
            'updated_at'     => $a['updated_at']
        ];
    }

    echo json_encode(['status' => 'success', 'appointments' => $formatted]);

} catch (PDOException $e) {
    error_log("DB Error in fetch_appointments_by_date_admin: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}