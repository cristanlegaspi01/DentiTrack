<?php
require_once '../calendar_function/calendar_conn.php';

$events = [];

// -----------------------------------------------------------
// 🧩 NORMAL CALENDAR LOAD (Approved + Rest Days)
// -----------------------------------------------------------
$query = "SELECT appointment_id, patient_name, appointment_date, appointment_time, service, status
          FROM appointments
          WHERE LOWER(TRIM(status)) = 'approved'
          ORDER BY appointment_date, appointment_time";
$stmt = $pdo->query($query);

$grouped = [];

// ✅ Group by date
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
  $date = $row['appointment_date'];
  if (!isset($grouped[$date])) {
    $grouped[$date] = [];
  }
  $grouped[$date][] = $row;
}

// ✅ Add one calendar event per date
foreach ($grouped as $date => $appointments) {
  $events[] = [
    'title' => 'Approved (' . count($appointments) . ')',
    'start' => $date,
    'color' => '#4A90E2',
    'textColor' => 'white',
    'allDay' => true,
    'extendedProps' => [
      'status' => 'Approved',
      'appointments' => $appointments
    ]
  ];
}

// ✅ Fetch rest days
$queryRest = "SELECT available_date, reason FROM doctor_availability WHERE is_available = 0";
$stmtRest = $pdo->query($queryRest);

while ($row = $stmtRest->fetch(PDO::FETCH_ASSOC)) {
  $events[] = [
    'title' => 'Rest Day',
    'start' => $row['available_date'],
    'color' => '#8FD19E',
    'textColor' => 'black',
    'allDay' => true,
    'extendedProps' => [
      'status' => 'Rest Day',
      'reason' => $row['reason']
    ]
  ];
}

// -----------------------------------------------------------
// 🧩 ADDED FUNCTION: FILTER BY PATIENT NAME OR DATE
// -----------------------------------------------------------

if (isset($_GET['search'])) {
  $name = $_GET['name'] ?? '';
  $date = $_GET['date'] ?? '';

  $conditions = ["LOWER(TRIM(status)) = 'approved'"];
  $params = [];

  if (!empty($name)) {
    $conditions[] = "LOWER(patient_name) LIKE ?";
    $params[] = "%" . strtolower(trim($name)) . "%";
  }

  if (!empty($date)) {
    $conditions[] = "appointment_date = ?";
    $params[] = $date;
  }

  $sql = "SELECT appointment_id, patient_name, appointment_date, appointment_time, service, status
          FROM appointments
          WHERE " . implode(" AND ", $conditions) . "
          ORDER BY appointment_date, appointment_time";

  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $filtered = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // ✅ Format for calendar
  $filteredEvents = [];
  foreach ($filtered as $row) {
    $filteredEvents[] = [
      'title' => $row['patient_name'] . " (" . $row['service'] . ")",
      'start' => $row['appointment_date'] . 'T' . $row['appointment_time'],
      'color' => '#FFB84D',
      'textColor' => 'black',
      'extendedProps' => [
        'status' => $row['status']
      ]
    ];
  }

  header('Content-Type: application/json');
  echo json_encode($filteredEvents);
  exit;
}

// -----------------------------------------------------------
// ✅ Default output: Calendar events
// -----------------------------------------------------------
header('Content-Type: application/json');
echo json_encode($events);
?>
