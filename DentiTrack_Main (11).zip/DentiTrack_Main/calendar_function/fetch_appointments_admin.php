<?php
require_once 'calendar_conn.php';
header('Content-Type: application/json');

/*
 * FINAL REVISION: Fetches appointments using the official DB ENUM statuses
 * ('booked', 'completed', 'cancelled', 'rest') and aggregates them
 * for the FullCalendar display, using the final requested color scheme.
 */
$query = "
    SELECT 
        appointment_date, 
        status, 
        COUNT(appointment_id) AS count
    FROM 
        appointments
    WHERE
        status IN ('booked', 'completed', 'cancelled', 'rest')
    GROUP BY 
        appointment_date, status
    ORDER BY 
        appointment_date ASC, 
        FIELD(status, 'booked', 'completed', 'cancelled', 'rest')
";

try {
    $stmt = $pdo->query($query);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $events = [];
    foreach ($results as $row) {
        $status = strtolower($row['status']);
        $count = (int)$row['count'];
        $date = $row['appointment_date'];
        
        $color = '#808080'; // Default gray
        $title = ucfirst($status);
        // Default text color to white for contrast on dark colors
        $textColor = 'white'; 

        switch ($status) {
            case 'booked':
                // 'booked' status is 'Booking' and Blue
                $color = '#4A90E2'; // Blue
                $title = "Booking";
                break;
            case 'completed':
                // 'completed' status is now Green (Requested)
                $color = '#8FD19E'; // Green
                $title = "Complete";
                // Green is a lighter color, use black text
                $textColor = 'black';
                break;
            case 'cancelled':
                // 'cancelled' status is Yellow
                $color = '#FFD966'; // Yellow
                $title = "Cancelled";
                // Yellow is a lighter color, use black text
                $textColor = 'black';
                break;
            case 'rest':
                // 'rest' status is now Gray for distinction
                $color = '#A9A9A9'; // Gray
                $title = "Rest Day";
                break;
        }

        $displayTitle = $title . ($count > 1 ? " ({$count})" : "");

        $events[] = [
            'title' => $displayTitle,
            'start' => $date,
            'color' => $color,
            'textColor' => $textColor,
            'extendedProps' => [
                'status' => $status
            ],
            'editable' => false,
            'display' => 'list-item'
        ];
    }

    echo json_encode($events);

} catch (PDOException $e) {
    error_log("Database Error: " . $e->getMessage()); 
    echo json_encode([]); 
}
?>