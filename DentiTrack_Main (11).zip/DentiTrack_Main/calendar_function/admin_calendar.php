<?php
require_once '../calendar_function/calendar_conn.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DentiTrack | Admin Calendar</title>
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

.page-title {
  text-align: center;
  color: #003366;
  font-size: 1.8rem;
  font-weight: 600;
  margin-bottom: 25px;
}
#calendar {
  max-width: 900px;
  margin: 0 auto;
  background: #fff;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}
/* === UPDATED CSS STATUS COLORS (Completed is Green, Rest Day is Gray) === */
.status-booking { background-color: #4A90E2 !important; color: white !important; } /* DB booked (Booking) - Blue */
.status-completed { background-color: #28a745 !important; color: black !important; } /* DB completed (Complete) - Green */
.status-cancelled { background-color: #FFD966 !important; color: black !important; } /* DB cancelled (Cancelled) - Yellow */
.status-restday { background-color: #8FD19E !important; color: white !important; } /* DB rest (Rest Day) - Gray */


/* Legend */
.legend {
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-bottom: 15px;
}
.legend-item {
  display: flex;
  align-items: center;
  gap: 6px;
}
.color-box {
  width: 18px;
  height: 18px;
  border-radius: 3px;
}

/* Highlight today's date */
.fc-day-today {
  background-color: #e0e0e0 !important;
  color: #000 !important;
  font-weight: 600;
  border: 2px solid #b0b0b0 !important;
  border-radius: 6px;
}

/* Make calendar text black */
.fc-event-title,
.fc-daygrid-day-number,
.fc-daygrid-event,
.fc-col-header-cell-cushion,
.fc-toolbar-title,
.fc-daygrid-day-top a {
  color: #000 !important;
  text-decoration: none !important;
}

/* === SEARCH BAR STYLING === */
.search-container {
  text-align: center;
  margin: 15px 0;
  position: relative;
}
.search-container select,
.search-container button,
.search-container input {
  padding: 6px 10px;
  margin: 0 5px;
  border-radius: 6px;
  border: 1px solid #ccc;
  font-size: 15px;
}
.search-container button {
  background-color: #007bff;
  color: #fff;
  border: none;
  cursor: pointer;
}
.search-container button:hover {
  background-color: #0056b3;
}

/* === AUTOCOMPLETE DROPDOWN === */
#patientList {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  width: 250px;
  background: #fff;
  border: 1px solid #ccc;
  border-top: none;
  border-radius: 0 0 6px 6px;
  max-height: 180px;
  overflow-y: auto;
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
  z-index: 1000;
  display: none;
}
#patientList div {
  padding: 8px 10px;
  cursor: pointer;
}
#patientList div:hover {
  background-color: #f0f0f0;
}

</style>
</head>
<body>

<h2 class="page-title">🧑‍💼 DentiTrack Admin Appointment Calendar</h2>

<div class="legend">
  <div class="legend-item"><div class="color-box" style="background:#4A90E2;"></div> Booking</div>
  <div class="legend-item"><div class="color-box" style="background:#28a745;"></div> Complete</div>
  <div class="legend-item"><div class="color-box" style="background:#FFD966;"></div> Cancelled</div>
  <div class="legend-item"><div class="color-box" style="background:#8FD19E;"></div> Rest Day</div>
</div>

<div class="search-container">
  <select id="yearSelect"></select>
  <select id="monthSelect"></select>
  <select id="daySelect"></select>
  <button class="search-btn" id="goDateBtn">Go</button>

  <form id="searchForm" style="display:inline; position:relative;">
    <input type="text" id="searchName" placeholder="🔎 Search by patient name..." style="width:220px;">
    <button type="submit" id="searchNameBtn">Search</button>
    <div id="patientList"></div>
  </form>
</div>

<div id="calendar"></div>

<div class="modal fade" id="appointmentModal" tabindex="-1" aria-labelledby="appointmentModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content shadow-lg border-0">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="appointmentModalLabel">Appointments for Selected Date</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <label class="form-label fw-semibold">Select Appointment:</label>
        <select id="appointmentSelect" class="form-select mb-3"></select>

        <div id="appointmentDetails" class="border-top pt-3">
          <p><strong>Appointment ID:</strong> <span id="appointment_id">-</span></p>
          <p><strong>Patient:</strong> <span id="patient_name">-</span></p>
          <p><strong>Email:</strong> <span id="email">-</span></p>
          <p><strong>Contact:</strong> <span id="contact_number">-</span></p>
          <p><strong>Gender:</strong> <span id="gender">-</span></p>
          <p><strong>Age:</strong> <span id="age">-</span></p>
          <p><strong>Service:</strong> <span id="service">-</span></p>
          <p><strong>Date:</strong> <span id="appointment_date">-</span></p>
          <p><strong>Time:</strong> <span id="appointment_time">-</span></p>
          <p><strong>Status:</strong> <span id="status">-</span></p>
          <p><strong>Comments:</strong> <span id="comments">-</span></p>
        </div>
      </div>
      <div class="modal-footer d-flex justify-content-between">
        <div>
          <button class="btn btn-primary" id="bookingBtn">Booking</button> 
          <button class="btn btn-success" id="completeBtn">Complete</button>
          <button class="btn btn-danger" id="cancelBtn">Cancel</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const calendarEl = document.getElementById('calendar');
  const modalEl = new bootstrap.Modal(document.getElementById('appointmentModal')); 
  const select = document.getElementById('appointmentSelect');
  let currentAppointments = [];
  let selectedAppointment = null;

  function showDetails(a) {
    selectedAppointment = a;
    document.getElementById('appointment_id').innerText = a.appointment_id || '-';
    document.getElementById('patient_name').innerText = a.patient_name || '-';
    document.getElementById('email').innerText = a.email || '-';
    document.getElementById('contact_number').innerText = a.contact_number || '-';
    document.getElementById('gender').innerText = a.gender || '-';
    document.getElementById('age').innerText = a.age || 'N/A';
    document.getElementById('service').innerText = a.service || '-';
    document.getElementById('appointment_date').innerText = a.appointment_date || '-';
    document.getElementById('appointment_time').innerText = a.appointment_time || '-';
    // If status is 'booked', display it as 'Booking'
    const displayStatus = a.status.toLowerCase() === 'booked' ? 'Booking' : a.status;
    document.getElementById('status').innerText = displayStatus || '-';
    document.getElementById('comments').innerText = a.comments || 'None';
  }

  // Function to update status
  function updateStatus(dbStatus) {
    if (!selectedAppointment) return alert('No appointment selected.');

    // Map DB status to display name for the confirmation message
    const displayStatus = dbStatus === 'booked' ? 'Booking' : dbStatus.charAt(0).toUpperCase() + dbStatus.slice(1);
    
    if (!confirm(`Are you sure you want to change the status to "${displayStatus}"?`)) {
        return;
    }

    fetch('../calendar_function/update_appointment_status_admin.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `appointment_id=${selectedAppointment.appointment_id}&status=${dbStatus}`
    })
    .then(res => res.text())
    .then(msg => {
      alert(msg);
      modalEl.hide();
      if (typeof calendar !== 'undefined') calendar.refetchEvents();
    })
    .catch(err => console.error('Error:', err));
  }
  
  // Helper Function to handle AJAX and Modal Display
  function fetchAppointmentsAndShowModal(queryValue, modalTitle, isPatientSearch = false) {
      const url = isPatientSearch 
        ? '../calendar_function/fetch_appointments_by_patient_admin.php?patient=' + encodeURIComponent(queryValue)
        : '../calendar_function/fetch_appointments_by_date_admin.php?date=' + encodeURIComponent(queryValue);

      fetch(url)
        .then(res => res.json())
        .then(data => {
          if (!data.appointments || data.appointments.length === 0 || data.status === 'empty') {
            alert(`No appointments found for ${queryValue}.`);
            return;
          }
          currentAppointments = data.appointments;
          select.innerHTML = '';
          data.appointments.forEach((appt, index) => {
            const option = document.createElement('option');
            option.value = index;
            const patientPart = isPatientSearch ? `${appt.appointment_date} - ` : `${appt.patient_name} - `;
            
            // Display 'Booking' instead of 'booked'
            const displayStatus = appt.status.toLowerCase() === 'booked' ? 'Booking' : appt.status;
            option.text = patientPart + `${appt.appointment_time} (${displayStatus})`;
            
            select.appendChild(option);
          });
          
          showDetails(data.appointments[0]);
          document.getElementById('appointmentModalLabel').textContent = modalTitle;
          modalEl.show();
        })
        .catch(err => {
          console.error('Error fetching appointments:', err);
          alert(`Error fetching appointments for ${queryValue}. Check console for details.`);
        });
  }

  // === FullCalendar Initialization ===
  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    events: '../calendar_function/fetch_appointments_admin.php',
    eventDidMount: function(info) {
      const s = (info.event.extendedProps.status || '').toLowerCase();
      // Maps DB statuses to the new CSS classes
      if (s === 'booked') info.el.classList.add('status-booking');
      else if (s === 'completed') info.el.classList.add('status-completed');
      else if (s === 'cancelled') info.el.classList.add('status-cancelled');
      else if (s === 'rest') info.el.classList.add('status-restday');
    },
    dateClick: function(info) {
      fetchAppointmentsAndShowModal(info.dateStr, `Appointments on ${info.dateStr}`);
    }
  });
  calendar.render();

  // Event listener for the dropdown change
  select.addEventListener('change', function() {
    const appt = currentAppointments[this.value];
    if (appt) showDetails(appt);
  });

  // Event listeners for status buttons (Mapped to DB ENUMs)
  document.getElementById('bookingBtn').addEventListener('click', () => updateStatus('booked'));
  document.getElementById('completeBtn').addEventListener('click', () => updateStatus('completed'));
  document.getElementById('cancelBtn').addEventListener('click', () => updateStatus('cancelled'));
  
  // =========================================================================
  // === Search Logic Block (Your original logic maintained) =================
  // =========================================================================

  // === Initialize date dropdowns ===
  const yearSelect = document.getElementById('yearSelect');
  const monthSelect = document.getElementById('monthSelect');
  const daySelect = document.getElementById('daySelect');
  const now = new Date();
  for (let y = now.getFullYear() - 1; y <= now.getFullYear() + 1; y++) {
    const opt = document.createElement('option');
    opt.value = y;
    opt.textContent = y;
    if (y === now.getFullYear()) opt.selected = true;
    yearSelect.appendChild(opt);
  }
  const months = [
    'January','February','March','April','May','June','July',
    'August','September','October','November','December'
  ];
  months.forEach((m, i) => {
    const opt = document.createElement('option');
    opt.value = i + 1;
    opt.textContent = m;
    if (i === now.getMonth()) opt.selected = true;
    monthSelect.appendChild(opt);
  });
  for (let d = 1; d <= 31; d++) {
    const opt = document.createElement('option');
    opt.value = d;
    opt.textContent = d;
    if (d === now.getDate()) opt.selected = true;
    daySelect.appendChild(opt);
  }

  // === Date search Button Listener ===
  document.getElementById('goDateBtn').addEventListener('click', () => {
    const y = parseInt(yearSelect.value, 10);
    const m = parseInt(monthSelect.value, 10);
    const d = parseInt(daySelect.value, 10);
    if (!y || !m || !d) {
      alert('Invalid date');
      return;
    }
    const dateStr = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    fetchAppointmentsAndShowModal(dateStr, `Appointments on ${dateStr}`);
  });

  // === Autocomplete + Patient search ===
  const searchForm = document.getElementById('searchForm');
  const searchInput = document.getElementById('searchName');
  const patientList = document.getElementById('patientList');
  let autocompleteTimer = null;

  function performPatientSearch(term) {
    fetchAppointmentsAndShowModal(term, `Appointments for ${term}`, true);
  }

  searchInput.addEventListener('keyup', function () {
    const q = this.value.trim();
    if (autocompleteTimer) clearTimeout(autocompleteTimer);
    if (!q) {
      patientList.style.display = 'none';
      return;
    }
    autocompleteTimer = setTimeout(() => {
      fetch('../calendar_function/fetch_appointments_by_patient_admin.php?patient=' + encodeURIComponent(q))
        .then(r => r.json())
        .then(data => {
          patientList.innerHTML = '';
          if (data.status === 'success' && Array.isArray(data.appointments) && data.appointments.length) {
            const uniquePatients = [...new Set(data.appointments.map(p => p.patient_name))];

            uniquePatients.forEach(name => {
              const item = document.createElement('div');
              item.textContent = name;
              item.addEventListener('click', () => {
                searchInput.value = name;
                patientList.style.display = 'none';
                performPatientSearch(name);
              });
              patientList.appendChild(item);
            });
            
            patientList.style.display = 'block';
          } else {
            patientList.style.display = 'none';
          }
        })
        .catch(err => {
          console.error(err);
          patientList.style.display = 'none';
        });
    }, 220);
  });

  document.addEventListener('click', e => {
    if (!e.target.closest('#searchName') && !e.target.closest('#patientList')) {
      patientList.style.display = 'none';
    }
  });

  searchForm.addEventListener('submit', e => {
    e.preventDefault();
    const term = searchInput.value.trim();
    if (!term) return alert('Enter a patient name to search.');
    performPatientSearch(term);
  });
});
</script>
</body>
</html>