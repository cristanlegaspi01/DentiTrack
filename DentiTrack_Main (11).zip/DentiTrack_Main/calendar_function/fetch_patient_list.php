<?php
require_once '../calendar_function/calendar_conn.php';
header('Content-Type: application/json');

// Get query parameter
$query = trim($_GET['query'] ?? '');

if ($query === '') {
    echo json_encode(['status' => 'empty', 'patients' => []]);
    exit;
}

try {
    // Prepare statement with case-insensitive search
    $stmt = $pdo->prepare("
        SELECT DISTINCT patient_name 
        FROM appointments 
        WHERE LOWER(patient_name) LIKE :search 
        ORDER BY patient_name 
        LIMIT 10
    ");
    $search = '%' . strtolower($query) . '%';
    $stmt->bindParam(':search', $search, PDO::PARAM_STR);
    $stmt->execute();

    $patients = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $patients[] = ['patient_name' => $row['patient_name']];
    }

    if (count($patients) === 0) {
        echo json_encode(['status' => 'empty', 'patients' => []]);
    } else {
        echo json_encode(['status' => 'success', 'patients' => $patients]);
    }

} catch (PDOException $e) {
    // Return error safely
    echo json_encode(['status' => 'error', 'message' => 'DB error: ' . $e->getMessage()]);
}
?>
