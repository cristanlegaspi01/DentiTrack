<?php
session_start();
include '../config/db_pdo.php';
include '../config/db_conn.php';

// ✅ Set timezone to Philippines
date_default_timezone_set('Asia/Manila');

// Ensure PDO throws exceptions
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Check secretary role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: ../public/login.php');
    exit();
}

$error = '';
// --- 1. Filter Variables ---
$search = $_GET['search'] ?? '';
$service_filter = $_GET['service_filter'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

// --- 2. Fetch all services for the dropdown filter ---
$services_list = [];
try {
    $stmt_services = $conn->query("SELECT service_id, service_name FROM services ORDER BY service_name ASC");
    $services_list = $stmt_services->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error = "Failed to fetch services list: " . $e->getMessage();
}


// --- 3. Build Dynamic SQL Query ---
try {
    $sql = "
        SELECT p.payment_id, CONCAT(pt.first_name, ' ', pt.last_name) AS patient_name,
               s.service_name, p.amount, p.discount_type, p.discount_amount,
               p.total_amount, p.payment_method, p.supplies_used, p.created_at, p.service_id
        FROM payments p
        INNER JOIN patient pt ON p.patient_id = pt.patient_id
        LEFT JOIN services s ON p.service_id = s.service_id
    ";
    
    $where_clauses = [];
    $params = [];
    
    // a) Text Search Filter (Patient Name or Service Name)
    if (!empty($search)) {
        $where_clauses[] = "(pt.first_name LIKE :search OR pt.last_name LIKE :search OR s.service_name LIKE :search)";
        $params[':search'] = "%$search%";
    }
    
    // b) Service Filter
    if (!empty($service_filter) && $service_filter != 'all') {
        $where_clauses[] = "p.service_id = :service_id";
        $params[':service_id'] = $service_filter;
    }

    // c) Date Range Filter
    if (!empty($start_date)) {
        // Look for records created ON or AFTER the start date (at the beginning of the day)
        $where_clauses[] = "DATE(p.created_at) >= :start_date";
        $params[':start_date'] = $start_date;
    }
    if (!empty($end_date)) {
        // Look for records created ON or BEFORE the end date (at the end of the day)
        $where_clauses[] = "DATE(p.created_at) <= :end_date";
        $params[':end_date'] = $end_date;
    }

    // Combine all WHERE clauses
    if (!empty($where_clauses)) {
        $sql .= " WHERE " . implode(" AND ", $where_clauses);
    }
    
    $sql .= " ORDER BY p.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $error = "Failed to fetch payments: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Payments Log - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<style>
/* ... (Existing CSS retained) ... */
*,*::before,*::after{box-sizing:border-box;}
body,html{margin:0;padding:0;height:100%;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#e6f0ff;color:#003366;}
body{display:flex;min-height:100vh;overflow-x:hidden;}
.sidebar{width:260px;background:linear-gradient(to bottom,#3399ff,#0066cc);padding:20px;color:white;display:flex;flex-direction:column;box-shadow:2px 0 10px rgba(0,0,0,0.15);}
.sidebar h2{text-align:center;margin-bottom:30px;font-size:24px;font-weight:700;}
.sidebar a{display:block;padding:12px 20px;margin:10px 0;color:#cce0ff;text-decoration:none;border-left:4px solid transparent;font-weight:600;transition:0.3s;}
.sidebar a:hover,.sidebar a.active{background:rgba(255,255,255,0.15);color:white;border-left:4px solid #ffcc00;}
main.main-content{flex:1;background:#fff;padding:40px 50px;overflow-y:auto;}
header{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;}
header h1{font-size:2.3rem;font-weight:900;color:#004080;display:flex;align-items:center;gap:15px;}
/* Updated styles for the filter area */
.action-bar{display:flex;align-items:center;gap:10px; flex-wrap: wrap;} 
.filter-controls {
    display: flex;
    gap: 10px;
    align-items: center;
    background: #f8f8f8;
    padding: 10px;
    border-radius: 10px;
    border: 1px solid #ddd;
}
.search-form{display:flex;align-items:center;gap:5px;}

/* Styling for all form controls */
.search-form input[type="text"],
.search-form select,
.search-form input[type="date"]{
    padding:6px 10px;
    border-radius:8px;
    border:1px solid #3399ff;
    font-weight:600;
}
.search-form button{padding:6px 12px;border:none;border-radius:8px;background:#3399ff;color:white;cursor:pointer;font-weight:700;}
.search-form button:hover{background:#0066cc;}
.flash-message{max-width:700px;margin:15px auto;padding:16px 20px;border-radius:15px;font-weight:700;text-align:center;}
.flash-error{background:#f8d7da;color:#721c24;}
.table-container{background:#f0f7ff;padding:25px;border-radius:20px;box-shadow:0 10px 25px rgba(0,0,0,0.1);}
table{width:100%;border-collapse:collapse;}
th,td{padding:12px 15px;text-align:left;border-bottom:1px solid #ccc;font-weight:600;color:#003366;}
th{background:#3399ff;color:white;border-radius:12px 12px 0 0;}
tr:hover{background:#e0f0ff;}
.supplies-list{font-weight:400;font-size:0.9rem;color:#004080;}
.export-csv-btn{padding:6px 12px;border:none;border-radius:8px;background:#28a745; color:white;cursor:pointer;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:5px;}
.export-csv-btn:hover{background:#1e7e34;}
</style>
</head>
<body>

<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="secretary_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
  <a href="find_patient.php" ><i class="fas fa-search"></i> Find Patient</a>
    <a href="view_patients.php"><i class="fas fa-users"></i> View Patients</a>
    <a href="payments.php"><i class="fas fa-cash-register"></i> Payments</a>
    <a href="online_bookings.php"><i class="fas fa-laptop-code"></i> Online Bookings</a>
    <a href="payment_logs.php" class="active"><i class="fas fa-file-invoice-dollar"></i> Payments Log</a>
    <a href="services_list.php"><i class="fas fa-list"></i> Services</a>
    <a href="appointments.php"><i class="fas fa-calendar-check"></i> Manage Consultation</a>
    <a href="create_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
    <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">
<header>
    <h1><i class="fas fa-file-invoice-dollar"></i> Payments Log</h1>
    <a href="export_payment_logs_csv.php?search=<?= urlencode($search) ?>&service_filter=<?= urlencode($service_filter) ?>&start_date=<?= urlencode($start_date) ?>&end_date=<?= urlencode($end_date) ?>" class="export-csv-btn">
        <i class="fas fa-file-csv"></i> Export Filtered to CSV
    </a>
</header>

<div class="filter-controls">
    <form class="search-form" method="GET">
        
        <label for="service_filter" style="font-weight:700;">Service:</label>
        <select name="service_filter" id="service_filter">
            <option value="all">-- All Services --</option>
            <?php foreach ($services_list as $service): ?>
                <option value="<?= htmlspecialchars($service['service_id']) ?>" 
                        <?= $service_filter == $service['service_id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($service['service_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="start_date" style="font-weight:700; margin-left: 10px;">Date From:</label>
        <input type="date" name="start_date" id="start_date" value="<?= htmlspecialchars($start_date) ?>">

        <label for="end_date" style="font-weight:700;">Date To:</label>
        <input type="date" name="end_date" id="end_date" value="<?= htmlspecialchars($end_date) ?>">

        <input type="text" name="search" placeholder="Search patient/service name..." value="<?= htmlspecialchars($search) ?>">
        
        <button type="submit"><i class="fas fa-filter"></i> Apply Filters</button>
        <a href="payment_logs.php" style="padding:6px 12px; border-radius:8px; background:#f0ad4e; color:white; text-decoration:none; font-weight:700;">
            <i class="fas fa-undo"></i> Reset
        </a>
    </form>
</div>

<?php if ($error): ?>
    <div class="flash-message flash-error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="table-container" style="margin-top: 20px;">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Patient</th>
                <th>Service</th>
                <th>Amount</th>
                <th>Supplies Used</th>
                <th>Supplies Total</th>
                <th>Discount</th>
                <th>Total</th>
                <th>Method</th>
                <th>Date Created</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($payments)): ?>
                <?php foreach ($payments as $idx => $p): 
                    // Calculate Supplies Total dynamically for display
                    $sup_total = 0;
                    $supplies = json_decode($p['supplies_used'], true);
                    if (!empty($supplies)) {
                        // This logic is inefficient but maintained for consistency.
                        foreach ($supplies as $s) {
                            $supply_id = $s['id'] ?? 0;
                            $qty = intval($s['qty'] ?? 0);

                            try {
                                $stmt2 = $conn->prepare("SELECT price FROM dental_supplies WHERE supply_id = ?");
                                $stmt2->execute([$supply_id]);
                                $price = $stmt2->fetchColumn();
                                if ($price !== false) {
                                    $sup_total += $qty * floatval($price);
                                }
                            } catch (Exception $e) {
                                // Error handling
                            }
                        }
                    }
                ?>
                    <tr>
                        <td><?= $idx + 1 ?></td>
                        <td><?= htmlspecialchars($p['patient_name']) ?></td>
                        <td><?= htmlspecialchars($p['service_name'] ?? '-') ?></td>
                        <td>₱<?= number_format($p['amount'],2) ?></td>
                        <td class="supplies-list">
                            <?php 
                                if (!empty($supplies)) {
                                    $list = [];
                                    foreach ($supplies as $s) {
                                        $list[] = htmlspecialchars($s['name']) . ' x' . intval($s['qty']);
                                    }
                                    echo implode(', ', $list);
                                } else {
                                    echo '-';
                                }
                            ?>
                        </td>
                        <td>
                            <?= $sup_total > 0 ? '₱' . number_format($sup_total,2) : '-' ?>
                        </td>
                        <td>
                            <?= $p['discount_type'] === 'none' ? '-' : htmlspecialchars($p['discount_type']) . ' (₱' . number_format($p['discount_amount'],2) . ')' ?>
                        </td>
                        <td>₱<?= number_format($p['total_amount'],2) ?></td>
                        <td><?= ucfirst($p['payment_method']) ?></td>
                        <td>
                            <?= date('M d, Y g:i A', strtotime($p['created_at'])) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="10" style="text-align:center;">No payments found based on current filters.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</main>
</body>
</html>