<?php
session_start();
// Include the database connections
require_once '../config/db_pdo.php';

// --- PHPMailer Includes (Required for Email Reminders) ---
// These explicit includes prevent the "Class not found" error
require '../phpmailer-master/src/PHPMailer.php';
require '../phpmailer-master/src/SMTP.php';
require '../phpmailer-master/src/Exception.php';

// Include Composer Autoload (for general dependencies)
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// 🛑 SMS SDK use statements removed (e.g., use Twilio\Rest\Client or use Vonage\Client)


// =======================================================
// IMPORTANT CONFIGURATION: SMTP & Timezone
// (SMS settings have been removed)
// =======================================================
define('CONF_TIMEZONE', 'Asia/Manila');
define('CONF_SMTP_HOST', 'smtp.gmail.com');
define('CONF_SMTP_PORT', 587);
define('CONF_SMTP_USER', 'dentitrack2025@gmail.com');       // Your SMTP Email User
define('CONF_SMTP_PASS', 'gpmennmjrynhujzq');             // Your SMTP Password (or App Password)
// =======================================================

// Set timezone for consistency 
date_default_timezone_set(CONF_TIMEZONE);

// Ensure PDO throws exceptions
if (isset($pdo)) {
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn = $pdo; // Use $pdo as $conn for consistency with original code's variable names
} else {
    $error = "Database connection failed.";
}

// Check secretary role 
/*
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: ../public/login.php');
    exit();
}
*/

$error = '';
$success = '';
$bookings = [];

// 🛑 The entire send_sms function has been removed.


// --- Filter and Search Logic ---
$search_term = $_GET['search'] ?? '';
$filter_mode = $_GET['mode'] ?? 'all'; // 'all', 'Online', 'Walk-in'

$where_clauses = [];
$params = [];

// Base condition to fetch Online and Walk-in payments
$where_clauses[] = "p.payment_method IN ('Online', 'Walk-in')"; 

// Mode Filter
if ($filter_mode !== 'all') {
    $where_clauses[] = "p.payment_method = ?";
    $params[] = $filter_mode;
}

// Search Filter (by patient name or service name)
if ($search_term) {
    // Add wildcards to the search term
    $search_pattern = '%' . $search_term . '%';
    $where_clauses[] = "(CONCAT(pat.first_name, ' ', pat.last_name) LIKE ? OR s.service_name LIKE ?)";
    $params[] = $search_pattern;
    $params[] = $search_pattern;
}

$where_sql = count($where_clauses) > 0 ? 'WHERE ' . implode(' AND ', $where_clauses) : '';


/* ==========================
    REMINDER FUNCTION (SEND EMAIL ONLY)
    ========================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_reminder'])) {
    $payment_id = $_POST['payment_id'] ?? null;

    if ($payment_id) {
        try {
            // 1. Fetch Patient Email and Payment Details
            $stmt = $conn->prepare("
                SELECT 
                    pat.email, 
                    CONCAT(pat.first_name, ' ', pat.last_name) AS patient_name,
                    s.service_name,
                    p.downpayment AS initial_fee,
                    p.monthly_payment,
                    p.payment_option
                FROM 
                    payments p
                JOIN 
                    patient pat ON p.patient_id = pat.patient_id
                JOIN 
                    services s ON p.service_id = s.service_id
                WHERE 
                    p.payment_id = ?
                LIMIT 1
            ");
            $stmt->execute([$payment_id]);
            $payment_data = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($payment_data && $payment_data['email']) {
                $patient_email = $payment_data['email'];
                $patient_name = $payment_data['patient_name'];
                $service_name = $payment_data['service_name'];
                $initial_fee = number_format($payment_data['initial_fee'], 2);
                $monthly_payment = number_format($payment_data['monthly_payment'], 2);
                $payment_option = ucfirst($payment_data['payment_option']);
                
                // 2. Configure PHPMailer 
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = CONF_SMTP_HOST; 
                $mail->SMTPAuth = true;
                $mail->Username = CONF_SMTP_USER; 
                $mail->Password = CONF_SMTP_PASS; 
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = CONF_SMTP_PORT; 
                $mail->setFrom(CONF_SMTP_USER, 'DentiTrack - Secretary'); 
                $mail->addAddress($patient_email, $patient_name);
                $mail->isHTML(true);
                $mail->Subject = 'DentiTrack Payment Reminder';

                // 3. Construct Email Body
                $body = "
                    <h2>Payment Reminder for Your Appointment</h2>
                    <p>Dear {$patient_name},</p>
                    <p>This is a friendly reminder regarding your payment for the service: <strong>{$service_name}</strong>.</p>
                    <p><strong>Payment Details:</strong></p>
                    <ul>
                        <li><strong>Payment Type:</strong> {$payment_option}</li>
                        <li><strong>Initial Fee/Downpayment:</strong> ₱{$initial_fee}</li>";
                if ($payment_data['payment_option'] === 'installment') {
                    $body .= "<li><strong>Monthly Payment:</strong> ₱{$monthly_payment}</li>";
                }
                $body .= "</ul>
                    <p>Please ensure your payment is completed promptly. Contact our clinic at 0922 878 7341 | danaroxas.dentalclinic@gmail.com if you have any questions.</p>
                    <p>Thank you.</p>
                    <p>DentiTrack Clinic Management</p>
                ";
                $mail->Body = $body;

                // 4. Send Email
                $mail->send();
                
                // 5. Set success message
                $success = 'Payment reminder sent successfully via email to ' . htmlspecialchars($patient_email) . '.';

            } else {
                $error = 'Patient email not found for this payment ID.';
            }
        } catch (Exception $e) {
            $error = "Payment Reminder Email could not be sent. Mailer Error: {$e->getMessage()}";
        }
    } else {
        $error = 'Invalid payment ID.';
    }
}


/* ==========================
    FETCH BOOKINGS WITH FILTERS
    ========================== */
if (isset($conn)) {
    try {
        // --- Fetch all payments from the 'payments' table, filtered ---
        $stmt = $conn->prepare("
            SELECT 
                p.payment_id,
                p.appointment_id,       /* <--- ADDED appointment_id */
                CONCAT(pat.first_name, ' ', pat.last_name) AS patient_name,
                s.service_name,
                s.service_id,             
                s.price AS service_price,         
                p.downpayment AS initial_fee,       
                p.payment_method,           
                p.proof_image AS proof_of_payment,  
                p.proof_image AS proof_image_url,   
                a.status AS booking_status,       
                p.status AS payment_status,       
                p.payment_date AS booking_date,   
                p.payment_option,           
                p.installment_term,           
                p.monthly_payment,            
                pat.patient_id,
                pat.email                    
            FROM 
                payments p
            JOIN 
                patient pat ON p.patient_id = pat.patient_id
            JOIN 
                services s ON p.service_id = s.service_id
            LEFT JOIN 
                appointments a ON p.appointment_id = a.appointment_id 
            {$where_sql}
            ORDER BY 
                p.payment_date DESC
        ");
        
        $stmt->execute($params);
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Exception $e) {
        $error = "Error loading bookings data: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bookings & Payments Management - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<style>
/* --- Basic Layout and Styling (Keep consistent with other pages) --- */
*,*::before,*::after{box-sizing:border-box;}
body,html{margin:0;padding:0;height:100%;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#e6f0ff;color:#003366;}
body{display:flex;min-height:100vh;overflow-x:hidden;}
.sidebar{width:260px;background:linear-gradient(to bottom,#3399ff,#0066cc);padding:20px;color:white;display:flex;flex-direction:column;box-shadow:2px 0 10px rgba(0,0,0,0.15);}
.sidebar h2{text-align:center;margin-bottom:30px;font-size:24px;font-weight:700;}
.sidebar a{display:block;padding:12px 20px;margin:10px 0;color:#cce0ff;text-decoration:none;border-left:4px solid transparent;font-weight:600;transition:0.3s;}
.sidebar a:hover,.sidebar a.active{background:rgba(255,255,255,0.15);color:white;border-left:4px solid #ffcc00;}
main.main-content{flex:1;background:#fff;padding:40px 50px;overflow-y:auto;}
header h1{font-size:2.3rem;font-weight:900;color:#004080;display:flex;align-items:center;gap:15px;}
.flash-message{max-width:100%;margin:15px 0;padding:16px 20px;border-radius:15px;font-weight:700;text-align:center;}
.flash-error{background:#f8d7da;color:#721c24;}
.flash-success{background:#d4edda;color:#155724;}
hr{border:0;height:1px;background:#cce0ff;margin:20px 0;}

/* --- Table Styles --- */
.data-table{width:100%;border-collapse:collapse;margin-top:20px;background:white;box-shadow:0 5px 15px rgba(0,0,0,0.05);border-radius:15px;overflow:hidden;}
.data-table th,.data-table td{padding:12px 15px;text-align:left;border-bottom:1px solid #e0f0ff;}
.data-table th{background:#3399ff;color:white;font-weight:700;text-transform:uppercase;}
.data-table tr:hover{background:#f5faff;}

/* Status Badges */
.status-badge{padding:5px 10px;border-radius:12px;font-weight:700;font-size:0.85rem;display:inline-block;}
.status-confirmed{background:#e6ffe6;color:#008000;border:1px solid #008000;}
.status-pending{background:#fff3cd;color:#856404;border:1px solid #856404;}
.status-paid{background:#d4edda;color:#155724;}
.status-debt{background:#f8d7da;color:#721c24;}
.status-online{background:#f2e6ff;color:#6600cc;}
.status-walk-in{background:#e0f0ff;color:#004080;}
.status-full{background:#cceeff;color:#004d99;}
.status-installment{background:#ffe0cc;color:#cc6600;}
.status-booked{background:#cceeff;color:#004d99;}

/* Action Buttons & Alignment */
.action-cell {
    white-space: nowrap; 
}
.action-buttons-group {
    display: flex;
    gap: 8px; 
    align-items: center; 
}
.action-btn{
    padding:8px 12px;
    border:none;
    border-radius:12px;
    font-weight:600;
    cursor:pointer;
    transition:0.2s;
    text-decoration:none;
    display: inline-flex; 
    align-items: center;
}
.action-btn i {
    margin-right: 5px; 
}
.btn-view{background:#0099ff;color:white;}
.btn-complete{background:#28a745;color:white;}
.btn-process{background:#ffc107;color:#333;}
.btn-reminder{background:#00b4d8;color:white;} /* New Reminder Button Style */

/* --- Search and Filter Area --- */
.filter-search-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding: 15px;
    background: #f5faff;
    border-radius: 15px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
}

.filter-search-container label, .filter-search-container select {
    font-weight: 600;
    color: #004080;
    margin-right: 10px;
}

.filter-search-container input[type="text"], 
.filter-search-container select, 
.filter-search-container button {
    padding: 10px 15px;
    border: 1px solid #cce0ff;
    border-radius: 10px;
}

.filter-search-container input[type="text"] {
    width: 250px;
}

.filter-search-container .search-group,
.filter-search-container .filter-group {
    display: flex;
    align-items: center;
}

.filter-search-container button {
    background: #3399ff;
    color: white;
    font-weight: 700;
    cursor: pointer;
    transition: background 0.2s;
}
.filter-search-container button:hover {
    background: #0066cc;
}

/* Modal Styles retained and simplified for brevity */
.modal {
    display: none; 
    position: fixed; 
    z-index: 1000; 
    left: 0;
    top: 0;
    width: 100%; 
    height: 100%; 
    overflow: auto; 
    background-color: rgba(0,0,0,0.4); 
    padding-top: 60px;
}
.modal-content {
    background-color: #fefefe;
    margin: 5% auto; 
    padding: 30px;
    border: 1px solid #888;
    width: 90%; 
    max-width: 700px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    position: relative;
}
.close-btn {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    position: absolute;
    top: 10px;
    right: 20px;
}
.close-btn:hover, .close-btn:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
.modal-info-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding: 8px 0;
    border-bottom: 1px dotted #cce0ff;
}
.proof-image {
    max-width: 100%;
    height: auto;
    max-height: 400px;
    border-radius: 10px;
    margin-top: 10px;
    object-fit: contain;
    border: 1px solid #ccc;
}
</style>
</head>
<body>

    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="secretary_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="find_patient.php" ><i class="fas fa-search"></i> Find Patient</a>
        <a href="view_patients.php"><i class="fas fa-users"></i> View Patients</a>
        <a href="Payments.php"><i class="fas fa-cash-register"></i> Payments</a>
        <a href="online_bookings.php" class="active"><i class="fas fa-laptop-code"></i> Online Bookings</a> <a href="payment_logs.php" ><i class="fas fa-file-invoice-dollar"></i> Payments Log</a>
        <a href="services_list.php"><i class="fas fa-list"></i> Services</a>
        <a href="appointments.php"><i class="fas fa-calendar-check"></i> Manage Consultation</a>
        <a href="create_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>
<main class="main-content">
<header><h1><i class="fas fa-laptop-code"></i> Bookings & Payments Management</h1></header>
<hr>

<?php if ($error): ?>
    <div class="flash-message flash-error"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="flash-message flash-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<div class="filter-search-container">
    <form method="GET" class="filter-group">
        <label for="mode-filter"><i class="fas fa-filter"></i> Payment Mode:</label>
        <select name="mode" id="mode-filter">
            <option value="all" <?= $filter_mode === 'all' ? 'selected' : '' ?>>All Modes</option>
            <option value="Online" <?= $filter_mode === 'Online' ? 'selected' : '' ?>>Online Booking</option>
            <option value="Walk-in" <?= $filter_mode === 'Walk-in' ? 'selected' : '' ?>>Walk-in</option>
        </select>
        <button type="submit"><i class="fas fa-redo"></i> Apply Filter</button>
    </form>

    <form method="GET" class="search-group">
        <label for="search-input"><i class="fas fa-search"></i> Search:</label>
        <input type="text" name="search" id="search-input" placeholder="Patient or Service Name" value="<?= htmlspecialchars($search_term) ?>">
        <input type="hidden" name="mode" value="<?= htmlspecialchars($filter_mode) ?>">
        <button type="submit"><i class="fas fa-search"></i> Search</button>
    </form>
</div>
<?php if (empty($bookings)): ?>
    <div class="flash-message" style="background:#fff3cd; color:#856404; border:1px solid #856404;">
        <i class="fas fa-exclamation-triangle"></i> No bookings found matching your criteria.
    </div>
<?php else: ?>
    <table class="data-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Patient</th>
                <th>Service</th>
                <th>Payment Type</th> 
                <th>Initial Fee</th> 
                <th>Term</th> 
                <th>Mode</th>
                <th>Booking Status</th>
                <th>Payment Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bookings as $booking): ?>
                <tr>
                    <td><?= htmlspecialchars($booking['payment_id']) ?></td>
                    <td><?= date('M d, Y', strtotime($booking['booking_date'])) ?></td>
                    <td><?= htmlspecialchars($booking['patient_name']) ?></td>
                    <td><?= htmlspecialchars($booking['service_name']) ?></td>
                    
                    <td>
                        <span class="status-badge status-<?= strtolower($booking['payment_option']) ?>">
                            <?= ucfirst($booking['payment_option']) ?>
                        </span>
                    </td>
                    
                    <td>₱<?= number_format($booking['initial_fee'], 2) ?></td>
                    
                    <td>
                        <?= ($booking['payment_option'] === 'installment') ? htmlspecialchars($booking['installment_term'] . ' mos') : 'N/A' ?>
                    </td>
                    
                    <td>
                        <span class="status-badge status-<?= strtolower(str_replace('-', '', $booking['payment_method'])) ?>">
                            <?= strtoupper($booking['payment_method']) ?>
                        </span>
                    </td>
                    
                    <td>
                        <span class="status-badge status-<?= strtolower($booking['booking_status'] ?? 'pending') ?>">
                            <?= ucfirst($booking['booking_status'] ?? 'Pending') ?>
                        </span>
                    </td>
                    <td>
                        <span class="status-badge status-<?= strtolower($booking['payment_status'] ?? 'pending') ?>">
                            <?= ucfirst($booking['payment_status'] ?? 'Pending') ?>
                        </span>
                    </td>
                    
                    <td class="action-cell">
                        <div class="action-buttons-group">
                            <?php 
                            // Determine if Process Payment is needed (Only for Booked/Pending Online or Walk-in/Pending)
                            $is_ready_to_process = (
                                (strtolower($booking['booking_status'] ?? 'pending') === 'booked' && strtolower($booking['payment_status'] ?? 'pending') === 'pending' && $booking['payment_method'] === 'Online') ||
                                ($booking['payment_method'] === 'Walk-in' && strtolower($booking['payment_status'] ?? 'pending') !== 'paid')
                            );

                            if ($is_ready_to_process): 
                                // --- REVISED URL TO PASS UNIQUE IDs ---
                                $processUrl = "payments.php?tab=new_service" . 
                                    "&online_booking_process=1" . 
                                    "&payment_id=" . $booking['payment_id'] .             /* <--- NEW */
                                    "&appointment_id=" . $booking['appointment_id'] .     /* <--- NEW */
                                    "&patient_id=" . $booking['patient_id'] . 
                                    "&service_id=" . $booking['service_id'] . 
                                    "&service_price=" . $booking['service_price'] . 
                                    "&downpayment=" . $booking['initial_fee'];
                            ?>
                                <a href="<?= $processUrl ?>" class="action-btn btn-process">
                                    <i class="fas fa-cash-register"></i> Process
                                </a>
                            <?php endif; ?>

                            <?php if (strtolower($booking['payment_status'] ?? 'pending') === 'pending'): ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="payment_id" value="<?= htmlspecialchars($booking['payment_id']) ?>">
                                    <button type="submit" name="send_reminder" class="action-btn btn-reminder" onclick="return confirm('Are you sure you want to send a payment reminder (Email Only) to <?= htmlspecialchars($booking['patient_name']) ?>?')">
                                        <i class="fas fa-bell"></i> Reminder (Email)
                                    </button>
                                </form>
                            <?php endif; ?>
                            
                            <button class="action-btn btn-view" 
                                onclick="viewBookingDetails(
                                    '<?= htmlspecialchars($booking['patient_name']) ?>',
                                    '<?= htmlspecialchars($booking['service_name']) ?>',
                                    '<?= htmlspecialchars($booking['payment_id']) ?>', 
                                    '<?= htmlspecialchars($booking['proof_of_payment']) ?>', 
                                    '<?= htmlspecialchars($booking['proof_image_url'] ? '../' . $booking['proof_image_url'] : 'N/A') ?>',
                                    '<?= htmlspecialchars($booking['payment_option']) ?>',
                                    '<?= htmlspecialchars($booking['installment_term']) ?>',
                                    '<?= number_format($booking['monthly_payment'], 2) ?>'
                                )">
                                <i class="fas fa-eye"></i> View
                            </button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<div id="bookingDetailsModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="document.getElementById('bookingDetailsModal').style.display='none'">&times;</span>
        <div class="modal-header">
            <h2><i class="fas fa-info-circle"></i> Booking Details</h2>
        </div>

        <div class="modal-body">
            <div class="modal-info-row">
                <strong>Patient Name:</strong> <span id="modal-patient-name"></span>
            </div>
            <div class="modal-info-row">
                <strong>Service Booked:</strong> <span id="modal-service-name"></span>
            </div>
            <div class="modal-info-row">
                <strong>Payment ID:</strong> <span id="modal-payment-id"></span>
            </div>
            <div class="modal-info-row">
                <strong>Payment Type:</strong> <span id="modal-payment-option"></span>
            </div>
            <div class="modal-info-row">
                <strong>Initial Fee:</strong> <span id="modal-downpayment"></span>
            </div>
            <div class="modal-info-row" id="modal-term-row">
                <strong>Installment Term:</strong> <span id="modal-term"></span>
            </div>
            <div class="modal-info-row" id="modal-monthly-row">
                <strong>Monthly Payment:</strong> <span id="modal-monthly-payment"></span>
            </div>
            <div class="modal-info-row">
                <strong>Reference ID:</strong> <span id="modal-proof-id"></span>
            </div>

            <div class="proof-section">
                <h3>Proof of Payment</h3>
                <p id="proof-status"></p>
                <a id="proof-image-link" href="#" target="_blank" style="display: none;">
                    <img id="proof-image" class="proof-image" src="" alt="Proof of Payment">
                </a>
            </div>
        </div>
    </div>
</div>


<script>
/**
 * Populates and displays the modal with booking and payment details.
 */
function viewBookingDetails(patientName, serviceName, id, proofId, imageUrl, paymentOption, downpayment, term, monthlyPayment) {
    const modal = document.getElementById('bookingDetailsModal');
    
    // Set general details
    document.getElementById('modal-patient-name').textContent = patientName;
    document.getElementById('modal-service-name').textContent = serviceName;
    document.getElementById('modal-payment-id').textContent = id;
    document.getElementById('modal-payment-option').textContent = paymentOption.toUpperCase();
    document.getElementById('modal-downpayment').textContent = '₱' + downpayment;
    document.getElementById('modal-proof-id').textContent = proofId || 'N/A';
    
    // Handle installment specific fields
    const termRow = document.getElementById('modal-term-row');
    const monthlyRow = document.getElementById('modal-monthly-row');

    if (paymentOption.toLowerCase() === 'installment') {
        document.getElementById('modal-term').textContent = term + ' months';
        document.getElementById('modal-monthly-payment').textContent = '₱' + monthlyPayment;
        termRow.style.display = 'flex';
        monthlyRow.style.display = 'flex';
    } else {
        termRow.style.display = 'none';
        monthlyRow.style.display = 'none';
    }

    // Handle Proof of Payment Image
    const proofImage = document.getElementById('proof-image');
    const proofImageLink = document.getElementById('proof-image-link');
    const proofStatus = document.getElementById('proof-status');

    if (imageUrl && imageUrl !== 'N/A' && proofId !== 'N/A') {
        proofImage.src = imageUrl;
        proofImageLink.href = imageUrl;
        proofImageLink.style.display = 'block';
        proofImage.style.display = 'block';
        proofStatus.textContent = '';
    } else {
        proofImage.src = ''; // Clear source
        proofImage.style.display = 'none';
        proofImageLink.style.display = 'none';
        proofStatus.textContent = 'No digital proof of payment was provided or recorded.';
    }

    // Display the modal
    modal.style.display = 'block';
}

// Close the modal if the user clicks anywhere outside of it
window.onclick = function(event) {
    const modal = document.getElementById('bookingDetailsModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
</script>

</main>
</body>
</html>