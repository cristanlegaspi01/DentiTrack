<?php
session_start();
// 1. Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: ../public/login.php');
    exit();
}

// 2. Database Connection
if (file_exists('../config/db_pdo.php')) {
    include '../config/db_pdo.php'; 
} else {
    die("Error: Could not find database config file at ../config/db_pdo.php");
}
$conn = $pdo; 

$secretary_username = $_SESSION['username'] ?? 'Secretary';
$message = '';
$errors = [];

// 3. Handle Update Submission (From the Modal)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_patient'])) {
    $patient_id = $_POST['patient_id'];
    $email = trim($_POST['email']);
    $contact_number = trim($_POST['contact_number']);
    $address = trim($_POST['address']);
    $emergency_name = trim($_POST['emergency_contact_name']);
    $emergency_num  = trim($_POST['emergency_contact_number']);
    $medical_history = trim($_POST['medical_history']);
    $allergies = trim($_POST['allergies']);
    $notes = trim($_POST['notes']);

    try {
        $sql = "UPDATE patient SET 
                email=:email, 
                contact_number=:contact_number, 
                address=:address, 
                emergency_contact_name=:ec_name,
                emergency_contact_number=:ec_num,
                medical_history=:med_hist,
                allergies=:allergies,
                notes=:notes, 
                updated_at=NOW() 
                WHERE patient_id=:patient_id";

        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':email' => $email,
            ':contact_number' => $contact_number,
            ':address' => $address,
            ':ec_name' => $emergency_name,
            ':ec_num' => $emergency_num,
            ':med_hist' => $medical_history,
            ':allergies' => $allergies,
            ':notes' => $notes,
            ':patient_id' => $patient_id
        ]);
        $message = "Patient record updated successfully!";
    } catch(PDOException $e){
        $errors[] = "Database error: ".$e->getMessage();
    }
}

// 4. Search Logic
$search = $_GET['search'] ?? '';
$patients = [];

try {
    // CHANGED: ORDER BY patient_id ASC (Sequence Order: 1, 2, 3...)
    $query = "SELECT * FROM patient 
              WHERE fullname LIKE :search 
              OR email LIKE :search 
              OR contact_number LIKE :search 
              OR patient_id LIKE :search
              ORDER BY patient_id ASC"; 
              
    $stmt = $conn->prepare($query);
    $stmt->execute([':search'=>"%$search%"]);
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e){
    $errors[] = "Database error: ".$e->getMessage();
}

// 5. AJAX HANDLER (Outputs table rows only)
if (isset($_GET['ajax_request'])) {
    if ($patients) {
        foreach($patients as $p) {
            renderPatientRow($p);
        }
    } else {
        echo '<tr><td colspan="8" style="text-align:center; padding: 20px;">No patients found.</td></tr>';
    }
    exit(); 
}

// Helper function to render a row
function renderPatientRow($p) {
    // Format the date nicely
    $dateCreated = date("M d, Y", strtotime($p['created_at']));
    $timeCreated = date("h:i A", strtotime($p['created_at']));
    ?>
    <tr>
        <td><?php echo htmlspecialchars($p['patient_id']); ?></td>
        <td>
            <strong><?php echo htmlspecialchars($p['fullname']); ?></strong><br>
            <small style="color:#666;"><?php echo htmlspecialchars($p['email']); ?></small>
        </td>
        <td>
            <?php echo htmlspecialchars($p['dob']); ?><br>
            <small><?php echo htmlspecialchars($p['gender']); ?></small>
        </td>
        <td><?php echo htmlspecialchars($p['contact_number']); ?></td>
        <td><?php echo htmlspecialchars($p['address']); ?></td>
        
        <td>
            <?php echo $dateCreated; ?><br>
            <small style="color:#888;"><?php echo $timeCreated; ?></small>
        </td>

        <td style="font-weight:bold; color: <?php echo ($p['outstanding_balance'] > 0) ? '#d9534f' : '#5cb85c'; ?>">
            ₱<?php echo number_format($p['outstanding_balance'], 2); ?>
        </td>
        <td>
            <button class="btn-edit" 
                onclick="openModal(
                    '<?php echo $p['patient_id']; ?>',
                    '<?php echo htmlspecialchars($p['fullname'], ENT_QUOTES); ?>',
                    '<?php echo htmlspecialchars($p['email'], ENT_QUOTES); ?>',
                    '<?php echo htmlspecialchars($p['contact_number'], ENT_QUOTES); ?>',
                    '<?php echo htmlspecialchars($p['address'], ENT_QUOTES); ?>',
                    '<?php echo htmlspecialchars($p['emergency_contact_name'], ENT_QUOTES); ?>',
                    '<?php echo htmlspecialchars($p['emergency_contact_number'], ENT_QUOTES); ?>',
                    '<?php echo htmlspecialchars($p['medical_history'], ENT_QUOTES); ?>',
                    '<?php echo htmlspecialchars($p['allergies'], ENT_QUOTES); ?>',
                    '<?php echo htmlspecialchars($p['notes'], ENT_QUOTES); ?>'
                )">
                <i class="fas fa-edit"></i> Edit
            </button>
        </td>
    </tr>
    <?php
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Find Patient - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous">
<style>
    body{margin:0;font-family:Segoe UI,sans-serif;background:#e6f0ff;color:#003366;display:flex;min-height:100vh;}
    .sidebar{width:220px;background:linear-gradient(to bottom,#3399ff,#0066cc);padding:20px;color:white;display:flex;flex-direction:column;}
    .sidebar h2{text-align:center;margin-bottom:30px;font-size:24px;font-weight:700;}
    .sidebar a{display:block;padding:12px 20px;margin:10px 0;color:#cce0ff;text-decoration:none;border-left:4px solid transparent;font-weight:600;transition:.3s ease;border-radius:6px 0 0 6px;}
    .sidebar a:hover,.sidebar a.active{background-color: rgba(255,255,255,.15); border-left:4px solid #ffcc00;color:white;}
    main.main-content{flex:1;padding:40px 60px;background:white;border-radius:0 20px 20px 0;box-shadow:4px 0 20px rgba(0,0,0,0.1); position: relative;}
    header h1{font-size:2.2rem;color:#004080;display:flex;align-items:center;gap:.5rem;margin-bottom:.5rem;}
    .welcome{font-size:1.2rem;margin-bottom:1rem;font-weight:600;}
    .message{padding:15px;margin-bottom:20px;border-radius:10px;background:#d9e8ff;color:#004080;font-weight:bold;text-align:center;}
    .error-list{background:#ffd6d6;border:1px solid #ff4d4d;padding:15px 20px;margin-bottom:20px;border-radius:10px;color:#b30000;font-weight:600;}
    
    /* Search Box */
    .search-container { position: relative; display: inline-block; margin-bottom: 10px; }
    input[type="text"].search-input{
        padding:10px 12px; font-size:16px; border:1.5px solid #b3c6ff;
        border-radius:12px; width:300px; transition: all 0.3s ease;
    }
    input[type="text"].search-input:focus { border-color: #0066cc; outline: none; }
    
    /* Table Styles */
    table{width:100%;border-collapse:collapse;margin-top:20px; font-size: 0.9rem;}
    th, td{border:1px solid #b3c6ff;padding:10px;text-align:left;border-radius:4px;}
    th{background:#3399ff;color:white; font-weight: 600;}
    tr:nth-child(even) {background-color: #f2f7ff;}
    
    /* Buttons */
    button.btn-edit{padding:6px 12px;background:#ff9900;color:white;border:none;border-radius:6px;font-weight:600;cursor:pointer;transition:.3s; font-size: 0.85rem;}
    button.btn-edit:hover{background:#cc7a00;}

    /* MODAL STYLES */
    .modal-overlay {
        display: none; 
        position: fixed; z-index: 1000; left: 0; top: 0;
        width: 100%; height: 100%;
        background-color: rgba(0,0,0,0.5);
        justify-content: center; align-items: center;
    }
    .modal-content {
        background-color: white;
        padding: 25px;
        border-radius: 15px;
        width: 600px;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        position: relative;
        animation: slideDown 0.3s ease-out;
    }
    @keyframes slideDown { from {transform: translateY(-50px); opacity:0;} to {transform: translateY(0); opacity:1;} }
    
    .close-btn { position: absolute; top: 15px; right: 20px; font-size: 24px; cursor: pointer; color: #666; }
    .close-btn:hover { color: #000; }
    
    .form-row { display: flex; gap: 15px; margin-bottom: 15px; }
    .form-group { flex: 1; }
    .form-group label { display: block; margin-bottom: 5px; font-weight: bold; color: #003366; font-size: 0.9rem;}
    .form-group input, .form-group textarea { 
        width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box;
    }
    .section-title {
        border-bottom: 2px solid #eee; padding-bottom: 5px; margin-bottom: 15px; margin-top: 10px;
        color: #0066cc; font-weight: bold;
    }
    .modal-actions { text-align: right; margin-top: 20px; }
    .btn-save { padding: 10px 25px; background: #0066cc; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold; }
    .btn-save:hover { background: #004080; }
</style>
</head>
<body>
<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="secretary_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="find_patient.php" class="active"><i class="fas fa-search"></i> Find Patient</a>
    <a href="view_patients.php"><i class="fas fa-users"></i> View Patients</a>
    <a href="payments.php"><i class="fas fa-cash-register"></i> Payments</a>
    <a href="online_bookings.php" ><i class="fas fa-laptop-code"></i> Online Bookings</a>
    <a href="payment_logs.php"><i class="fas fa-file-invoice-dollar"></i> Payments Log</a>
    <a href="services_list.php"><i class="fas fa-list"></i> Services</a>
    <a href="appointments.php"><i class="fas fa-calendar-check"></i> Manage Consultation</a>
    <a href="create_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
    <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">
    <header>
        <h1><i class="fas fa-search"></i> Find Patient</h1>
        <div class="welcome">Logged in as <strong><?php echo htmlspecialchars($secretary_username); ?></strong></div>
    </header>

    <?php if($message):?><div class="message"><?php echo htmlspecialchars($message);?></div><?php endif;?>
    <?php if($errors):?><div class="error-list"><ul><?php foreach($errors as $err):?><li><?php echo htmlspecialchars($err);?></li><?php endforeach;?></ul></div><?php endif;?>

    <div class="search-container">
        <input type="text" id="search_input" class="search-input" placeholder="Search Name, ID, Email or Contact..." value="<?php echo htmlspecialchars($search); ?>" autocomplete="off">
    </div>

    <table>
        <thead>
            <tr>
                <th style="width: 5%;">ID</th>
                <th style="width: 18%;">Full Name & Email</th>
                <th style="width: 10%;">DOB / Gender</th>
                <th style="width: 12%;">Contact</th>
                <th style="width: 15%;">Address</th>
                <th style="width: 10%;">Date Added</th>
                <th style="width: 12%;">Balance</th>
                <th style="width: 8%;">Action</th>
            </tr>
        </thead>
        <tbody id="patient_table_body">
        <?php if($patients): ?>
            <?php foreach($patients as $p): ?>
                <?php renderPatientRow($p); ?>
            <?php endforeach;?>
        <?php else: ?>
            <tr><td colspan="8" style="text-align:center; padding: 20px;">No patients found.</td></tr>
        <?php endif;?>
        </tbody>
    </table>
</main>

<div id="editModal" class="modal-overlay">
    <div class="modal-content">
        <span class="close-btn" onclick="closeModal()">&times;</span>
        <h2 style="margin-top:0; color:#003366;">Edit Patient Details</h2>
        <p id="modal_patient_name" style="color:#666; margin-bottom:20px; border-bottom: 1px solid #ddd; padding-bottom: 10px;"></p>
        
        <form method="post">
            <input type="hidden" name="patient_id" id="modal_patient_id">
            
            <div class="section-title">Contact Information</div>
            <div class="form-row">
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="text" name="email" id="modal_email">
                </div>
                <div class="form-group">
                    <label>Contact Number</label>
                    <input type="text" name="contact_number" id="modal_contact">
                </div>
            </div>
            <div class="form-group" style="margin-bottom:15px;">
                <label>Home Address</label>
                <input type="text" name="address" id="modal_address">
            </div>

            <div class="section-title">Emergency Contact</div>
            <div class="form-row">
                <div class="form-group">
                    <label>Contact Person</label>
                    <input type="text" name="emergency_contact_name" id="modal_em_name">
                </div>
                <div class="form-group">
                    <label>Emergency Number</label>
                    <input type="text" name="emergency_contact_number" id="modal_em_num">
                </div>
            </div>

            <div class="section-title">Medical Information</div>
            <div class="form-row">
                <div class="form-group">
                    <label>Medical History</label>
                    <textarea name="medical_history" id="modal_med_history" rows="2"></textarea>
                </div>
                <div class="form-group">
                    <label>Allergies</label>
                    <textarea name="allergies" id="modal_allergies" rows="2"></textarea>
                </div>
            </div>

            <div class="form-group">
                <label>General Notes</label>
                <textarea name="notes" id="modal_notes" rows="2"></textarea>
            </div>
            
            <div class="modal-actions">
                <button type="submit" name="update_patient" class="btn-save">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
    // 1. MODAL LOGIC
    const modal = document.getElementById('editModal');

    function openModal(id, name, email, contact, address, em_name, em_num, med_hist, allergies, notes) {
        document.getElementById('modal_patient_id').value = id;
        document.getElementById('modal_patient_name').innerText = "Editing: " + name + " (ID: " + id + ")";
        
        document.getElementById('modal_email').value = email;
        document.getElementById('modal_contact').value = contact;
        document.getElementById('modal_address').value = address;
        
        document.getElementById('modal_em_name').value = em_name;
        document.getElementById('modal_em_num').value = em_num;
        
        document.getElementById('modal_med_history').value = med_hist;
        document.getElementById('modal_allergies').value = allergies;
        document.getElementById('modal_notes').value = notes;
        
        modal.style.display = 'flex';
    }

    function closeModal() {
        modal.style.display = 'none';
    }

    window.onclick = function(event) {
        if (event.target == modal) {
            closeModal();
        }
    }

    // 2. SEARCH LOGIC (AJAX)
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('search_input');
        const tableBody = document.getElementById('patient_table_body');
        let timeout = null;

        searchInput.addEventListener('input', function() {
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                const query = searchInput.value;
                const url = `?ajax_request=1&search=${encodeURIComponent(query)}`;

                fetch(url)
                    .then(response => {
                        if (!response.ok) { throw new Error('Network response was not ok'); }
                        return response.text();
                    })
                    .then(html => {
                        tableBody.innerHTML = html;
                    })
                    .catch(error => console.error('Error:', error));
            }, 300); 
        });
    });
</script>
</body>
</html>