<?php
session_start();
include '../config/db_pdo.php';
include '../config/db_conn.php';

// Ensure PDO throws exceptions
if (isset($conn)) {
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}

// Check secretary role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    // If running in a live environment, uncomment the two lines below:
    // header('Location: ../public/login.php');
    // exit();
}

$payment_id = intval($_GET['id'] ?? 0);
if ($payment_id <= 0) {
    die("Invalid payment ID.");
}

$payment = false;
$supplies = [];

if (isset($conn)) {
    try {
        // --- 1. Fetch payment info with patient and service details ---
        // Use a LEFT JOIN for the services table so that payments without a service_id (like installment payments) don't break the query.
        $stmt = $conn->prepare("
            SELECT 
                p.*, 
                pa.first_name, 
                pa.last_name, 
                s.service_name, 
                s.price AS service_price
            FROM payments p
            JOIN patient pa ON p.patient_id = pa.patient_id
            LEFT JOIN services s ON p.service_id = s.service_id
            WHERE p.payment_id = :id
        ");
        $stmt->execute([':id' => $payment_id]);
        $payment = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$payment) {
            die("Payment not found.");
        }

        // --- 2. Fetch supplies used for this specific payment ---
        $supplyStmt = $conn->prepare("
            SELECT ds.name, su.quantity_used, ds.unit, ds.price
            FROM supply_usage su
            JOIN dental_supplies ds ON su.supply_id = ds.supply_id
            WHERE su.payment_id = :payment_id
        ");
        $supplyStmt->execute([':payment_id' => $payment['payment_id']]);
        $supplies = $supplyStmt->fetchAll(PDO::FETCH_ASSOC);
        
        
        // --- 3. Determine the Payment Type and Cash Received ---
        $payment_option = $payment['payment_option'];
        
        if ($payment_option === 'full') {
            // Full payment: Cash received is the full total amount after discount.
            $cash_received = floatval($payment['total_amount']);
            $receipt_title = "FULL PAYMENT RECEIPT";
        } elseif ($payment_option === 'installment') {
            // New installment: Cash received is the downpayment.
            $cash_received = floatval($payment['downpayment']);
            $receipt_title = "INSTALLMENT DOWNPAYMENT RECEIPT";
        } elseif ($payment_option === 'installment_payment') {
            // Payment towards existing debt: Cash received is logged in 'downpayment' column in payments.php
            $cash_received = floatval($payment['downpayment']); 
            $receipt_title = "INSTALLMENT PAYMENT RECEIPT";
        } else {
            // Default/Fallback
            $cash_received = floatval($payment['total_amount']);
            $receipt_title = "PAYMENT RECEIPT";
        }
        
    } catch (Exception $e) {
        die("Database error: " . $e->getMessage());
    }
} else {
    die("Database connection failed.");
}

$is_installment_plan = ($payment['payment_option'] === 'installment');
$is_installment_settlement = ($payment['payment_option'] === 'installment_payment');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Payment Receipt - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<style>
body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#f0f7ff;color:#003366;padding:20px;}
.receipt{max-width:700px;margin:auto;background:white;padding:30px;border-radius:20px;box-shadow:0 10px 25px rgba(0,0,0,0.1);}
.receipt h2{text-align:center;margin-bottom:20px;color:#004080;}
.receipt .row{display:flex;justify-content:space-between;margin:8px 0;border-bottom:1px dashed #ccc;padding-bottom:5px;}
.receipt .row strong:first-child{font-weight:600;}
.receipt table{width:100%;border-collapse:collapse;margin-top:15px;margin-bottom:20px;}
.receipt table th, .receipt table td{border:1px solid #3399ff;padding:10px 8px;text-align:left;}
.receipt table th{background:#eaf3ff;}
.print-btn, .proceed-btn{display:block;margin:20px auto 10px;padding:12px 30px;border:none;border-radius:15px;font-weight:700;cursor:pointer;box-shadow:0 5px 15px rgba(51,153,255,0.5);}
.print-btn{background:#3399ff;color:white;}
.print-btn:hover{background:#0066cc;}
.proceed-btn{background:#28a745;color:white;}
.proceed-btn:hover{background:#218838;}
.installment-info{margin-top:20px;padding:15px;border:1px solid #ffcc00;background:#fff8e6;border-radius:10px;}
.installment-info h3{margin-top:0; color:#004080;}
.installment-info .row{border-bottom:none;padding:3px 0;}
.total-line{font-size: 1.2rem; font-weight: bold; border-top: 2px solid #003366; padding-top: 10px; margin-top: 15px !important;}
.cash-received-line{font-size: 1.4rem; font-weight: bold; color: #28a745; border-top: 2px solid #28a745; padding-top: 10px; margin-top: 15px !important;}

@media print {
    body{background: none;}
    .receipt{box-shadow: none; border: 1px solid #000; border-radius: 0;}
    .print-btn, .proceed-btn{display: none;}
}
</style>
</head>
<body>

<div class="receipt">
    <h2><i class="fas fa-receipt"></i> <?= htmlspecialchars($receipt_title) ?></h2>

    <div class="row"><strong>Receipt ID:</strong> <?= htmlspecialchars($payment['payment_id']) ?></div>
    <div class="row"><strong>Patient Name:</strong> <?= htmlspecialchars($payment['first_name'].' '.$payment['last_name']) ?></div>
    <div class="row"><strong>Payment Method:</strong> <?= ucfirst(htmlspecialchars($payment['payment_method'])) ?></div>
    <div class="row"><strong>Payment Option:</strong> **<?= htmlspecialchars(ucfirst($payment['payment_option'])) ?>**</div>
    <div class="row"><strong>Payment Status:</strong> **<?= htmlspecialchars(ucfirst($payment['status'])) ?>**</div>
    <div class="row"><strong>Payment Date:</strong> <?= date('M d, Y H:i', strtotime($payment['payment_date'])) ?></div>

    <?php if (!$is_installment_settlement): // Only show itemized breakdown for new services ?>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    // Calculate Service Subtotal
                    $service_subtotal = floatval($payment['service_price'] ?? 0);
                    $total_service_and_supply_cost = $service_subtotal;
                ?>
                <tr>
                    <td><?= htmlspecialchars($payment['service_name'] ?? 'N/A') ?></td>
                    <td>1</td>
                    <td>₱<?= number_format($service_subtotal,2) ?></td>
                    <td>₱<?= number_format($service_subtotal,2) ?></td>
                </tr>

                <?php if(!empty($supplies)): ?>
                    <?php foreach($supplies as $s): ?>
                        <?php 
                            $supply_subtotal = floatval($s['price']) * floatval($s['quantity_used']);
                            $total_service_and_supply_cost += $supply_subtotal;
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($s['name']) ?></td>
                            <td><?= htmlspecialchars($s['quantity_used']).' '.htmlspecialchars($s['unit']) ?></td>
                            <td>₱<?= number_format($s['price'],2) ?></td>
                            <td>₱<?= number_format($supply_subtotal,2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <div class="row"><strong>--- SERVICE SUMMARY ---</strong></div>
        <div class="row"><strong>Total Item Cost:</strong> ₱<?= number_format($total_service_and_supply_cost,2) ?></div>
        <div class="row"><strong>Discount (<?= htmlspecialchars($payment['discount_type']) ?>):</strong> ₱<?= number_format($payment['discount_amount'],2) ?></div>
        <div class="row total-line"><strong>TOTAL BILL (Due to Clinic):</strong> ₱<?= number_format($payment['total_amount'],2) ?></div>

        <?php if ($is_installment_plan): ?>
            <div class="installment-info">
                <h3>Installment Plan Details (New Debt)</h3>
                <div class="row"><strong>Total Amount Billed (Debt Principal):</strong> ₱<?= number_format($payment['total_amount'],2) ?></div>
                <div class="row"><strong>Downpayment Paid Now:</strong> ₱<?= number_format($payment['downpayment'],2) ?></div>
                <div class="row"><strong>Remaining Debt:</strong> ₱<?= number_format($payment['total_amount'] - $payment['downpayment'], 2) ?></div>
                <div class="row"><strong>Installment Term:</strong> <?= htmlspecialchars($payment['installment_term']) ?> Months</div>
                <div class="row"><strong>Monthly Payment Due:</strong> ₱<?= number_format($payment['monthly_payment'],2) ?></div>
            </div>
        <?php endif; ?>
    <?php else: // installment_payment settlement ?>
        <div class="installment-info" style="background:#e6ffe6; border-color:#28a745;">
            <h3>Payment Towards Existing Installment Plan</h3>
            <div class="row"><strong>Payment Type:</strong> Installment Settlement</div>
            <div class="row"><strong>Reference Service:</strong> <?= htmlspecialchars($payment['service_name'] ?? 'N/A') ?></div>
            <div class="row"><strong>Payment Date:</strong> <?= date('M d, Y H:i', strtotime($payment['payment_date'])) ?></div>
        </div>
        <div class="row total-line" style="border-color:#28a745; margin-top:20px !important;">
            <strong>SETTLED DEBT AMOUNT:</strong> ₱<?= number_format($payment['downpayment'],2) ?>
        </div>
    <?php endif; ?>

    <div class="row cash-received-line">
        <strong>CASH RECEIVED THIS TRANSACTION:</strong> ₱<?= number_format($cash_received,2) ?>
    </div>

    <button class="print-btn" onclick="window.print()"><i class="fas fa-print"></i> Print Receipt</button>
    <button class="proceed-btn" onclick="window.location.href='payments.php'"><i class="fas fa-arrow-right"></i> Proceed to Payments</button>
</div>

</body>
</html>