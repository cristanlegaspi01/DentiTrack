<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: ../public/login.php');
    exit();
}

include '../config/db.php'; // using PDO connection
include '../config/db_conn.php';

$secretary_username = $_SESSION['username'];

// ✅ Handle AJAX update for status
if (isset($_POST['ajax']) && $_POST['ajax'] === '1') {
    $service_id = $_POST['service_id'];
    $status = $_POST['status'];

    $update = $conn->prepare("UPDATE services SET status = :status WHERE service_id = :id");
    $update->bindParam(':status', $status);
    $update->bindParam(':id', $service_id);
    $update->execute();

    echo "success";
    exit;
}

// Fetch all services in ascending order by service_id
$sql = "SELECT * FROM services ORDER BY service_id ASC";
$stmt = $conn->prepare($sql);
$stmt->execute();
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Services List - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background: #e6f0ff;
        color: #003366;
        height: 100vh;
        display: flex;
    }

    .sidebar {
        width: 220px;
        background: linear-gradient(to bottom, #3399ff, #0066cc);
        padding: 20px;
        color: white;
        box-shadow: 2px 0 10px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
    }

    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        font-weight: 700;
        user-select: none;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }

    .sidebar a {
        display: block;
        padding: 12px 20px;
        margin: 10px 0;
        color: #cce0ff;
        text-decoration: none;
        border-left: 4px solid transparent;
        font-weight: 600;
        transition: background-color 0.3s ease, border-left-color 0.3s ease;
    }

    .sidebar a:hover,
    .sidebar a.active {
        background-color: rgba(255,255,255,0.15);
        color: white;
        border-left: 4px solid #ffcc00;
    }

    .main-content {
        flex: 1;
        padding: 40px;
        background: white;
        overflow-y: auto;
    }

    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }

    header h1 {
        font-size: 2rem;
        color: #004080;
        text-shadow: 1px 1px 2px #a3c2ff;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .welcome {
        font-size: 1.3rem;
        margin-bottom: 2rem;
        font-weight: 600;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background: #f0f7ff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    th, td {
        padding: 14px;
        text-align: left;
        border-bottom: 1px solid #cce0ff;
    }

    th {
        background-color: #3399ff;
        color: white;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    tr:hover {
        background-color: #d9e8ff;
    }

    .price {
        font-weight: bold;
        color: #004080;
    }

    .no-data {
        text-align: center;
        padding: 20px;
        color: #666;
    }

    select {
        padding: 6px 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 14px;
        cursor: pointer;
    }

    .success-message {
        position: fixed;
        top: 20px;
        right: 20px;
        background: #28a745;
        color: white;
        padding: 10px 20px;
        border-radius: 6px;
        font-weight: 600;
        display: none;
        z-index: 1000;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
</style>
</head>
<body>
    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="secretary_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
         <a href="find_patient.php" ><i class="fas fa-search"></i> Find Patient</a>
        <a href="view_patients.php"><i class="fas fa-users"></i> View Patients</a>
        <a href="payments.php"><i class="fas fa-cash-register"></i> Payments</a>
        <a href="online_bookings.php"><i class="fas fa-laptop-code"></i> Online Bookings</a>
        <a href="payment_logs.php" ><i class="fas fa-file-invoice-dollar"></i> Payments Log</a>
        <a href="services_list.php" class="active"><i class="fas fa-list"></i> Services</a>
        <a href="appointments.php"><i class="fas fa-calendar-check"></i> Manage Consultation</a>
        <a href="create_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>

    <main class="main-content">
        <header>
            <h1><i class="fas fa-list"></i> Services List</h1>
        </header>

        <p class="welcome">Welcome, <strong><?= htmlspecialchars($secretary_username) ?></strong>! Here’s the list of dental services available:</p>

        <div class="success-message" id="successMsg">Status updated successfully!</div>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Service Name</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th>Price (₱)</th>
                    <th>Duration</th>
                    <th>Created At</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($services) > 0): ?>
                    <?php foreach ($services as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['service_id']) ?></td>
                            <td><?= htmlspecialchars($row['service_name']) ?></td>
                            <td><?= htmlspecialchars($row['category']) ?></td>
                            <td><?= htmlspecialchars($row['description']) ?></td>
                            <td class="price">₱<?= number_format($row['price'], 2) ?></td>
                            <td><?= htmlspecialchars($row['duration']) ?></td>
                            <td><?= htmlspecialchars(date('M d, Y', strtotime($row['created_at']))) ?></td>
                            <td>
                                <select class="status-select" data-id="<?= $row['service_id'] ?>">
                                    <option value="active" <?= ($row['status'] == 'active') ? 'selected' : '' ?>>Active</option>
                                    <option value="inactive" <?= ($row['status'] == 'inactive') ? 'selected' : '' ?>>Inactive</option>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="8" class="no-data">No services found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>

<script>
document.querySelectorAll('.status-select').forEach(select => {
    select.addEventListener('change', function() {
        const serviceId = this.dataset.id;
        const newStatus = this.value;

        const formData = new FormData();
        formData.append('ajax', '1');
        formData.append('service_id', serviceId);
        formData.append('status', newStatus);

        fetch('services_list.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.text())
        .then(response => {
            if (response.trim() === 'success') {
                const msg = document.getElementById('successMsg');
                msg.style.display = 'block';
                setTimeout(() => msg.style.display = 'none', 2000);
            }
        });
    });
});
</script>

</body>
</html>