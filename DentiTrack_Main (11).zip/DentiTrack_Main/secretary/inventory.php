<?php
session_start();
// Use require_once to ensure execution stops if the database connection fails
require_once '../config/db_pdo.php'; 
// The db_conn.php include is kept as you included it, but the main logic uses PDO ($conn)
include '../config/db_conn.php'; 

// Check secretary role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: secretary_login.php');
    exit();
}

$message = '';
$error = '';

// --- Normalization function ---
// Standardizes item names
function normalizeName($name) {
    $name = trim($name);
    $name = strtolower($name);
    // Capitalize each word, better for dental supply names
    $name = ucwords($name); 
    return $name;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_or_update') {
        // Core Item Details
        $name = normalizeName($_POST['name_input'] ?? '');
        // supply_id is the primary key in the single-table model (if updating an existing record)
        $supply_id = intval($_POST['supply_id'] ?? 0); 
        $description = trim($_POST['description'] ?? '');
        $unit = trim($_POST['unit'] ?? 'pcs');
        $low_stock_threshold = intval($_POST['low_stock_threshold'] ?? 5);
        $price = floatval($_POST['price'] ?? 0);
        
        // NEW: Lot Number Field - Using the variable as requested
        $lot_number = trim($_POST['lot_number'] ?? ''); 
        
        // Batch Details 
        $quantity = intval($_POST['quantity'] ?? 0);
        // Expiration date is required for stock update
        $expiration_date = $_POST['expiration_date'] ?: null; 
        
        $item_id_placeholder = $supply_id; 

        if ($name === '' || $quantity < 0 || $low_stock_threshold < 0) {
            $error = "Please fill out all required fields correctly (especially Item Name and Quantity)."; 
        } else {
            try {
                // Use transactions for safety
                $conn->beginTransaction();

                if ($supply_id > 0) {
                    // Item/Record already exists, update its details
                    $sql_supply = "UPDATE dental_supplies 
                                 SET name = :name,
                                     description = :description,
                                     unit = :unit,
                                     low_stock_threshold = :low_stock_threshold,
                                     quantity = :quantity,
                                     expiration_date = :expiration_date,
                                     price = :price,
                                     lot_number = :lot_number,
                                     last_updated = NOW()
                                 WHERE supply_id = :supply_id";
                    $stmt_supply = $conn->prepare($sql_supply);
                    $stmt_supply->bindValue(':name', $name);
                    $stmt_supply->bindValue(':description', $description);
                    $stmt_supply->bindValue(':unit', $unit);
                    $stmt_supply->bindValue(':low_stock_threshold', $low_stock_threshold, PDO::PARAM_INT);
                    $stmt_supply->bindValue(':quantity', $quantity, PDO::PARAM_INT);
                    $stmt_supply->bindValue(':expiration_date', $expiration_date, $expiration_date ? PDO::PARAM_STR : PDO::PARAM_NULL);
                    $stmt_supply->bindValue(':price', $price);
                    $stmt_supply->bindValue(':lot_number', $lot_number);
                    $stmt_supply->bindValue(':supply_id', $supply_id, PDO::PARAM_INT);
                    $stmt_supply->execute();
                    $message = "Supply record (ID: **{$supply_id}**) updated successfully.";
                    
                } else {
                    
                    // =========================================================================
                    // FIX START: Check for existing batch before insertion to prevent 1062 error
                    // =========================================================================
                    
                    // 1. Check if a batch already exists with the same Name and Expiration Date (matching the unique key).
                    $sql_check = "SELECT supply_id, quantity 
                                  FROM dental_supplies 
                                  WHERE name = :name AND expiration_date = :expiration_date";
                    $stmt_check = $conn->prepare($sql_check);
                    $stmt_check->bindValue(':name', $name);
                    $stmt_check->bindValue(':expiration_date', $expiration_date, $expiration_date ? PDO::PARAM_STR : PDO::PARAM_NULL);
                    $stmt_check->execute();
                    $existing_record = $stmt_check->fetch(PDO::FETCH_ASSOC);

                    if ($existing_record) {
                        // 2. Existing Record Found: Merge the new quantity into the old record to avoid duplication.
                        $existing_supply_id = $existing_record['supply_id'];
                        $new_quantity = $existing_record['quantity'] + $quantity;
                        
                        $sql_merge = "UPDATE dental_supplies 
                                      SET quantity = :quantity,
                                          price = :price, 
                                          low_stock_threshold = :low_stock_threshold,
                                          description = :description,
                                          unit = :unit,
                                          last_updated = NOW() 
                                      WHERE supply_id = :supply_id";
                        
                        $stmt_merge = $conn->prepare($sql_merge);
                        $stmt_merge->bindValue(':quantity', $new_quantity, PDO::PARAM_INT);
                        $stmt_merge->bindValue(':price', $price);
                        $stmt_merge->bindValue(':low_stock_threshold', $low_stock_threshold, PDO::PARAM_INT);
                        $stmt_merge->bindValue(':description', $description);
                        $stmt_merge->bindValue(':unit', $unit);
                        $stmt_merge->bindValue(':supply_id', $existing_supply_id, PDO::PARAM_INT);
                        $stmt_merge->execute();
                        
                        $message = "Existing batch (ID: **{$existing_supply_id}**) of **{$name}** (Exp: {$expiration_date}) was found. Quantity updated/merged to **{$new_quantity}**.";
                        $supply_id = $existing_supply_id; // Set supply_id for success message/consistency
                        
                    } else {
                        // 3. Record Not Found: Proceed with Insertion.
                        
                        // Generate lot_number if not provided by user
                        if (empty($lot_number)) {
                            // Generate a simple Lot Number based on current time/randomness
                            $lot_number = 'LOT-' . date('Ymd') . '-' . substr(md5(microtime()), 0, 6);
                        }

                        // --- STEP 1: Insert the new record ---
                        $sql_supply = "INSERT INTO dental_supplies 
                                     (name, description, unit, low_stock_threshold, quantity, expiration_date, price, lot_number, last_updated)
                                     VALUES (:name, :description, :unit, :low_stock_threshold, :quantity, :expiration_date, :price, :lot_number, NOW())";
                        
                        $stmt_supply = $conn->prepare($sql_supply);
                        
                        $stmt_supply->bindValue(':name', $name);
                        $stmt_supply->bindValue(':description', $description);
                        $stmt_supply->bindValue(':unit', $unit);
                        $stmt_supply->bindValue(':low_stock_threshold', $low_stock_threshold, PDO::PARAM_INT);
                        $stmt_supply->bindValue(':quantity', $quantity, PDO::PARAM_INT);
                        $stmt_supply->bindValue(':expiration_date', $expiration_date, $expiration_date ? PDO::PARAM_STR : PDO::PARAM_NULL);
                        $stmt_supply->bindValue(':price', $price);
                        $stmt_supply->bindValue(':lot_number', $lot_number); 
                        
                        $stmt_supply->execute();
                        
                        // Get the newly generated primary key (supply_id)
                        $supply_id = $conn->lastInsertId();

                        // --- STEP 2: Generate and update the batch_id (Optional/Legacy logic kept) ---
                        if ($supply_id > 0 && !empty($expiration_date)) {
                            
                            $date_part = date('Y-m-d', strtotime($expiration_date));
                            $generated_batch_id = $date_part . '-' . $supply_id;
                            
                            $sql_update_batch = "UPDATE dental_supplies SET batch_id = :batch_id WHERE supply_id = :supply_id";
                            $stmt_update = $conn->prepare($sql_update_batch);
                            $stmt_update->bindValue(':batch_id', $generated_batch_id);
                            $stmt_update->bindValue(':supply_id', $supply_id, PDO::PARAM_INT);
                            $stmt_update->execute();
                        }
                        
                        $message = "New supply record **{$name}** added (ID: **{$supply_id}**). Lot Number: **{$lot_number}**";
                    }
                    // =========================================================================
                    // FIX END
                    // =========================================================================
                }

                $conn->commit();
            } catch (PDOException $e) {
                $conn->rollBack();
                // Return a more user-friendly error unless it's the duplicate entry error
                if ($e->getCode() === '23000' && strpos($e->getMessage(), 'Duplicate entry') !== false) {
                    $error = "Database Error: Cannot add duplicate batch. A record for **{$name}** with expiration date **{$expiration_date}** already exists. The application should have merged the quantities. Please try again or check the database record manually.";
                } else {
                    $error = "Database Error: " . $e->getMessage();
                }
            }
        }
    } elseif ($action === 'delete_item') {
        // Deletes all records associated with this item name
        $name_to_delete = $_POST['name'] ?? '';
        if ($name_to_delete !== '') {
            try {
                $sql = "DELETE FROM dental_supplies WHERE name = :name";
                $stmt = $conn->prepare($sql);
                $stmt->bindValue(':name', $name_to_delete);
                $stmt->execute();
                $message = "All records for supply item **{$name_to_delete}** deleted successfully.";
            } catch (PDOException $e) {
                $error = "Failed to delete item group: " . $e->getMessage();
            }
        } else {
            $error = "Invalid item name for deletion.";
        }
    } elseif ($action === 'delete_batch') {
        // Deletes a specific supply record (batch)
        $supply_id = intval($_POST['supply_id'] ?? 0);
        if ($supply_id > 0) {
            $sql = "DELETE FROM dental_supplies WHERE supply_id = :supply_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(':supply_id', $supply_id, PDO::PARAM_INT);
            if ($stmt->execute()) {
                $message = "Supply Record (Batch) ID: **{$supply_id}** deleted successfully.";
            } else {
                $error = "Failed to delete supply record.";
            }
        } else {
            $error = "Invalid supply ID for deletion.";
        }
    }
}

// Helper functions for status
function isLowStock($quantity, $threshold) {
    return $quantity <= $threshold;
}
function isExpired($expiration_date) {
    if (!$expiration_date) return false;
    return strtotime($expiration_date) < time(); 
}

// --- Fetch all normalized supplies for display (Single Table) ---
$sql = "SELECT 
            supply_id, name, description, unit, low_stock_threshold, quantity, expiration_date, price, batch_id, lot_number 
        FROM 
            dental_supplies
        ORDER BY name ASC, expiration_date ASC";

$supplies_raw = $conn->query($sql)->fetchAll(PDO::FETCH_ASSOC); 

// Group supplies by Item Name and calculate totals
$supplies_grouped = [];

foreach ($supplies_raw as $row) {
    $item_name = $row['name'];
    
    // 1. Initialize item group if it doesn't exist
    if (!isset($supplies_grouped[$item_name])) {
        $supplies_grouped[$item_name] = [
            'item_id' => $row['supply_id'], 
            'name' => $item_name,
            'description' => $row['description'],
            'unit' => $row['unit'],
            'low_stock_threshold' => $row['low_stock_threshold'],
            'needs_batch' => 1, 
            'total_quantity' => 0,
            'status_low' => false, 
            'status_expired' => false, 
            'batches' => []
        ];
    }

    // 2. Aggregate data and check batch status
    $supplies_grouped[$item_name]['total_quantity'] += $row['quantity'];
        
    $is_exp_batch = isExpired($row['expiration_date']);

    if ($is_exp_batch) {
        $supplies_grouped[$item_name]['status_expired'] = true;
    }

    // Store batch data (which is the individual row)
    $supplies_grouped[$item_name]['batches'][] = [
        'supply_id' => $row['supply_id'], 
        'batch_id_external' => $row['batch_id'], 
        'lot_number' => $row['lot_number'], // Store Lot Number
        'quantity' => $row['quantity'],
        'expiration_date' => $row['expiration_date'],
        'price' => $row['price'],
        'is_expired' => $is_exp_batch,
    ];
}

// 3. Final check for Low Stock (based on TOTAL quantity)
foreach ($supplies_grouped as $item_name => $item) {
    if (isLowStock($item['total_quantity'], $item['low_stock_threshold'])) {
        $supplies_grouped[$item_name]['status_low'] = true;
    }
}


// Totals for widgets
$total_supplies_items = count($supplies_grouped);
$total_low_stock_items = count(array_filter($supplies_grouped, fn($s) => $s['status_low']));
$total_expired_items = count(array_filter($supplies_grouped, fn($s) => $s['status_expired']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Dental Inventory Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<style>
/* --- STYLES (MODAL ADDED) --- */
*, *::before, *::after { box-sizing: border-box; }
body, html { margin: 0; padding: 0; height: 100%; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #e6f0ff; color: #003366; scroll-behavior: smooth; }
a { text-decoration: none; color: inherit; }
button { cursor: pointer; }
body { display: flex; min-height: 100vh; overflow-x: hidden; }
/* Sidebar */
.sidebar { width: 250px; background: linear-gradient(180deg, #3399ff 0%, #0066cc 100%); color: #fff; display: flex; flex-direction: column; padding: 30px 20px; box-shadow: 3px 0 15px rgba(0,0,0,0.1); }
.sidebar h2 { text-align: center; margin-bottom: 30px; font-size: 24px; font-weight: 700; user-select: none; text-shadow: 1px 1px 2px rgba(0,0,0,0.3); }
.sidebar a { padding: 15px 20px; margin-bottom: 12px; border-radius: 12px; font-weight: 600; display: flex; align-items: center; gap: 12px; color: #cce0ff; transition: background-color 0.3s ease, color 0.3s ease; border-left: 5px solid transparent; }
.sidebar a:hover, .sidebar a.active { background-color: rgba(255,255,255,0.2); color: #fff; border-left-color: #ffcc00; font-weight: 700; }
.sidebar a i { min-width: 20px; font-size: 1.1rem; }
/* Main content */
main.main-content { flex: 1; background: #fff; padding: 40px 50px; overflow-y: auto; display: flex; flex-direction: column; gap: 30px; }
header h1 { font-size: 2.4rem; font-weight: 900; color: #004080; display: flex; align-items: center; gap: 15px; text-shadow: 1px 1px 4px #a3c2ff; margin: 0; }
header h1 i { font-size: 2.8rem; color: #0066cc; }

/* Modal Styles */
.modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.6); /* Dark overlay */
    display: none; /* Hidden by default */
    justify-content: center;
    align-items: center;
    z-index: 1000;
    overflow-y: auto;
    padding: 20px;
}
.modal-content {
    background: #fff;
    padding: 30px;
    border-radius: 20px;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
    position: relative;
    max-width: 650px;
    width: 100%;
    animation: fadeIn 0.3s ease-out;
}
.close-btn {
    position: absolute;
    top: 15px;
    right: 25px;
    font-size: 2rem;
    font-weight: bold;
    color: #aaa;
    transition: color 0.3s;
    border: none;
    background: none;
}
.close-btn:hover, .close-btn:focus {
    color: #0066cc;
    text-decoration: none;
    cursor: pointer;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-50px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Widgets */
.widgets { display: grid; grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap: 28px; }
.widget { background: #f0f7ff; padding: 30px 25px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); display: flex; flex-direction: column; gap: 8px; }
.widget i { font-size: 2.6rem; color: #3399ff; }
.widget span { font-weight: 800; font-size: 1.8rem; color: #004080; }
.widget small { font-weight: 600; color: #004080; opacity: 0.75; }
/* Table */
section table { width: 100%; border-collapse: collapse; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.05); background-color: #f8fbff; font-size: 1rem; color: #003366; }
table thead { background: #3399ff; color: #fff; font-weight: 700; }
table thead tr th { padding: 15px 18px; text-align: left; }
/* Changed to use 'data-item-name' for the unique identifier since item_id is no longer unique */
table tbody tr.main-item { cursor: pointer; border-bottom: 2px solid #3399ff; font-weight: 600; }
table tbody tr { transition: background-color 0.25s ease; }
table tbody tr.main-item:hover { background-color: #cde1ff; }
/* Status colors for MAIN ITEM ROW */
table tbody tr.low-stock { background-color: #fff3cd; }
table tbody tr.expired { background-color: #f8d7da; }
table tbody tr.low-stock.expired { background-color: #f5c6cb; }

table tbody tr td { padding: 12px 18px; vertical-align: middle; }
table tbody tr td.actions { text-align: center; white-space: nowrap; }
table tbody tr td.actions button { border: none; background: none; font-size: 1.2rem; color: #dc3545; padding: 5px 8px; border-radius: 6px; transition: background-color 0.25s ease, color 0.25s ease; }
table tbody tr td.actions button.edit { color: #0066cc; }
table tbody tr td.actions button.edit:hover { background-color: #0066cc; color: #fff; }
table tbody tr td.actions button:hover { background-color: #dc3545; color: #fff; }

/* New Styles for Batch Details */
.batch-row { display: none; background: #e6f0ff; border-top: 1px dashed #3399ff; }
.batch-row td { padding: 8px 18px 8px 40px; font-size: 0.95rem; }
.batch-table { width: 90%; margin: 10px auto; background: #cde1ff; box-shadow: none; border: 1px solid #3399ff; border-radius: 10px; overflow: hidden;}
.batch-table th { background: #0066cc; color: white; padding: 8px; text-align: left; }
.batch-table td { padding: 6px 10px; }
.batch-row .batch-expired { background-color: #f8d7da; }
.batch-toggle { margin-left: 10px; font-size: 0.8rem; font-weight: 700; padding: 4px 8px; border-radius: 6px; background: #0066cc; color: white; border: none; }
.batch-toggle:hover { background: #3399ff; }
.batch-toggle.open::after { content: " ▲"; }
.batch-toggle:not(.open)::after { content: " ▼"; }

/* Add Supply Form inside Modal */
form#add-supply { background: #fff; padding: 0; border-radius: 0; box-shadow: none; max-width: none; margin: 0; }
form#add-supply h2 { margin: 0 0 20px 0; color: #004080; font-weight: 900; font-size: 1.9rem; text-align: center; text-shadow: 1px 1px 3px #a3c2ff; }
form#add-supply .form-row { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 18px; }
form#add-supply label { flex: 1 0 120px; font-weight: 600; color: #003366; display: flex; align-items: center; gap: 6px; }
form#add-supply input, form#add-supply select, form#add-supply textarea { flex: 2 1 250px; padding: 8px 12px; font-size: 1rem; border-radius: 12px; border: 1.5px solid #3399ff; font-weight: 600; }
form#add-supply button[type="submit"] { display: block; margin: 20px auto 0; padding: 14px 40px; font-weight: 700; font-size: 1.2rem; border-radius: 20px; border: none; background: #3399ff; color: white; box-shadow: 0 6px 20px rgba(51,153,255,0.6); transition: background-color 0.3s ease; }
form#add-supply button[type="submit"]:hover { background: #0066cc; }
/* Flash Messages */
.flash-message { max-width: 600px; margin: 15px auto; padding: 16px 20px; border-radius: 20px; font-weight: 700; font-size: 1.1rem; text-align: center; }
.flash-success { background-color: #d4edda; color: #155724; }
.flash-error { background-color: #f8d7da; color: #721c24; }

/* Add New Item Button */
#add-new-supply-btn {
    align-self: flex-start; /* Position it cleanly */
    padding: 12px 25px;
    font-size: 1.1rem;
    font-weight: 700;
    border-radius: 20px;
    border: none;
    background: #00cc66; /* Green button for Add */
    color: white;
    box-shadow: 0 5px 15px rgba(0, 204, 102, 0.4);
    transition: background-color 0.3s ease;
}
#add-new-supply-btn:hover {
    background: #00b359;
}
</style>
</head>
<body>
<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="secretary_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
 <a href="find_patient.php" ><i class="fas fa-search"></i> Find Patient</a>
    <a href="view_patients.php"><i class="fas fa-users"></i> View Patients</a>
    <a href="payments.php"><i class="fas fa-cash-register"></i> Payments</a>
    <a href="online_bookings.php" ><i class="fas fa-laptop-code"></i> Online Bookings</a>
    <a href="services_list.php"><i class="fas fa-list"></i> Services</a>
    <a href="appointments.php"><i class="fas fa-calendar-check"></i> Manage Consultation</a>
    <a href="create_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
    <a href="inventory.php" class="active"><i class="fas fa-boxes"></i> Inventory</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">
<header><h1><i class="fas fa-boxes-stacked"></i> Dental Supplies Inventory</h1></header>

<?php if ($message): ?>
    <div class="flash-message flash-success"><?= htmlspecialchars($message) ?></div>
<?php elseif ($error): ?>
    <div class="flash-message flash-error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="widgets">
    <div class="widget"><i class="fas fa-cubes"></i><span><?= $total_supplies_items ?></span><small>Total Unique Items</small></div>
    <div class="widget"><i class="fas fa-exclamation-triangle"></i><span><?= $total_low_stock_items ?></span><small>Items Low Stock</small></div>
    <div class="widget"><i class="fas fa-calendar-xmark"></i><span><?= $total_expired_items ?></span><small>Items Expired</small></div>
</div>

<button type="button" id="add-new-supply-btn" onclick="openModalForNewItem()">
    <i class="fas fa-plus-circle"></i> Add New Supply / Batch
</button>

<section>
<table>
<thead>
    <tr>
        <th>Item Name</th>
        <th>Total Quantity</th>
        <th>Unit</th>
        <th>Threshold</th>
        <th>Description / Status</th>
        <th>Actions</th>
    </tr>
</thead>
<tbody>
<?php if (empty($supplies_grouped)): ?>
<tr><td colspan="6" style="text-align:center;">No supplies found.</td></tr>
<?php else: ?>
<?php foreach ($supplies_grouped as $item): 
    $itemNameKey = htmlspecialchars($item['name']); 
    $rowClass = ($item['status_low'] ? 'low-stock ' : '') . ($item['status_expired'] ? 'expired' : '');
    $isBatched = $item['needs_batch']; 
    $statusText = htmlspecialchars($item['description']) ?: 'N/A';

    if ($item['status_expired']) $statusText = '<i class="fas fa-circle-exclamation" style="color:#dc3545;"></i> **Expired Batch Exists**';
    if ($item['status_low']) $statusText .= '<i class="fas fa-triangle-exclamation" style="color:#ffc107; margin-left: 10px;"></i> **LOW STOCK**';
    
?>
<tr class="main-item <?= $rowClass ?>" data-item-name="<?= $itemNameKey ?>">
    <td><?= $itemNameKey ?></td>
    <td><?= htmlspecialchars($item['total_quantity']) ?></td>
    <td><?= htmlspecialchars($item['unit']) ?></td>
    <td><?= htmlspecialchars($item['low_stock_threshold']) ?></td>
    <td>
        <?= $statusText ?>
        <?php if ($isBatched && count($item['batches']) > 0): ?>
            <button type="button" class="batch-toggle" id="toggle-btn-<?= $itemNameKey ?>" onclick="toggleBatches('<?= $itemNameKey ?>')">View Batches</button>
        <?php else: ?> 
            <span style="opacity:0.6;">(Item has no stock records)</span>
        <?php endif; ?>
    </td>
    <td class="actions">
        <button type="button" class="edit" onclick="loadItemForNewBatch('<?= $itemNameKey ?>')" title="Add New Batch / Edit Item"><i class="fas fa-plus-circle"></i></button>

        <form method="post" onsubmit="return confirm('Delete item \'<?= $itemNameKey ?>\' and ALL its records?');" style="display:inline;">
            <input type="hidden" name="action" value="delete_item">
            <input type="hidden" name="name" value="<?= $itemNameKey ?>">
            <button type="submit" title="Delete Item Group"><i class="fas fa-trash"></i></button>
        </form>
    </td>
</tr>

<?php if ($isBatched && !empty($item['batches'])): ?>
<tr class="batch-row" id="batches-<?= $itemNameKey ?>">
    <td colspan="6">
        <table class="batch-table">
            <thead>
                <tr>
                    <th>Record ID (supply_id)</th>
                    <th>Lot Number</th> 
                    <th>Quantity</th>
                    <th>Expiration Date</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($item['batches'] as $batch): 
                    $batchClass = ($batch['is_expired'] ? 'batch-expired' : '');
                ?>
                <tr class="<?= $batchClass ?>">
                    <td><?= htmlspecialchars($batch['supply_id']) ?></td>
                    <td><?= htmlspecialchars($batch['lot_number']) ?: 'N/A' ?></td> 
                    <td><?= htmlspecialchars($batch['quantity']) ?></td>
                    <td><?= $batch['expiration_date'] ? date('M d, Y', strtotime($batch['expiration_date'])) : 'N/A' ?></td>
                    <td><?= htmlspecialchars(number_format($batch['price'], 2)) ?></td>
                    <td>
                        <?= $batch['is_expired'] ? '<span style="color:#dc3545; font-weight:700;">EXPIRED</span>' : 'OK' ?>
                    </td>
                    <td class="actions">
                        <button type="button" class="edit" onclick="loadBatch('<?= $itemNameKey ?>', <?= $batch['supply_id'] ?>)" title="Edit Batch Record"><i class="fas fa-edit"></i></button>
                        <form method="post" action="inventory.php" onsubmit="return confirm('Delete this specific batch record (ID: <?= $batch['supply_id'] ?>)?');" style="display:inline;">
                            <input type="hidden" name="action" value="delete_batch">
                            <input type="hidden" name="supply_id" value="<?= $batch['supply_id'] ?>">
                            <button type="submit" title="Delete Batch Record"><i class="fas fa-minus-circle"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </td>
</tr>
<?php endif; ?>

<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
</section>


<div id="supplyModal" class="modal">
    <div class="modal-content">
        <button type="button" class="close-btn" onclick="closeModal()">&times;</button>
        <form id="add-supply" method="post" action="inventory.php" novalidate>
            <h2>Add New Record / Update Existing</h2>
            <input type="hidden" name="action" value="add_or_update">
            <input type="hidden" name="supply_id" id="supply_id" value="0"> 
            <input type="hidden" name="batch_id" id="batch_id" value="0"> 
            
            <div class="form-row">
                <label for="item_select">Select Existing Item Name</label>
                <select id="item_select" onchange="loadItemDetails(this.value)">
                    <option value="">-- Add New Item Name --</option>
                    <?php foreach ($supplies_grouped as $item): ?>
                        <option value="<?= htmlspecialchars($item['name']) ?>"><?= htmlspecialchars($item['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-row">
                <label for="name_input">Item Name <sup style="color:red">*</sup></label>
                <input type="text" name="name_input" id="name_input" required placeholder="e.g., Composite Resin">
            </div>

            <div class="form-row">
                <label for="description">Description</label>
                <textarea name="description" id="description" placeholder="Manufacturer, model, shade..."></textarea>
            </div>
            
            <div class="form-row">
                <label for="unit">Unit</label>
                <select name="unit" id="unit" required>
                    <option value="pcs">pcs</option>
                    <option value="boxes">boxes</option>
                    <option value="packs">packs</option>
                    <option value="ml">ml</option>
                    <option value="grams">grams</option>
                </select>
            </div>

            <div class="form-row">
                <label for="low_stock_threshold">Low Stock Threshold (for item group)</label>
                <input type="number" name="low_stock_threshold" id="low_stock_threshold" min="0" value="5">
            </div>
            
            <div class="form-row">
                <label for="price">Unit Price</label>
                <input type="number" name="price" id="price" min="0" step="0.01" value="0.00">
            </div>

            <input type="hidden" name="needs_batch" id="needs_batch" value="1"> 


            <hr>
            <h3>Stock Details <span id="batch-status-label" style="font-weight:400; font-size:0.9em;">(New Record)</span></h3>
            
            <div class="form-row">
                <div name="lot_number" id="lot_number" ></div>
            </div>
            <div class="form-row">
                <label for="quantity">Quantity <sup style="color:red">*</sup></label>
                <input type="number" name="quantity" id="quantity" min="0" value="0" required>
            </div>
            <div class="form-row">
                <label for="expiration_date">Expiration Date</label>
                <input type="date" name="expiration_date" id="expiration_date">
            </div>

            <button type="submit">Save Record</button>
        </form>
    </div>
</div>

</main>

<script>
// Array of item objects, flattened for easy search
const suppliesGrouped = <?= json_encode(array_values($supplies_grouped)) ?>;
const modal = document.getElementById('supplyModal');

// --- MODAL FUNCTIONS ---
function openModal() {
    modal.style.display = 'flex';
}

function closeModal() {
    modal.style.display = 'none';
    resetForm(); // Always reset form when closing the modal
}

function openModalForNewItem() {
    resetForm();
    openModal();
}
// --- END MODAL FUNCTIONS ---

function resetForm() {
    document.getElementById('supply_id').value = 0; 
    document.getElementById('batch_id').value = 0; 
    document.getElementById('name_input').value = '';
    document.getElementById('description').value = '';
    document.getElementById('unit').value = 'pcs';
    document.getElementById('low_stock_threshold').value = 5;
    document.getElementById('price').value = 0;
    document.getElementById('lot_number').value = ''; // Reset Lot Number
    document.getElementById('quantity').value = 0;
    document.getElementById('expiration_date').value = '';
    document.getElementById('item_select').value = ''; 
    document.getElementById('name_input').readOnly = false;
    document.getElementById('batch-status-label').textContent = '(New Record)';
}

// Toggle Batches now uses the Item Name as the ID
function toggleBatches(itemName) {
    // FIX APPLIED: Use the raw item name passed from PHP, as it correctly matches the HTML ID, 
    // instead of trying to escape it with hyphen, which caused a mismatch.
    const safeItemName = itemName; 
    
    // Original: const safeItemName = itemName.replace(/[^a-zA-Z0-9]/g, '-');

    const batchRow = document.getElementById('batches-' + safeItemName);
    const toggleBtn = document.getElementById('toggle-btn-' + safeItemName);
    
    if (!batchRow || !toggleBtn) return;

    if (batchRow.style.display === 'none' || batchRow.style.display === '') {
        batchRow.style.display = 'table-row';
        toggleBtn.classList.add('open');
        toggleBtn.textContent = 'Hide Batches';
    } else {
        batchRow.style.display = 'none';
        toggleBtn.classList.remove('open');
        toggleBtn.textContent = 'View Batches';
    }
}

// 1. Load item details (for a new record) when selecting from dropdown or clicking "+"
function loadItemDetails(itemName) {
    resetForm();

    if (itemName === '') return;
    document.getElementById('item_select').value = itemName;

    const item = suppliesGrouped.find(s => s.name === itemName);

    if (item) {
        document.getElementById('name_input').value = item.name;
        document.getElementById('description').value = item.description || '';
        document.getElementById('unit').value = item.unit;
        document.getElementById('low_stock_threshold').value = item.low_stock_threshold;
        document.getElementById('name_input').readOnly = true;

        document.getElementById('supply_id').value = 0;
        document.getElementById('quantity').value = 0;
        document.getElementById('expiration_date').value = '';
        document.getElementById('lot_number').value = ''; 
        document.getElementById('price').value = item.batches[0]?.price || 0; 
        document.getElementById('batch-status-label').textContent = '(New Record for Existing Item)';
        
        openModal();
    }
}

// 2. Used when clicking the "Add New Batch / Edit Item" button on the table row
function loadItemForNewBatch(itemName) {
    loadItemDetails(itemName);
}

// 3. Used when clicking the "Edit" button on a specific batch row
function loadBatch(itemName, supplyId) {
    const item = suppliesGrouped.find(s => s.name === itemName);

    if (item) {
        // Load the general item details first
        loadItemDetails(itemName); 
        document.getElementById('name_input').readOnly = false; // Allow editing name for this specific record

        // Find and apply specific batch record details (using supplyId)
        const batchRecord = item.batches.find(b => b.supply_id == supplyId);
        
        if (batchRecord) {
            document.getElementById('supply_id').value = batchRecord.supply_id;
            document.getElementById('quantity').value = batchRecord.quantity;
            document.getElementById('price').value = batchRecord.price;
            document.getElementById('lot_number').value = batchRecord.lot_number || ''; // Load Lot Number
            document.getElementById('expiration_date').value = batchRecord.expiration_date ? batchRecord.expiration_date.substring(0, 10) : ''; 
            document.getElementById('batch-status-label').textContent = `(Updating Record ID: ${supplyId})`;
        }
    }
    openModal();
}

// Initial form setup 
document.addEventListener('DOMContentLoaded', () => {
    resetForm();
    
    // Explicit client-side validation for Item Name
    const form = document.getElementById('add-supply');
    form.addEventListener('submit', function(e) {
        const nameInput = document.getElementById('name_input');
        if (nameInput.value.trim() === '') {
            e.preventDefault();
            alert('Item Name is required. Please enter a name for the new item.');
            nameInput.focus();
            return false;
        }
    });
});

// Close modal when clicking outside of it
window.onclick = function(event) {
    if (event.target == modal) {
        closeModal();
    }
}
</script>
</body>
</html>