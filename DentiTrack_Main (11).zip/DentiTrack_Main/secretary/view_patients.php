 <?php
    session_start();
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
        header('Location: ../public/login.php');
        exit();
    }

    // Ensure db_pdo.php and db_conn.php are included for database connection
    include '../config/db_pdo.php';
    include '../config/db_conn.php';

    // --- AUTO-ARCHIVE PATIENTS (for testing INTERVAL 1 DAY) ---
    try {
        $sql_auto_archive = "UPDATE patient
                            SET is_archived = 1
                            WHERE is_archived = 0
                            AND updated_at <= DATE_SUB(NOW(), INTERVAL 6 MONTH)";
        $conn->exec($sql_auto_archive);
    } catch (PDOException $e) {}

    // --- Get search term and filter ---
    $search_term = trim($_GET['search'] ?? '');
    $filter_status = $_GET['status'] ?? 'all'; // all, active, archived

    function calculateAge($dob) {
        if (!$dob) return '';
        try {
            $dobDate = new DateTime($dob);
            $now = new DateTime();
            return $now->diff($dobDate)->y;
        } catch (Exception $e) {
            return '';
        }
    }

    // --- Fetch Patient Details for Modal (NEW AJAX ENDPOINT) ---
    if (isset($_GET['fetch_patient_details']) && is_numeric($_GET['fetch_patient_details'])) {
        $patient_id = (int)$_GET['fetch_patient_details'];

        $sql_details = "SELECT * FROM patient WHERE patient_id = :id";
        $stmt_details = $conn->prepare($sql_details);
        $stmt_details->bindParam(':id', $patient_id, PDO::PARAM_INT);
        $stmt_details->execute();
        $patient_details = $stmt_details->fetch(PDO::FETCH_ASSOC);

        header('Content-Type: application/json');
        if ($patient_details) {
            // Add Age for display
            $patient_details['age'] = calculateAge($patient_details['dob']);

            // Format dates if needed (example)
            $patient_details['created_at_formatted'] = date('F j, Y', strtotime($patient_details['created_at']));

            echo json_encode(['success' => true, 'data' => $patient_details]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Patient not found.']);
        }
        exit;
    }
    // --- END NEW AJAX ENDPOINT ---


    // --- Fetch patients for table display ---
    $patients = [];
    $search_like = "%$search_term%";

    $sql = "SELECT * FROM patient
            WHERE (fullname LIKE :search1 OR contact_number LIKE :search2)";

    if ($filter_status === 'active') {
        $sql .= " AND is_archived = 0";
    } elseif ($filter_status === 'archived') {
        $sql .= " AND is_archived = 1";
    }

    $sql .= " ORDER BY patient_id DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':search1', $search_like, PDO::PARAM_STR);
    $stmt->bindParam(':search2', $search_like, PDO::PARAM_STR);
    $stmt->execute();
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // --- AJAX request for table data ---
    if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
        if (count($patients) === 0) {
            echo '<tr><td colspan="6" style="text-align:center;">No patients found.</td></tr>';
            exit;
        }
        $counter = 1;
        foreach ($patients as $patient) {
            echo '<tr>';
            echo '<td>'.$counter.'</td>';
            echo '<td>'.htmlspecialchars($patient['fullname']).'</td>';
            echo '<td>'.htmlspecialchars(calculateAge($patient['dob'])).'</td>';
            echo '<td>'.htmlspecialchars($patient['contact_number']).'</td>';
            echo '<td>'.($patient['is_archived'] ? 'Archived' : 'Active').'</td>';
            echo '<td>';
            // --- UPDATED VIEW BUTTON ---
            echo '<button data-id="'. (int)$patient['patient_id'] .'" class="action-btn view-btn open-modal-btn"><i class="fas fa-eye"></i> View</button>';
            // --- END UPDATED VIEW BUTTON ---

            if (!$patient['is_archived']) {
                echo '<a href="archive_patients.php?id='. (int)$patient['patient_id'] .'&mode=archive" class="action-btn archive-btn" onclick="return confirm(\'Are you sure you want to archive this patient?\');"><i class="fas fa-archive"></i> Archive</a>';
            } else {
                echo '<a href="archive_patients.php?id='. (int)$patient['patient_id'] .'&mode=restore" class="action-btn archive-btn" style="border-color:#00a000;color:#00a000;" onclick="return confirm(\'Are you sure you want to restore this patient?\');"><i class="fas fa-undo"></i> Restore</a>';
            }
            echo '</td>';
            echo '</tr>';
            $counter++;
        }
        exit;
    }
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>View Patients - DentiTrack</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" />
    <style>
    /* Existing CSS */
    html { scroll-behavior: smooth; }
    body { margin: 0; font-family: 'Segoe UI', sans-serif; background: #e6f0ff; color: #003366; height: 100vh; display: flex; }
    .sidebar { width: 220px; background: linear-gradient(to bottom, #3399ff, #0066cc); padding: 20px; color: white; box-shadow: 2px 0 10px rgba(0,0,0,0.15); display: flex; flex-direction: column; }
    .sidebar h2 { text-align: center; margin-bottom: 30px; font-size: 24px; font-weight: 700; user-select: none; text-shadow: 1px 1px 2px rgba(0,0,0,0.3); }
    .sidebar a { display: block; padding: 12px 20px; margin: 10px 0; color: #cce0ff; text-decoration: none; border-left: 4px solid transparent; font-weight: 600; transition: background-color 0.3s ease, border-left-color 0.3s ease; }
    .sidebar a:hover, .sidebar a.active { background-color: rgba(255,255,255,0.15); color: white; border-left: 4px solid #ffcc00; }
    main.main-content { flex: 1; padding: 40px; background: white; overflow-y: auto; }
    header { margin-bottom: 20px; }
    header h1 { font-size: 2rem; color: #004080; text-shadow: 1px 1px 2px #a3c2ff; display: flex; align-items: center; gap: 0.5rem; }
    .search-box { margin-bottom: 10px; display: flex; gap: 10px; align-items: center; }
    .search-box input[type="text"] { width: 250px; padding: 10px 12px; border-radius: 12px; border: 1.5px solid #b3c6ff; font-size: 16px; outline-offset: 2px; transition: border-color 0.3s ease; }
    .search-box select { padding: 10px 12px; border-radius: 12px; border: 1.5px solid #b3c6ff; font-size: 16px; outline-offset: 2px; }
    .search-box input[type="text"]:focus, .search-box select:focus { border-color: #3399ff; outline: none; box-shadow: 0 0 8px #3399ff88; }
    table { width: 100%; border-collapse: collapse; border-radius: 15px; overflow: hidden; box-shadow: 0 6px 16px rgba(0,0,0,0.1); background: #f9fbff; }
    th, td { padding: 14px 18px; text-align: left; border-bottom: 1px solid #e2e8f0; font-weight: 600; }
    th { background: linear-gradient(to right, #3399ff, #0066cc); color: white; user-select: none; letter-spacing: 0.05em; }
    tr:hover { background-color: #d0e1ff; }
    .action-btn { display: inline-block; margin-right: 5px; margin-bottom: 5px; color: #0066cc; font-weight: 700; text-decoration: none; padding: 6px 14px; border: 1.5px solid #0066cc; border-radius: 12px; cursor: pointer; transition: background-color 0.3s ease, color 0.3s ease; }
    .action-btn:hover { background-color: #0066cc; color: white; }
    .view-btn { border-color: #00a000; color: #00a000; }
    .view-btn:hover { background-color: #00a000; color: white; }
    .archive-btn { border-color: #cc6600; color: #cc6600; }
    .archive-btn:hover { background-color: #cc6600; color: white; }

    /* --- NEW MODAL STYLES --- */
    .modal {
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 1000; /* Sit on top */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */
        background-color: rgba(0,0,0,0.5); /* Black w/ opacity */
        padding-top: 60px;
    }
    .modal-content {
        background-color: #fefefe;
        margin: 5% auto; /* 5% from the top and centered */
        padding: 30px;
        border: 1px solid #888;
        width: 80%; /* Could be more or less, depending on screen size */
        max-width: 600px;
        border-radius: 15px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        animation: fadeIn 0.3s;
    }
    @keyframes fadeIn {
        from {opacity: 0;}
        to {opacity: 1;}
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        transition: color 0.3s;
    }
    .close:hover,
    .close:focus {
        color: #333;
        text-decoration: none;
        cursor: pointer;
    }
    .modal-content h2 {
        color: #0066cc;
        border-bottom: 2px solid #e0eaff;
        padding-bottom: 10px;
        margin-top: 0;
        font-size: 1.8rem;
    }
    .modal-details p {
        margin: 8px 0;
        font-size: 16px;
        line-height: 1.5;
    }
    .modal-details strong {
        color: #004080;
        display: inline-block;
        width: 120px; /* Align the values */
    }
    /* --- END NEW MODAL STYLES --- */
    </style>
    </head>
    <body>

    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="secretary_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
       <a href="find_patient.php" ><i class="fas fa-search"></i> Find Patient</a>
        <a href="view_patients.php" class="active"><i class="fas fa-users"></i> View Patients</a>
        <a href="Payments.php"><i class="fas fa-cash-register"></i> Payments</a>
        <a href="online_bookings.php"><i class="fas fa-laptop-code"></i> Online Bookings</a>
        <a href="payment_logs.php" ><i class="fas fa-file-invoice-dollar"></i> Payments Log</a>
        <a href="services_list.php"><i class="fas fa-list"></i> Services</a>
        <a href="appointments.php"><i class="fas fa-calendar-check"></i> Manage Consultation</a>
        <a href="create_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>

    <main class="main-content">
        <header>
            <h1><i class="fas fa-users"></i> Patients</h1>
        </header>

        <div class="search-box">
            <input type="text" id="searchInput" placeholder="Search by name or contact" />
            <select id="statusFilter">
                <option value="all" <?= $filter_status==='all' ? 'selected' : '' ?>>All</option>
                <option value="active" <?= $filter_status==='active' ? 'selected' : '' ?>>Active</option>
                <option value="archived" <?= $filter_status==='archived' ? 'selected' : '' ?>>Archived</option>
            </select>
        </div>

        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Contact</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="patientsTable">
                <?php
                $counter = 1;
                foreach ($patients as $patient) {
                    echo '<tr>';
                    echo '<td>'.$counter.'</td>';
                    echo '<td>'.htmlspecialchars($patient['fullname']).'</td>';
                    echo '<td>'.htmlspecialchars(calculateAge($patient['dob'])).'</td>';
                    echo '<td>'.htmlspecialchars($patient['contact_number']).'</td>';
                    echo '<td>'.($patient['is_archived'] ? 'Archived' : 'Active').'</td>';
                    echo '<td>';
                    // --- UPDATED VIEW BUTTON ---
                    echo '<button data-id="'. (int)$patient['patient_id'] .'" class="action-btn view-btn open-modal-btn"><i class="fas fa-eye"></i> View</button>';
                    // --- END UPDATED VIEW BUTTON ---

                    if (!$patient['is_archived']) {
                        echo '<a href="archive_patients.php?id='. (int)$patient['patient_id'] .'&mode=archive" class="action-btn archive-btn" onclick="return confirm(\'Are you sure you want to archive this patient?\');"><i class="fas fa-archive"></i> Archive</a>';
                    } else {
                        echo '<a href="archive_patients.php?id='. (int)$patient['patient_id'] .'&mode=restore" class="action-btn archive-btn" style="border-color:#00a000;color:#00a000;" onclick="return confirm(\'Are you sure you want to restore this patient?\');"><i class="fas fa-undo"></i> Restore</a>';
                    }
                    echo '</td>';
                    echo '</tr>';
                    $counter++;
                }
                ?>
            </tbody>
        </table>
    </main>

    <div id="patientModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2 id="modalTitle">Patient Details</h2>
            <div id="modalDetails" class="modal-details">
                <p><strong>Name:</strong> <span id="modalName"></span></p>
                <p><strong>ID:</strong> <span id="modalId"></span></p>
                <p><strong>Age:</strong> <span id="modalAge"></span></p>
                <p><strong>DOB:</strong> <span id="modalDob"></span></p>
                <p><strong>Contact:</strong> <span id="modalContact"></span></p>
                <p><strong>Gender:</strong> <span id="modalGender"></span></p>
                <p><strong>Address:</strong> <span id="modalAddress"></span></p>
                <p><strong>Status:</strong> <span id="modalStatus"></span></p>
                <p><strong>Registered:</strong> <span id="modalRegistered"></span></p>
                <div id="modalLoading" style="text-align:center; display:none;"><i class="fas fa-spinner fa-spin"></i> Loading...</div>
            </div>
        </div>
    </div>
    <script>
    const searchInput = document.getElementById('searchInput');
    const statusFilter = document.getElementById('statusFilter');
    const tableBody = document.getElementById('patientsTable');

    // --- Existing AJAX for Table Filtering/Search ---
    function fetchPatients() {
        const query = searchInput.value.trim();
        const status = statusFilter.value;

        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'view_patients.php?ajax=1&search=' + encodeURIComponent(query) + '&status=' + encodeURIComponent(status), true);
        xhr.onload = function() {
            if (xhr.status === 200) {
                tableBody.innerHTML = xhr.responseText;
                // IMPORTANT: Re-attach the event listener after the table content is updated
                attachModalListeners();
            }
        };
        xhr.send();
    }

    searchInput.addEventListener('input', fetchPatients);
    statusFilter.addEventListener('change', fetchPatients);
    // --- End Existing AJAX ---


    // --- NEW MODAL JAVASCRIPT ---
    const modal = document.getElementById("patientModal");
    const spanClose = document.getElementsByClassName("close")[0];

    // Function to close the modal
    spanClose.onclick = function() {
        modal.style.display = "none";
    }

    // Close the modal when the user clicks anywhere outside of the modal
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    function showLoading(show) {
        document.getElementById('modalLoading').style.display = show ? 'block' : 'none';
        document.getElementById('modalDetails').style.display = show ? 'none' : 'block';
    }

    function fetchPatientDetails(patientId) {
        showLoading(true); // Show loading indicator

        const xhr = new XMLHttpRequest();
        // Use the new AJAX endpoint defined in PHP
        xhr.open('GET', 'view_patients.php?fetch_patient_details=' + patientId, true);
        xhr.responseType = 'json';

        xhr.onload = function() {
            showLoading(false); // Hide loading indicator

            if (xhr.status === 200 && xhr.response && xhr.response.success) {
                const data = xhr.response.data;
                document.getElementById('modalTitle').textContent = `Patient Details: ${data.fullname}`;
                document.getElementById('modalName').textContent = data.fullname || 'N/A';
                document.getElementById('modalId').textContent = data.patient_id || 'N/A';
                document.getElementById('modalAge').textContent = data.age || 'N/A';
                document.getElementById('modalDob').textContent = data.dob || 'N/A';
                document.getElementById('modalContact').textContent = data.contact_number || 'N/A';
                document.getElementById('modalGender').textContent = data.gender || 'N/A';
                document.getElementById('modalAddress').textContent = data.address || 'N/A';
                document.getElementById('modalStatus').textContent = data.is_archived == 1 ? 'Archived' : 'Active';
                document.getElementById('modalRegistered').textContent = data.created_at_formatted || 'N/A';

                modal.style.display = "block"; // Show the modal
            } else {
                alert('Could not fetch patient details.');
            }
        };

        xhr.onerror = function() {
            showLoading(false);
            alert('An error occurred during the request.');
        };

        xhr.send();
    }

    function attachModalListeners() {
        // Select all buttons with the class 'open-modal-btn'
        const viewButtons = document.querySelectorAll('.open-modal-btn');

        viewButtons.forEach(button => {
            // Remove existing listener to prevent duplicates after AJAX reload
            button.removeEventListener('click', modalOpenHandler);
            // Add a new listener
            button.addEventListener('click', modalOpenHandler);
        });
    }

    function modalOpenHandler(event) {
        const patientId = event.currentTarget.getAttribute('data-id');
        if (patientId) {
            fetchPatientDetails(patientId);
        }
    }

    // Initial call to set up the listeners on the patient list loaded by PHP
    document.addEventListener('DOMContentLoaded', attachModalListeners);
    // --- END NEW MODAL JAVASCRIPT ---
    </script>

    </body>
    </html>