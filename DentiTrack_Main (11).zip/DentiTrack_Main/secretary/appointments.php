<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: ../public/login.php');
    exit();
}

include '../config/db.php';

$secretary_username = $_SESSION['username'];

// Count total patients (correct table name)
$sql_patients_count = "SELECT COUNT(*) as count FROM patient";
$patients_count = $conn->query($sql_patients_count)->fetch_assoc()['count'];


// Count upcoming appointments (all patients)
$sql_upcoming_appointments = "SELECT COUNT(*) as count FROM appointments WHERE appointment_date >= CURDATE()";
$upcoming_appointments = $conn->query($sql_upcoming_appointments)->fetch_assoc()['count'];

// Count announcements
$sql_announcements_count = "SELECT COUNT(*) as count FROM announcements";
$announcements_count = $conn->query($sql_announcements_count)->fetch_assoc()['count'];

// Count total inventory items
$sql_inventory_count = "SELECT COUNT(*) as count FROM dental_supplies";
$inventory_count = $conn->query($sql_inventory_count)->fetch_assoc()['count'];


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Secretary Dashboard - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    html {
        scroll-behavior: smooth;
    }

    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background: #e6f0ff;
        color: #003366;
        height: 100vh;
        display: flex;
    }

    .sidebar {
        width: 220px;
        background: linear-gradient(to bottom, #3399ff, #0066cc);
        padding: 20px;
        color: white;
        box-shadow: 2px 0 10px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
    }

    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        font-weight: 700;
        user-select: none;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }

    .sidebar a {
        display: block;
        padding: 12px 20px;
        margin: 10px 0;
        color: #cce0ff;
        text-decoration: none;
        border-left: 4px solid transparent;
        font-weight: 600;
        transition: background-color 0.3s ease, border-left-color 0.3s ease;
    }
    .sidebar a:hover,
    .sidebar a.active {
        background-color: rgba(255,255,255,0.15);
        color: white;
        border-left: 4px solid #ffcc00;
    }

    .main-content {
        flex: 1;
        padding: 40px;
        background: white;
        overflow-y: auto;
    }

    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }
    header h1 {
        font-size: 2rem;
        color: #004080;
        text-shadow: 1px 1px 2px #a3c2ff;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .welcome {
        font-size: 1.3rem;
        margin-bottom: 2rem;
        font-weight: 600;
    }

    .widgets {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 30px;
    }

    .widget {
        background: #f0f7ff;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        text-align: left;
        cursor: pointer;
        transition: transform 0.3s ease, background-color 0.3s ease;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }
    .widget:hover {
        transform: translateY(-5px);
        background-color: #d9e8ff;
    }

    .widget i {
        font-size: 36px;
        color: #004080;
        margin-bottom: 10px;
    }

    .widget .title {
        font-size: 18px;
        font-weight: 700;
        color: #003366;
    }

    .widget .value {
        font-size: 40px;
        font-weight: 900;
        color: #004080;
    }

    .widget .subtitle {
        font-size: 14px;
        color: #666;
        font-weight: 500;
    }
    
</style>
</head>
<body>
    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="secretary_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
       <a href="find_patient.php" ><i class="fas fa-search"></i> Find Patient</a>
        <a href="view_patients.php"><i class="fas fa-users"></i> View Patients</a>
        <a href="payments.php"><i class="fas fa-cash-register"></i> Payments</a>
        <a href="online_bookings.php"><i class="fas fa-laptop-code"></i> Online Bookings</a>
        <a href="payment_logs.php" ><i class="fas fa-file-invoice-dollar"></i> Payments Log</a>
        <a href="services_list.php"><i class="fas fa-list"></i> services</a>
        <a href="appointments.php" class="active"><i class="fas fa-calendar-check"></i> Manage Consultation</a>
        <a href="create_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>

    <main class="main-content">
        <header>
            <h1><i class="fas fa-calendar-check"></i> Appointments</h1>
        </header>

        <?php include '../calendar_function/secretary_calendar.php'; ?>
        </div>
    </main>
</body>
</html>
