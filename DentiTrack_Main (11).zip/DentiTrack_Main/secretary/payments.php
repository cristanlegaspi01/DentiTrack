<?php
session_start();
// Assuming these files set up $conn as a PDO object
include '../config/db_pdo.php';
include '../config/db_conn.php'; 

// Ensure PDO throws exceptions
if (isset($conn)) {
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} else {
    $error = "Database connection failed.";
}

// Check secretary role (Commented out for easy testing, uncomment for production)
/*
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: ../public/login.php');
    exit();
}
*/

$message = '';
$error = '';

// --- NEW ONLINE BOOKING INITIALIZATION PHP ---
$online_booking_mode = false;
$online_booking_patient_id = null;
$online_booking_service_id = null;
$online_booking_downpayment = null;
$online_booking_service_price = null;

if (isset($_GET['online_booking_process']) && $_GET['online_booking_process'] == 1 &&
    isset($_GET['patient_id']) && isset($_GET['service_id']) && isset($_GET['downpayment']) && isset($_GET['service_price'])) {
    
    $online_booking_mode = true;
    $online_booking_patient_id = intval($_GET['patient_id']);
    $online_booking_service_id = intval($_GET['service_id']);
    $online_booking_downpayment = floatval($_GET['downpayment']);
    $online_booking_service_price = floatval($_GET['service_price']);
}

// --- Fetch necessary data ---
if (isset($conn)) {
    try {
        // Fetch patients (patient_id, name, outstanding_balance is crucial)
        $patients = $conn->query("SELECT patient_id, outstanding_balance, CONCAT(first_name, ' ', last_name) AS name FROM patient ORDER BY first_name ASC")->fetchAll(PDO::FETCH_ASSOC);
        // Add service price as data attribute for JS
        $services = $conn->query("SELECT service_id, service_name, price FROM services ORDER BY service_name ASC")->fetchAll(PDO::FETCH_ASSOC);
        $supplies = $conn->query("SELECT supply_id, name, quantity, unit, price FROM dental_supplies ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $error = "Error loading data: " . $e->getMessage();
        $patients = $services = $supplies = []; 
    }
} else {
    $patients = $services = $supplies = [];
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    // Determine which service_id and payment_option to use based on the active tab
    $patient_id = intval($_POST['patient_id'] ?? 0);
    $payment_method = $_POST['payment_method'] ?? 'cash';
    
    // The payment_option is set dynamically by JS based on the active tab/select
    $payment_option = $_POST['payment_option'] ?? 'full'; 
    $service_id = intval($_POST['service_id'] ?? 0);

    $total_amount_billed = 0; 
    $discount = 0.0;
    
    // Variables for New Service/Installment Tab
    $base_amount = floatval($_POST['base_amount'] ?? 0); 
    $discount_type = $_POST['discount_type'] ?? 'none';
    $downpayment = floatval($_POST['downpayment'] ?? 0);
    $installment_term = intval($_POST['installment_term'] ?? 1);
    $monthly_payment = floatval($_POST['monthly_payment'] ?? 0);
    $used_supplies = $_POST['supply_id'] ?? [];
    $used_quantities = $_POST['used_quantity'] ?? [];

    // Variable for Existing Installment Tab
    $installment_payment_amount = floatval($_POST['installment_payment_amount'] ?? 0); 
    

    // --- 1. Determine Payment Type and Calculate Amounts ---
    if ($payment_option === 'installment_payment') {
        // Case: Payment towards an existing debt (Existing Installment Tab)
        $final_payment_amount = $installment_payment_amount;
        $total_amount_billed = $installment_payment_amount; // Log the amount paid in the total_amount field
        $status = 'paid_installment';
        
        if ($service_id <= 0) {
             $error = "Please select the service the installment payment relates to.";
        }
        
        if ($final_payment_amount <= 0) {
             $error = "Payment amount must be greater than zero.";
        }
        
    } else {
        // Case: NEW service (full or new installment plan) (New Service Tab)
        if ($patient_id <= 0 || $service_id <= 0 || $base_amount <= 0) {
            $error = "Please fill out all required fields and ensure the total amount is greater than zero for the new service.";
        } else {
            // Server-side calculation for NEW service
            // Note: base_amount now includes supplies and service price (calculated by JS)
            if ($discount_type === 'loyalty') $discount = $base_amount * 0.10;
            elseif ($discount_type === 'health') $discount = $base_amount * 0.15;
            
            $total_amount_billed = $base_amount - $discount;
            
            // The cash received now is the full amount or the downpayment
            $final_payment_amount = ($payment_option === 'installment') ? $downpayment : $total_amount_billed;
            
            // Determine transaction status
            $status = ($payment_option === 'full') ? 'paid' : 'pending';
        }
    }


    if (empty($error)) {
        
        // --- 2. Inventory Check and Logging (Only for NEW services - applies to both walk-in and online booking) ---
        $supplies_used_arr = [];
        $inventory_error = false;
        
        if ($payment_option !== 'installment_payment') { // Check inventory for any new service payment
            for ($i = 0; $i < count($used_supplies); $i++) {
                $supply_id = intval($used_supplies[$i]);
                $used_qty = intval($used_quantities[$i]);
                
                if ($supply_id > 0 && $used_qty > 0) {
                    $stmt = $conn->prepare("SELECT name, quantity FROM dental_supplies WHERE supply_id = :id");
                    $stmt->execute([':id' => $supply_id]);
                    $supply_data = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$supply_data || $supply_data['quantity'] < $used_qty) {
                        $error = "Insufficient stock for " . htmlspecialchars($supply_data['name'] ?? 'Supply ID: ' . $supply_id) . ".";
                        $inventory_error = true;
                        break;
                    }
                    
                    $supplies_used_arr[] = [
                        'id' => $supply_id,
                        'name' => $supply_data['name'],
                        'qty' => $used_qty
                    ];
                }
            }
        }
        
        if (!$inventory_error) {
            
            try {
                $conn->beginTransaction();

                // 3. Insert payment record 
                $stmt = $conn->prepare("INSERT INTO payments 
                    (patient_id, service_id, amount, discount_type, discount_amount, total_amount, payment_method, payment_option, downpayment, installment_term, monthly_payment, payment_date, supplies_used, created_at, status)
                    VALUES 
                    (:patient_id, :service_id, :amount, :discount_type, :discount_amount, :total_amount, :payment_method, :payment_option, :downpayment, :installment_term, :monthly_payment, NOW(), :supplies_used, NOW(), :status)");

                $stmt->execute([
                    ':patient_id' => $patient_id,
                    ':service_id' => $service_id,
                    // Use the calculated base_amount (service + supplies) for the 'amount' field
                    ':amount' => ($payment_option !== 'installment_payment') ? $base_amount : 0, 
                    // Use the posted discount_type and calculated discount
                    ':discount_type' => ($payment_option !== 'installment_payment') ? $discount_type : 'none',
                    ':discount_amount' => ($payment_option !== 'installment_payment') ? $discount : 0,
                    // Use the calculated total_amount_billed (base_amount - discount)
                    ':total_amount' => $total_amount_billed,
                    ':payment_method' => $payment_method,
                    ':payment_option' => $payment_option, 
                    // Log the cash received now (downpayment for new debt, or the installment amount for old debt)
                    ':downpayment' => $final_payment_amount, 
                    // Use posted installment terms
                    ':installment_term' => ($payment_option === 'installment') ? $installment_term : 0,
                    ':monthly_payment' => ($payment_option === 'installment') ? $monthly_payment : 0,
                    // Log supplies used
                    ':supplies_used' => ($payment_option === 'installment_payment') ? '[]' : json_encode($supplies_used_arr), 
                    ':status' => $status
                ]);

                $payment_id = $conn->lastInsertId();
                if (!$payment_id) {
                    throw new Exception("Failed to retrieve new payment ID.");
                }

                // 4. Deduct stock and log supply usage (Only for NEW services)
                if ($payment_option !== 'installment_payment' && !empty($supplies_used_arr)) {
                    foreach ($supplies_used_arr as $s) {
                        // Deduct stock
                        $update = $conn->prepare("UPDATE dental_supplies SET quantity = quantity - :qty WHERE supply_id = :id");
                        $update->execute([':qty' => $s['qty'], ':id' => $s['id']]);

                        // Log usage
                        $log = $conn->prepare("INSERT INTO supply_usage (supply_id, patient_id, payment_id, quantity_used, used_at)
                                             VALUES (:supply_id, :patient_id, :payment_id, :quantity_used, NOW())");
                        $log->execute([
                            ':supply_id' => $s['id'],
                            ':patient_id' => $patient_id,
                            ':payment_id' => $payment_id,
                            ':quantity_used' => $s['qty']
                        ]);
                    }
                }
                
                // 5. Update Patient's Outstanding Balance 
                
                if ($payment_option === 'installment') {
                    // 5a. Add NEW debt to the patient's balance
                    $remaining_balance_to_add = $total_amount_billed - $final_payment_amount;
                    
                    if ($remaining_balance_to_add > 0) {
                        $update_balance_add = $conn->prepare("UPDATE patient SET outstanding_balance = outstanding_balance + :remaining WHERE patient_id = :id");
                        $update_balance_add->execute([
                            ':remaining' => $remaining_balance_to_add,
                            ':id' => $patient_id
                        ]);
                    }
                } elseif ($payment_option === 'installment_payment') {
                    // 5b. Deduct OLD debt from the patient's balance
                    if ($final_payment_amount > 0) {
                        $update_balance_deduct = $conn->prepare("UPDATE patient SET outstanding_balance = outstanding_balance - :settled_amount WHERE patient_id = :id");
                        $update_balance_deduct->execute([
                            ':settled_amount' => $final_payment_amount,
                            ':id' => $patient_id
                        ]);
                    }
                }

                $conn->commit();
                
                // Redirect to receipt.php after successful transaction
                header("Location: receipt.php?id=" . $payment_id);
                exit();

            } catch (Exception $e) {
                $conn->rollBack();
                $error = "Transaction failed: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Payments - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<style>
/* --- Design Styles (Keep consistent with previous design) --- */
*,*::before,*::after{box-sizing:border-box;}
body,html{margin:0;padding:0;height:100%;font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#e6f0ff;color:#003366;}
body{display:flex;min-height:100vh;overflow-x:hidden;}
.sidebar{width:260px;background:linear-gradient(to bottom,#3399ff,#0066cc);padding:20px;color:white;display:flex;flex-direction:column;box-shadow:2px 0 10px rgba(0,0,0,0.15);}
.sidebar h2{text-align:center;margin-bottom:30px;font-size:24px;font-weight:700;}
.sidebar a{display:block;padding:12px 20px;margin:10px 0;color:#cce0ff;text-decoration:none;border-left:4px solid transparent;font-weight:600;transition:0.3s;}
.sidebar a:hover,.sidebar a.active{background:rgba(255,255,255,0.15);color:white;border-left:4px solid #ffcc00;}
main.main-content{flex:1;background:#fff;padding:40px 50px;overflow-y:auto;}
header h1{font-size:2.3rem;font-weight:900;color:#004080;display:flex;align-items:center;gap:15px;}
.flash-message{max-width:700px;margin:15px auto;padding:16px 20px;border-radius:15px;font-weight:700;text-align:center;}
.flash-success{background:#d4edda;color:#155724;}
.flash-error{background:#f8d7da;color:#721c24;}
form#payment-form{background:#f0f7ff;padding:30px;border-radius:20px;box-shadow:0 10px 25px rgba(0,0,0,0.1);max-width:700px;margin:auto;}
form#payment-form h2{text-align:center;color:#004080;margin-bottom:20px;}
.form-row{display:flex;flex-wrap:wrap;gap:20px;margin-bottom:15px;align-items:center;}
.form-row label{flex:1 0 120px;font-weight:600;color:#003366;}
.form-row select,.form-row input[type=number],.form-row input[type=text]{flex:2 1 250px;padding:8px 12px;border-radius:12px;border:1.5px solid #3399ff;font-weight:600;color:#003366;}
/* NEW STYLES FOR ALIGNED SUPPLIES */
.supply-row-group {
    flex: 2 1 250px; /* Takes up the space of a regular input/select */
    display: flex;
    gap: 10px;
    align-items: center;
}
.supply-row-group .supply-select {
    flex: 3; /* Supply select takes up more space */
    padding:8px 12px;border-radius:12px;border:1.5px solid #3399ff;font-weight:600;color:#003366;
}
.supply-row-group .qty-input {
    flex: 1; /* Quantity input is smaller */
    padding:8px 12px;border-radius:12px;border:1.5px solid #3399ff;font-weight:600;color:#003366;
}
.supply-row-group .remove-btn {
    flex: 0 0 40px; 
    background:#dc3545; 
    color:white; 
    border:none; 
    border-radius:12px; 
    padding:10px 0; 
    font-weight:700; 
    cursor:pointer; 
    font-size: 1.1rem;
}
/* END NEW STYLES */

form#payment-form button[type=submit]{display:block;margin:20px auto;padding:14px 40px;font-weight:700;font-size:1.1rem;border:none;border-radius:20px;background:#3399ff;color:white;box-shadow:0 6px 20px rgba(51,153,255,0.6);cursor:pointer;}
form#payment-form button[type=submit]:hover{background:#0066cc;}
.supplies-card{background:#eaf3ff;border-radius:20px;padding:25px;margin-top:20px;box-shadow:0 8px 25px rgba(0,102,204,0.1);}
.supplies-card h3{font-size:1.5rem;color:#004080;font-weight:800;margin-bottom:20px;display:flex;align-items:center;gap:10px;}
#supplies-container{display:flex;flex-direction:column;gap:15px;} /* Increased gap for better spacing */
.tab-navigation{display: flex; justify-content: center; margin-bottom: 25px;}
.tab-button{padding: 10px 20px; border: none; background: #cce0ff; color: #004080; cursor: pointer; font-weight: 600; transition: background 0.3s; border-radius: 12px 12px 0 0; margin: 0 5px;}
.tab-button.active{background: #3399ff; color: white;}
/* Additional style for disabled/readonly fields in online mode */
.form-row input[readonly], .form-row select[disabled] {
    background-color: #f5f5f5;
    cursor: not-allowed;
}
</style>
</head>
<body>

    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="secretary_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="find_patient.php" ><i class="fas fa-search"></i> Find Patient</a>
        <a href="view_patients.php"><i class="fas fa-users"></i> View Patients</a>
        <a href="Payments.php"class="active"><i class="fas fa-cash-register"></i> Payments</a>
        <a href="online_bookings.php"><i class="fas fa-laptop-code"></i> Online Bookings</a>
        <a href="payment_logs.php" ><i class="fas fa-file-invoice-dollar"></i> Payments Log</a>
        <a href="services_list.php"><i class="fas fa-list"></i> Services</a>
        <a href="appointments.php"><i class="fas fa-calendar-check"></i> Manage Consultation</a>
        <a href="create_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>
<main class="main-content">
<header><h1><i class="fas fa-cash-register"></i> Record Payments</h1></header>
<hr>

<?php if ($message): ?>
    <div class="flash-message flash-success"><?= htmlspecialchars($message) ?></div>
<?php elseif ($error): ?>
    <div class="flash-message flash-error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form id="payment-form" method="post" action="payments.php" novalidate data-tab="new_service"> 
    <h2>Add Payment</h2>
    
    <div class="tab-navigation">
        <button type="button" class="tab-button" onclick="changeTab('new_service', this)">
            <i class="fas fa-plus-circle"></i> New Service Payment
        </button>
        <button type="button" class="tab-button" onclick="changeTab('existing_installment', this)">
            <i class="fas fa-undo"></i> Pay Existing Installment
        </button>
    </div>

    <div id="new_service" class="tab-content">
        <div class="form-row">
            <label for="patient_id">Select Patient:</label>
            <select name="patient_id" id="patient_id" onchange="populateDebtServices()"
                    <?= $online_booking_mode ? 'disabled' : '' ?>>
                <option value="">-- Select Patient --</option>
                <?php foreach ($patients as $p): ?>
                    <option value="<?= $p['patient_id'] ?>" 
                            data-balance="<?= $p['outstanding_balance'] ?>"
                            <?= ($online_booking_mode && $p['patient_id'] == $online_booking_patient_id) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($p['name']) ?> (Balance: ₱<?= number_format($p['outstanding_balance'], 2) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-row">
            <label for="service_id_new">Select Service:</label>
            <select id="service_id_new" onchange="updateTotal()" 
                    <?= $online_booking_mode ? 'disabled' : '' ?>>
                <option value="">-- Select Service --</option>
                <?php foreach ($services as $s): ?>
                    <option value="<?= $s['service_id'] ?>" 
                            data-price="<?= $s['price'] ?>"
                            <?= ($online_booking_mode && $s['service_id'] == $online_booking_service_id) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($s['service_name']) ?> (₱<?= number_format($s['price'], 2) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
             <?php if ($online_booking_mode): ?>
                <input type="hidden" name="service_id" value="<?= $online_booking_service_id ?>">
            <?php endif; ?>
        </div>

        <div class="form-row">
            <label>Payment Method:</label>
            <div class="payment-method">
                <label><input type="radio" name="payment_method" value="Cash" checked> Cash</label>
                <label><input type="radio" name="payment_method" value="Online"> Online Transfer</label>
                <label><input type="radio" name="payment_method" value="Card"> Card</label>
            </div>
        </div>
        
        <div class="supplies-card" id="supplies-section">
            <h3><i class="fas fa-boxes"></i> Supplies Used</h3>
            <div id="supplies-container">
                <div class="form-row supply-row">
                    <label>Supply Item:</label>
                    <div class="supply-row-group">
                        <select name="supply_id[]" class="supply-select" onchange="updateTotal()">
                            <option value="">-- Select Supply --</option>
                            <?php foreach ($supplies as $sup): ?>
                                <option value="<?= $sup['supply_id'] ?>" data-price="<?= $sup['price'] ?>">
                                    <?= htmlspecialchars($sup['name']) ?> (Stock: <?= $sup['quantity'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="number" name="used_quantity[]" class="qty-input" min="1" value="1" placeholder="Qty" oninput="updateTotal()">
                        <button type="button" class="remove-btn fas fa-trash" onclick="this.closest('.supply-row').remove(); updateTotal()"></button>
                    </div>
                </div>
            </div>
            <div class="form-row" style="justify-content: flex-end; margin-top: 15px;">
                <button type="button" onclick="addSupplyRow()" style="flex: 0 1 auto; padding: 10px 20px;">+ Add Supply</button>
            </div>
        </div>
        <hr> 
        
        <div class="form-row" id="discount-row">
            <label>Discount Type:</label>
            <select name="discount_type" id="discount_type" onchange="updateTotal()">
                <option value="none">None</option>
                <option value="loyalty">Loyalty Card (10%)</option>
                <option value="health">Health Card (15%)</option>
            </select>
        </div>
        
        <div class="form-row">
            <label>Total Amount (w/ Discount):</label>
            <input type="number" id="amount" name="amount_display" step="0.01" readonly placeholder="Calculated Total">
            <input type="hidden" id="base_amount" name="base_amount"> 
        </div>
        <hr> 
        
        <div class="form-row">
            <label>Payment Option:</label>
            <select id="payment_option_new" onchange="toggleInstallmentFields()" 
                    <?= $online_booking_mode ? 'disabled' : '' ?>>
                <option value="full">Full Payment</option>
                <option value="installment">New Installment Plan</option>
            </select>
             <?php if ($online_booking_mode): ?>
                <input type="hidden" name="payment_option" value="installment">
            <?php endif; ?>
        </div>
        <hr> 
        
        <div id="new-installment-setup">
            <div class="form-row" id="downpayment-row" style="display:none;">
                <label>Downpayment (₱):</label>
                <input type="number" id="downpayment" name="downpayment" step="0.01" min="0" value="0" oninput="calculateInstallment()">
            </div>
            <div class="form-row" id="installment-row" style="display:none;">
                <label>Installment Term:</label>
                <select id="installment_term" name="installment_term" onchange="calculateInstallment()">
                    <option value="1">1 month</option>
                    <option value="2">2 months</option>
                    <option value="3">3 months</option>
                    <option value="6">6 months</option>
                    <option value="12">12 months</option>
                    <option value="24">24 months</option>
                    <option value="36">36 months</option>
                </select>
            </div>
            <div class="form-row" id="monthly-row" style="display:none;">
                <label>Monthly Payment (₱):</label>
                <input type="number" id="monthly_payment" name="monthly_payment" readonly placeholder="Calculated Monthly">
            </div>
        </div>
    </div>

    <div id="existing_installment" class="tab-content" style="display:none;">
        <input type="hidden" name="payment_option" id="payment_option_existing" value="installment_payment">
        <div class="form-row">
            <label for="patient_id_existing_display">Selected Patient:</label>
             <select id="patient_id_existing_display" disabled>
                 <option value="">-- Patient Not Selected --</option>
                 <?php foreach ($patients as $p): ?>
                    <option value="<?= $p['patient_id'] ?>" data-balance="<?= $p['outstanding_balance'] ?>">
                        <?= htmlspecialchars($p['name']) ?> (Balance: ₱<?= number_format($p['outstanding_balance'], 2) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-row">
            <label for="service_id_existing">Installment Service:</label>
            <select id="service_id_existing" onchange="fetchInstallmentDetails()">
                <option value="">-- Select Debt Service --</option>
            </select>
        </div>
        <hr>
        
        <div class="supplies-card">
            <h3><i class="fas fa-file-invoice-dollar"></i> Installment Details</h3>
            <div class="form-row">
                <label>Remaining Balance (Service):</label>
                <input type="number" id="service_remaining_balance" readonly placeholder="0.00">
            </div>
            <div class="form-row">
                <label>Current Monthly Due:</label>
                <input type="number" id="current_monthly_due" readonly placeholder="0.00">
            </div>
            <div class="form-row">
                <label>Total Outstanding Balance:</label>
                <input type="number" id="current_total_balance" readonly placeholder="0.00">
            </div>
        </div>
        <hr>
        
        <div class="form-row">
            <label for="installment_payment_amount">Payment Amount (₱):</label>
            <input type="number" id="installment_payment_amount" name="installment_payment_amount" step="0.01" min="0" value="0.00">
        </div>
        
        <div class="form-row">
            <label>Payment Method:</label>
            <div class="payment-method">
                <label><input type="radio" name="payment_method" value="Cash" checked> Cash</label>
                <label><input type="radio" name="payment_method" value="Online"> Online Transfer</label>
                <label><input type="radio" name="payment_method" value="Card"> Card</label>
            </div>
        </div>
        
    </div>

    <button type="submit" id="submit-button"><i class="fas fa-receipt"></i> Complete Payment</button>
</form>

<script>
// PHP variables for initial setup
const ONLINE_BOOKING_MODE = <?= $online_booking_mode ? 'true' : 'false' ?>;
const ONLINE_PATIENT_ID = <?= $online_booking_patient_id ?? 'null' ?>;
const ONLINE_SERVICE_ID = <?= $online_booking_service_id ?? 'null' ?>;
const ONLINE_DOWNPAYMENT = <?= $online_booking_downpayment ?? 'null' ?>;
const ONLINE_SERVICE_PRICE = <?= $online_booking_service_price ?? 'null' ?>;

// --- Tab Switching ---
function changeTab(tabId, buttonElement) {
    // 1. Manage active tab/content visibility
    document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
    document.getElementById(tabId).style.display = 'block';
    if (buttonElement) {
        buttonElement.classList.add('active');
    }

    // 2. Manage form attributes (name attributes for submission)
    const form = document.getElementById('payment-form');
    const serviceSelectNew = document.getElementById('service_id_new');
    const serviceSelectExisting = document.getElementById('service_id_existing');
    const paymentOptionNew = document.getElementById('payment_option_new');
    const paymentOptionExisting = document.getElementById('payment_option_existing');
    const patientSelect = document.getElementById('patient_id');

    // Remove all previous name/required attributes
    serviceSelectNew.removeAttribute('name');
    serviceSelectExisting.removeAttribute('name');
    paymentOptionNew.removeAttribute('name');
    paymentOptionExisting.removeAttribute('name');
    serviceSelectNew.removeAttribute('required');
    serviceSelectExisting.removeAttribute('required');
    document.getElementById('installment_payment_amount').removeAttribute('required');
    form.setAttribute('data-tab', tabId);

    // Sync patient selection across tabs
    const patientId = patientSelect.value;
    document.getElementById('patient_id_existing_display').value = patientId; 

    if (tabId === 'new_service') {
        // Set Service ID and Payment Option for New Service Tab
        serviceSelectNew.setAttribute('name', 'service_id');
        serviceSelectNew.setAttribute('required', 'required');
        
        // Only set name if not in online booking mode (where hidden field sets it)
        if (!ONLINE_BOOKING_MODE) {
            paymentOptionNew.setAttribute('name', 'payment_option');
        }

        // Force 'Full Payment' fields to be visible/required initially for new service
        toggleInstallmentFields();
        updateTotal();

    } else if (tabId === 'existing_installment') {
        // Set Service ID and Payment Option for Existing Installment Tab
        serviceSelectExisting.setAttribute('name', 'service_id');
        serviceSelectExisting.setAttribute('required', 'required');
        paymentOptionExisting.setAttribute('name', 'payment_option');
        document.getElementById('installment_payment_amount').setAttribute('required', 'required');

        // Hide new service/installment fields
        document.getElementById('downpayment-row').style.display = 'none';
        document.getElementById('installment-row').style.display = 'none';
        document.getElementById('monthly-row').style.display = 'none';
        
        // Fetch debt services for the newly active tab
        populateDebtServices();
    }
}

// --- Online Booking Mode Initialization ---
function initializeOnlineBooking() {
    if (!ONLINE_BOOKING_MODE) return;

    // 1. Switch to New Service tab and activate button style
    changeTab('new_service', document.querySelector('.tab-navigation .tab-button:first-child'));

    // 2. Set Patient/Service selection to Readonly/Disabled
    const patientSelect = document.getElementById('patient_id');
    const serviceSelect = document.getElementById('service_id_new');
    const paymentOption = document.getElementById('payment_option_new');
    
    // The PHP template handles setting the correct 'selected' value
    patientSelect.disabled = true;
    serviceSelect.disabled = true;
    paymentOption.value = 'installment';
    paymentOption.disabled = true;
    
    // 3. Set Downpayment and make it read-only
    const downpaymentInput = document.getElementById('downpayment');
    downpaymentInput.value = ONLINE_DOWNPAYMENT.toFixed(2);
    downpaymentInput.setAttribute('readonly', 'readonly');
    downpaymentInput.style.backgroundColor = '#f0f0f0'; // Highlight pre-filled field

    // 4. Show Installment fields
    const downpaymentRow = document.getElementById('downpayment-row');
    const installmentRow = document.getElementById('installment-row');
    const monthlyRow = document.getElementById('monthly-row');
    
    downpaymentRow.style.display = 'flex';
    installmentRow.style.display = 'flex';
    monthlyRow.style.display = 'flex';
    
    // 5. Calculate total amount (service + supplies + discount) and monthly payment
    updateTotal(); 
    
    // Change submit button text
    document.getElementById('submit-button').innerHTML = '<i class="fas fa-receipt"></i> Finalize Installment';
}


// --- Payment Calculation (New Service Tab) ---

function updateTotal() {
    // Only run if the 'new_service' tab is active OR in online booking mode
    if (document.getElementById('payment-form').getAttribute('data-tab') !== 'new_service' && !ONLINE_BOOKING_MODE) return;
    
    const serviceSelect = document.getElementById('service_id_new');
    const discountType = document.getElementById('discount_type').value;
    let baseAmount = 0;

    // 1. Service Price 
    let servicePrice = 0;
    const selectedService = serviceSelect.options[serviceSelect.selectedIndex];
    if (selectedService && selectedService.dataset.price) {
        servicePrice = parseFloat(selectedService.dataset.price);
    }
    baseAmount += servicePrice;
    
    // 2. Supplies 
    document.querySelectorAll('#supplies-container .supply-row').forEach(row => {
        const select = row.querySelector('.supply-select');
        const qtyInput = row.querySelector('.qty-input');
        // Safely get price, defaulting to 0
        const price = parseFloat(select.options[select.selectedIndex]?.dataset.price || 0);
        const qty = parseInt(qtyInput.value) || 0;
        baseAmount += price * qty;
    });

    // 3. Apply Discount 
    let discount = 0;
    if (discountType === 'loyalty') discount = baseAmount * 0.10;
    else if (discountType === 'health') discount = baseAmount * 0.15;

    const finalAmount = baseAmount - discount;

    document.getElementById('amount').value = finalAmount.toFixed(2);
    document.getElementById('base_amount').value = baseAmount.toFixed(2);

    calculateInstallment();
}

// Shows/hides installment fields and triggers calculation
function toggleInstallmentFields() {
    // Prevent modification if in a forced online booking state
    if (ONLINE_BOOKING_MODE) {
        document.getElementById('downpayment-row').style.display = 'flex';
        document.getElementById('installment-row').style.display = 'flex';
        document.getElementById('monthly-row').style.display = 'flex';
        return;
    }
    
    const paymentOption = document.getElementById('payment_option_new').value;
    const downpaymentRow = document.getElementById('downpayment-row');
    const installmentRow = document.getElementById('installment-row');
    const monthlyRow = document.getElementById('monthly-row');
    const downpaymentInput = document.getElementById('downpayment');

    if (paymentOption === 'installment') {
        downpaymentRow.style.display = 'flex';
        installmentRow.style.display = 'flex';
        monthlyRow.style.display = 'flex';
        downpaymentInput.setAttribute('required', 'required');
    } else {
        downpaymentRow.style.display = 'none';
        installmentRow.style.display = 'none';
        monthlyRow.style.display = 'none';
        downpaymentInput.removeAttribute('required');
        downpaymentInput.value = '0'; // Reset for 'full' payment
    }
    calculateInstallment();
}

// Calculates monthly payment for a new installment plan
function calculateInstallment() {
    const finalAmount = parseFloat(document.getElementById('amount').value) || 0;
    const downpayment = parseFloat(document.getElementById('downpayment').value) || 0;
    const term = parseInt(document.getElementById('installment_term').value) || 1;
    const remainingBalance = finalAmount - downpayment;

    if (remainingBalance > 0 && term > 0) {
        const monthly = remainingBalance / term;
        document.getElementById('monthly_payment').value = monthly.toFixed(2);
    } else {
        document.getElementById('monthly_payment').value = '0.00';
    }
}

// --- Supply Management (MODIFIED) ---
function addSupplyRow() {
    const container = document.getElementById('supplies-container');
    const firstRow = container.querySelector('.supply-row');
    
    // Clone the entire form-row structure
    const newRow = firstRow.cloneNode(true);
    
    // Clear the selected value and reset quantity
    newRow.querySelector('.supply-select').value = '';
    newRow.querySelector('.qty-input').value = '1';

    // Update event listeners on the new row
    newRow.querySelector('.supply-select').onchange = updateTotal;
    newRow.querySelector('.qty-input').oninput = updateTotal;
    
    // Re-link the remove button's function
    newRow.querySelector('.remove-btn').onclick = function() {
        this.closest('.supply-row').remove();
        updateTotal();
    };

    container.appendChild(newRow);
    updateTotal();
}


// --- Debt Management (Requires separate AJAX endpoints to function) ---

/** Fetches and populates services the patient currently owes money for. */
function populateDebtServices() {
    const patientSelect = document.getElementById('patient_id');
    const patientId = parseInt(patientSelect.value);
    const serviceSelect = document.getElementById('service_id_existing'); 
    
    // Sync patient selection display in the existing tab
    document.getElementById('patient_id_existing_display').value = patientId;

    // Reset and disable the service select initially
    serviceSelect.innerHTML = '<option value="">-- Loading services... --</option>';
    serviceSelect.disabled = true;
    
    // Clear the debt details card 
    document.getElementById('service_remaining_balance').value = '0.00';
    document.getElementById('current_monthly_due').value = '0.00';
    document.getElementById('current_total_balance').value = '0.00';
    document.getElementById('installment_payment_amount').value = '0.00';


    if (patientId > 0) {
        // --- NOTE: This is a placeholder for an AJAX call to a PHP script you must create. ---
        // Example: fetch_patient_debt_services.php?patient_id=...
        
        // Simulating the result for demonstration (Replace with actual fetch call)
        setTimeout(() => {
            serviceSelect.disabled = false;
            let options = '<option value="">-- Select Debt Service --</option>';
            // Example patient ID 26 with active debt
            if (patientId === 26) { 
                options += `<option value="9" data-debt="44500.00" data-monthly="1000.00">
                                Dental Implants (Remaining: ₱44,500.00)
                            </option>`;
                options += `<option value="12" data-debt="2000.00" data-monthly="500.00">
                                Teeth Whitening (Remaining: ₱2,000.00)
                            </option>`;
            } else {
                 // For all other patients
                 options = '<option value="">-- No active installment debt found for this patient --</option>';
                 serviceSelect.disabled = true;
            }
            serviceSelect.innerHTML = options;
        }, 300);
        // --- END SIMULATION ---
        
    } else {
        serviceSelect.innerHTML = '<option value="">-- Select Patient First --</option>';
    }
}


function fetchInstallmentDetails() {
    const serviceSelect = document.getElementById('service_id_existing');
    const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
    
    // Clear previous values
    document.getElementById('service_remaining_balance').value = '0.00';
    document.getElementById('current_monthly_due').value = '0.00';
    document.getElementById('current_total_balance').value = '0.00';
    document.getElementById('installment_payment_amount').value = '0.00';

    if (!selectedOption || !selectedOption.dataset.debt) return;
    
    const debt = parseFloat(selectedOption.dataset.debt);
    const monthly = parseFloat(selectedOption.dataset.monthly);
    
    // --- NOTE: This is a placeholder for an AJAX call to a PHP script you must create. ---
    // Simulating the total balance from the patient select
    const patientSelect = document.getElementById('patient_id');
    const totalBalance = parseFloat(patientSelect.options[patientSelect.selectedIndex].dataset.balance || 0);
    // --- END SIMULATION ---
    
    if (debt > 0) {
        document.getElementById('service_remaining_balance').value = debt.toFixed(2);
        document.getElementById('current_monthly_due').value = monthly.toFixed(2);
        document.getElementById('current_total_balance').value = totalBalance.toFixed(2);
        
        // Pre-fill the payment amount
        let suggestedPayment = monthly;
        if (suggestedPayment > debt) {
            suggestedPayment = debt;
        }
        document.getElementById('installment_payment_amount').value = suggestedPayment.toFixed(2);
    }
}


// --- Initial Setup ---

document.addEventListener('DOMContentLoaded', function() {
    const patientSelect = document.getElementById('patient_id');
    
    if (ONLINE_BOOKING_MODE) {
        // If in online booking mode, force initialization
        initializeOnlineBooking();
    } else {
        // Initial setup: activate the first tab programmatically to initialize required fields
        const firstButton = document.querySelector('.tab-navigation .tab-button:first-child');
        if (firstButton) {
             firstButton.click();
        }
    }

    // Update patient list visibility on existing tab
    patientSelect.addEventListener('change', populateDebtServices);
    
    // Call populateDebtServices on load if a patient is already selected (e.g., from form re-submission after error)
    if (parseInt(patientSelect.value) > 0) {
        populateDebtServices();
    }
});
</script>

</body>
</html>