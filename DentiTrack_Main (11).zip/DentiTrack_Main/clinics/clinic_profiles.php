<?php
session_start();
require_once '../config/db_pdo.php'; 

if (!isset($_SESSION['clinic_id'])) {
    header("Location: ../index.php");
    exit;
}

$clinic_id = $_SESSION['clinic_id'];
$message = "";

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = $_POST['address'];
    $contact_number = $_POST['contact_number'];
    $about = $_POST['about'];

    // Handle logo upload
    $logo = null;
    if (!empty($_FILES['logo']['name'])) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $fileName = time() . "_" . basename($_FILES["logo"]["name"]);
        $targetFile = $targetDir . $fileName;

        if (move_uploaded_file($_FILES["logo"]["tmp_name"], $targetFile)) {
            $logo = "uploads/" . $fileName;
        }
    }

    // Check if profile exists
    $check = $pdo->prepare("SELECT * FROM clinic_profiles WHERE clinic_id=?");
    $check->execute([$clinic_id]);
    if ($check->fetch()) {
        // Update
        $query = "UPDATE clinic_profiles SET address=?, contact_number=?, about=?, updated_at=NOW()";
        $params = [$address, $contact_number, $about];
        if ($logo) {
            $query .= ", logo=?";
            $params[] = $logo;
        }
        $query .= " WHERE clinic_id=?";
        $params[] = $clinic_id;
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $message = "Profile updated!";
    } else {
        // Insert
        $stmt = $pdo->prepare("INSERT INTO clinic_profiles (clinic_id, logo, address, contact_number, about) VALUES (?,?,?,?,?)");
        $stmt->execute([$clinic_id, $logo, $address, $contact_number, $about]);
        $message = "Profile created!";
    }
}

// Fetch profile
$stmt = $pdo->prepare("SELECT * FROM clinic_profiles WHERE clinic_id=?");
$stmt->execute([$clinic_id]);
$profile = $stmt->fetch();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Clinic Profile</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 30px; }
        form { max-width: 500px; margin: auto; background: #f9f9f9; padding: 20px; border-radius: 8px; }
        input, textarea { width: 100%; margin: 8px 0; padding: 10px; }
        button { padding: 10px 15px; background: #007bff; color: #fff; border: none; border-radius: 6px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .message { margin-bottom: 15px; color: green; font-weight: bold; }
    </style>
</head>
<body>
    <h2>Clinic Profile</h2>
    <?php if($message): ?><div class="message"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
        <label>Logo:</label>
        <input type="file" name="logo">
        <?php if($profile && $profile['logo']): ?>
            <br><img src="../<?= htmlspecialchars($profile['logo']) ?>" width="100">
        <?php endif; ?>
        <label>Address:</label>
        <textarea name="address"><?= $profile['address'] ?? '' ?></textarea>
        <label>Contact Number:</label>
        <input type="text" name="contact_number" value="<?= $profile['contact_number'] ?? '' ?>">
        <label>About:</label>
        <textarea name="about"><?= $profile['about'] ?? '' ?></textarea>
        <button type="submit">Save</button>
    </form>
</body>
</html>
