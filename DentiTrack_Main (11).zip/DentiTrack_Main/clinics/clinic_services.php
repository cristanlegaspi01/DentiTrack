<?php
session_start();
require_once '../config/db_pdo.php'; 

if (!isset($_SESSION['clinic_id'])) {
    header("Location: ../index.php");
    exit;
}

$clinic_id = $_SESSION['clinic_id'];
$message = "";

// Add service
if (isset($_POST['add'])) {
    $service_name = $_POST['service_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $stmt = $pdo->prepare("INSERT INTO clinic_services (clinic_id, service_name, description, price) VALUES (?,?,?,?)");
    $stmt->execute([$clinic_id, $service_name, $description, $price]);
    $message = "Service added!";
}

// Delete service
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM clinic_services WHERE service_id=? AND clinic_id=?");
    $stmt->execute([$id, $clinic_id]);
    $message = "Service deleted!";
}

// Fetch services
$stmt = $pdo->prepare("SELECT * FROM clinic_services WHERE clinic_id=?");
$stmt->execute([$clinic_id]);
$services = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Clinic Services</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 30px; }
        form, table { max-width: 600px; margin: auto; }
        input, textarea { width: 100%; margin: 8px 0; padding: 10px; }
        button { padding: 10px 15px; background: #28a745; color: #fff; border: none; border-radius: 6px; cursor: pointer; }
        button:hover { background: #1e7e34; }
        .delete-btn { background: red; padding: 5px 10px; color: #fff; text-decoration: none; border-radius: 5px; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        table, th, td { border: 1px solid #ddd; padding: 10px; }
        .message { margin-bottom: 15px; color: green; font-weight: bold; }
    </style>
</head>
<body>
    <h2>Clinic Services</h2>
    <?php if($message): ?><div class="message"><?= htmlspecialchars($message) ?></div><?php endif; ?>

    <form method="POST">
        <label>Service Name:</label>
        <input type="text" name="service_name" required>
        <label>Description:</label>
        <textarea name="description"></textarea>
        <label>Price:</label>
        <input type="number" step="0.01" name="price">
        <button type="submit" name="add">Add Service</button>
    </form>

    <h3>Existing Services</h3>
    <table>
        <tr><th>Name</th><th>Description</th><th>Price</th><th>Action</th></tr>
        <?php foreach ($services as $s): ?>
        <tr>
            <td><?= htmlspecialchars($s['service_name']) ?></td>
            <td><?= htmlspecialchars($s['description']) ?></td>
            <td><?= htmlspecialchars($s['price']) ?></td>
            <td><a class="delete-btn" href="?delete=<?= $s['service_id'] ?>">Delete</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
