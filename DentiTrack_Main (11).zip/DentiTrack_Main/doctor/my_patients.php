<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'doctor') {
    header('Location: doctor_login.php');
    exit();
}

// NOTE: require_once '../config/db_pdo.php' is assumed to define $pdo for main operations.
require_once '../config/db_pdo.php';

$doctor_username = $_SESSION['username'] ?? '';
$clinicDb = 'dentitrack_main';

// --- HELPER FUNCTION FOR REDIRECT ---
function redirect_with_patient_id($patient_id, $message_key, $message_value) {
    // Redirect back to the same page with the patient ID to trigger modal re-open
    // and a success/error message
    $url = "my_patients.php?" . $message_key . "=" . urlencode($message_value) . "&refetch_patient_id=" . urlencode($patient_id);
    header("Location: " . $url);
    exit();
}

// --- HANDLE FILE UPLOAD (UNCHANGED) ---
if (isset($_POST['upload_file']) && isset($_FILES['patient_file'])) {
    $patient_id = $_POST['patient_id'];
    $file = $_FILES['patient_file'];

    $uploadDir = '../uploads/patient_files/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    $fileName = time() . '_' . basename($file['name']);
    $targetFile = $uploadDir . $fileName;

    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        // Insert with uploaded_at timestamp
        $stmt = $pdo->prepare("INSERT INTO patient_files (patient_id, file_name, file_path, uploaded_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$patient_id, $file['name'], $targetFile]);

        // Use the new redirect function
        redirect_with_patient_id($patient_id, 'uploadSuccess', 'File uploaded successfully.');
    } else {
        redirect_with_patient_id($patient_id, 'uploadError', 'Failed to upload file.');
    }
}

// --- HANDLE SAVE NEW RECOMMENDATION ---
if (isset($_POST['save_recommendation'])) {
    $patient_id = $_POST['patient_id'];
    $recommendation = trim($_POST['recommendation'] ?? '');

    if ($recommendation !== '') {
        $stmt = $pdo->prepare("INSERT INTO patient_recommendations (patient_id, doctor_username, recommendation, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$patient_id, $doctor_username, $recommendation]);
        
        redirect_with_patient_id($patient_id, 'recSuccess', 'Recommendation saved.');
    } else {
        redirect_with_patient_id($patient_id, 'recError', 'Recommendation cannot be empty.');
    }
}

// --- NEW: HANDLE EDIT RECOMMENDATION SUBMISSION ---
if (isset($_POST['edit_recommendation'])) {
    $rec_id = $_POST['rec_id'];
    $patient_id = $_POST['patient_id']; // CRITICAL: Added patient_id retrieval here
    $recommendation = trim($_POST['recommendation'] ?? '');

    if ($recommendation !== '' && is_numeric($rec_id)) {
        // FIX APPLIED: Removed 'updated_at = NOW()' to avoid Unknown column error
        $stmt = $pdo->prepare("UPDATE patient_recommendations SET recommendation = ? WHERE id = ? AND doctor_username = ?");
        $stmt->execute([$recommendation, $rec_id, $doctor_username]);
        
        if ($stmt->rowCount()) {
            redirect_with_patient_id($patient_id, 'recSuccess', 'Recommendation updated successfully.');
        } else {
            redirect_with_patient_id($patient_id, 'recError', 'Update failed or recommendation not found/owned.');
        }
    } else {
        $patient_id = $_POST['patient_id'] ?? 0; // Fallback patient ID
        redirect_with_patient_id($patient_id, 'recError', 'Invalid recommendation ID or empty recommendation.');
    }
}

// --- NEW: HANDLE DELETE RECOMMENDATION SUBMISSION ---
if (isset($_POST['delete_recommendation']) && isset($_POST['rec_id_to_delete'])) {
    $rec_id = $_POST['rec_id_to_delete'];
    $patient_id = $_POST['patient_id_to_delete']; // CRITICAL: Added patient_id retrieval here

    if (is_numeric($rec_id) && is_numeric($patient_id)) {
        $stmt = $pdo->prepare("DELETE FROM patient_recommendations WHERE id = ? AND doctor_username = ?");
        $stmt->execute([$rec_id, $doctor_username]);
        
        if ($stmt->rowCount()) {
            redirect_with_patient_id($patient_id, 'recSuccess', 'Recommendation deleted successfully.');
        } else {
            redirect_with_patient_id($patient_id, 'recError', 'Deletion failed or recommendation not found/owned.');
        }
    } else {
        $patient_id = $_POST['patient_id_to_delete'] ?? 0; // Fallback patient ID
        redirect_with_patient_id($patient_id, 'recError', 'Invalid recommendation ID for deletion.');
    }
}

// --- RETRIEVE MESSAGES FROM URL ---
$uploadSuccess = $_GET['uploadSuccess'] ?? '';
$uploadError = $_GET['uploadError'] ?? '';
$recSuccess = $_GET['recSuccess'] ?? '';
$recError = $_GET['recError'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Doctor Dashboard - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" />
<style>
html { scroll-behavior: smooth; }
body { margin: 0; font-family: 'Segoe UI', sans-serif; background: #f0f5ff; color: #003366; min-height: 100vh; display: flex; }

/* Sidebar */
.sidebar { width: 220px; background: linear-gradient(to bottom, #3399ff, #0066cc); padding: 20px; color: white; box-shadow: 2px 0 10px rgba(0,0,0,0.15); display: flex; flex-direction: column; }
.sidebar h2 { text-align: center; margin-bottom: 30px; font-size: 24px; font-weight: 700; user-select: none; text-shadow: 1px 1px 2px rgba(0,0,0,0.3); }
.sidebar a { display: block; padding: 12px 20px; margin: 10px 0; color: #cce0ff; text-decoration: none; border-left: 4px solid transparent; font-weight: 600; transition: background-color 0.3s ease, border-left-color 0.3s ease; border-radius: 4px; }
.sidebar a:hover, .sidebar a.active { background-color: rgba(255,255,255,0.2); color: white; border-left: 4px solid #ffcc00; }

/* Main content */
.main-content { flex: 1; padding: 40px; background: #ffffff; overflow-y: auto; border-left: 2px solid #cce0ff; }
header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
header h1 { font-size: 2rem; color: #004080; text-shadow: 1px 1px 2px #a3c2ff; display: flex; align-items: center; gap: 0.5rem; }

/* Search input */
#patientSearch { padding: 8px 12px; width: 300px; margin-bottom: 15px; border: 1px solid #cce0ff; border-radius: 5px; font-size: 1rem; }

/* Table styling */
.table { width: 100%; border-collapse: collapse; margin-top: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
.table th, .table td { padding: 12px; border: 1px solid #cce0ff; text-align: left; }
.table th { background: #3399ff; color: white; font-weight: 600; }
.table tr:nth-child(even) { background: #f0f5ff; }
.view-btn { cursor: pointer; background-color: #3399ff; color: white; font-weight: 600; border: none; padding: 6px 12px; border-radius: 5px; transition: background-color 0.3s ease; }
.view-btn:hover { background-color: #0066cc; }

/* Modal styling */
.modal { display: none; position: fixed; z-index: 9999; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4); backdrop-filter: blur(3px); }
.modal-content { background-color: #f7faff; margin: 5% auto; padding: 30px; border-radius: 12px; width: 90%; max-width: 900px; box-shadow: 0 5px 20px rgba(0,0,0,0.2); position: relative; }
.close-btn { color: #003366; position: absolute; top: 15px; right: 20px; font-size: 28px; font-weight: bold; cursor: pointer; }
.close-btn:hover { color: #ff0000; }

/* Patient details */
#patientDetails { display: grid; grid-template-columns: 1fr 1fr; gap: 15px 25px; margin-bottom: 20px; }
.patient-label { font-weight: 700; color: #004080; }
.patient-value { color: #003366; }

/* File list */
.file-list { margin-top: 15px; }
.file-item { margin-bottom: 8px; }

/* File upload zone */
.file-drop-zone {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 20px;
    border: 2px dashed #3399ff;
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-bottom: 10px;
    text-align: center;
    background: #f7faff;
}
.file-drop-zone:hover { background: #e6f0ff; border-color: #0066cc; }
.file-drop-zone input[type="file"] { display: none; }
#fileDropText { margin-top: 8px; font-weight: 600; color: #004080; }

/* Recommendation styles */
.recommendation-box { margin-top: 12px; padding: 12px; background: #eef6ff; border-radius: 8px; }
.recommendation-list .rec-item { margin-bottom: 10px; padding: 10px; background: #fff; border-radius: 8px; border: 1px solid #e6f0ff; }
.recommendation-list .rec-item .meta { color:#666; font-size:0.9rem; margin-bottom:6px; display: flex; justify-content: space-between; align-items: center;}
.rec-actions button { margin-left: 5px; padding: 4px 8px; border: none; border-radius: 4px; cursor: pointer; font-size: 0.85rem; font-weight: 600; transition: background-color 0.3s; }
.edit-rec-btn { background-color: #ffcc00; color: #003366; }
.edit-rec-btn:hover { background-color: #e6b800; }
.delete-rec-btn { background-color: #ff4d4d; color: white; }
.delete-rec-btn:hover { background-color: #cc0000; }

/* NEW: Edit Modal Styling */
#editRecModal { display: none; position: fixed; z-index: 10000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.6); backdrop-filter: blur(2px); }
#editRecModal .modal-content { margin: 15% auto; max-width: 500px; padding: 25px; }
</style>
</head>
<body>

<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="doctor_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="my_patients.php" class="active"><i class="fas fa-users"></i> My Patients</a>
    <a href="my_appointments.php"><i class="fas fa-calendar-check"></i> My Appointments</a>
    <a href="announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">
<header>
    <h1><i class="fas fa-user-md"></i> Doctor Dashboard</h1>
    <div>
        <?php if (!empty($uploadSuccess)) echo "<div style='color:green;margin-bottom:8px;'>$uploadSuccess</div>"; ?>
        <?php if (!empty($uploadError)) echo "<div style='color:red;margin-bottom:8px;'>$uploadError</div>"; ?>
        <?php if (!empty($recSuccess)) echo "<div style='color:green;margin-bottom:8px;'>$recSuccess</div>"; ?>
        <?php if (!empty($recError)) echo "<div style='color:red;margin-bottom:8px;'>$recError</div>"; ?>
    </div>
</header>

<h2>My Patients</h2>

<input type="text" id="patientSearch" placeholder="Search patients...">

<?php
if ($clinicDb) {
    try {
        $clinicPDO = new PDO(
            "mysql:host=localhost;dbname=$clinicDb;charset=utf8mb4",
            "root",
            "",
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]
        );

        $stmt = $clinicPDO->query("SELECT * FROM patient");
        $patients = $stmt->fetchAll();

        if ($patients) {
            echo "<table class='table' id='patientTable'>
                        <tr>
                            <th>ID</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Contact No.</th>
                            <th>DOB</th>
                            <th>Gender</th>
                            <th>Action</th>
                        </tr>";

            foreach ($patients as $p) {
                // Encode the patient ID separately for easy JavaScript access
                $patientData = htmlspecialchars(json_encode($p), ENT_QUOTES, 'UTF-8');
                echo "<tr data-patient-id='{$p['patient_id']}'>
                            <td>{$p['patient_id']}</td>
                            <td>{$p['fullname']}</td>
                            <td>{$p['email']}</td>
                            <td>{$p['contact_number']}</td>
                            <td>{$p['dob']}</td>
                            <td>{$p['gender']}</td>
                            <td><button class='view-btn' onclick='showPatient($patientData)'>View</button></td>
                          </tr>";
            }

            echo "</table>";
        } else {
            echo "<p>No patients found.</p>";
        }
    } catch (PDOException $e) {
        echo "<p>Error loading patients: " . $e->getMessage() . "</p>";
    }
}
?>

<div id="patientModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="closeModal('patientModal')">&times;</span>
        <div id="patientDetails"></div>

        <form method="POST" enctype="multipart/form-data" id="uploadForm">
            <input type="hidden" name="patient_id" id="modalPatientId">

            <label for="patientFile" class="file-drop-zone" id="fileDropZone">
                <i class="fas fa-upload" style="font-size: 28px; color: #3399ff;"></i>
                <p id="fileDropText">Choose a file or drag it here</p>
                <input type="file" name="patient_file" id="patientFile" required>
            </label>

            <button type="submit" name="upload_file" class="view-btn">Upload File</button>
        </form>

        <div class="file-list" id="fileList"></div>

        <hr>

        <div class="recommendation-box">
            <h3>Doctor Recommendation (New)</h3>
            <form method="POST" id="recForm">
                <input type="hidden" name="patient_id" id="recPatientId">
                <textarea name="recommendation" id="recommendation" required placeholder="Write your recommendation..." style="width:100%; height:100px; padding:10px; border:1px solid #cce0ff; border-radius:8px; resize:none;"></textarea>
                <div style="margin-top:10px;">
                    <button type="submit" name="save_recommendation" class="view-btn">Save Recommendation</button>
                </div>
            </form>
        </div>

        <hr>

        <h3>Previous Recommendations:</h3>
        <div id="recList" class="recommendation-list"></div>
    </div>
</div>

<div id="editRecModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="closeModal('editRecModal')">&times;</span>
        <h3>Edit Recommendation</h3>
        <form method="POST" id="editRecForm">
            <input type="hidden" name="rec_id" id="editRecId">
            <input type="hidden" name="patient_id" id="editRecPatientId">
            <textarea name="recommendation" id="editRecommendationText" required style="width:100%; height:150px; padding:10px; border:1px solid #cce0ff; border-radius:8px; resize:vertical;"></textarea>
            <div style="margin-top:10px; text-align: right;">
                <button type="button" class="view-btn" onclick="closeModal('editRecModal')" style="background-color: #999; margin-right: 10px;">Cancel</button>
                <button type="submit" name="edit_recommendation" class="view-btn">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<form id="deleteRecForm" method="POST" style="display:none;">
    <input type="hidden" name="delete_recommendation" value="1">
    <input type="hidden" name="rec_id_to_delete" id="recIdToDelete">
    <input type="hidden" name="patient_id_to_delete" id="patientIdToDelete">
</form>

<script>
const doctorUsername = "<?php echo $doctor_username; ?>"; // Get current doctor's username
const patientTable = document.getElementById('patientTable');

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function showEditModal(recId, recText, patientId) {
    document.getElementById('editRecId').value = recId;
    document.getElementById('editRecommendationText').value = recText;
    document.getElementById('editRecPatientId').value = patientId;
    document.getElementById('editRecModal').style.display = 'block';
}

function deleteRecommendation(recId, patientId) {
    if (confirm("Are you sure you want to delete this recommendation?")) {
        document.getElementById('recIdToDelete').value = recId;
        document.getElementById('patientIdToDelete').value = patientId; // Pass patient ID for redirect
        
        // Submit the hidden form
        document.getElementById('deleteRecForm').submit();
    }
}

function formatPatientDetails(patient) {
    let details = '';
    details += `<p><span class='patient-label'>Full Name:</span> <span class='patient-value'>${patient.fullname}</span></p>`;
    details += `<p><span class='patient-label'>Email:</span> <span class='patient-value'>${patient.email}</span></p>`;
    details += `<p><span class='patient-label'>Contact Number:</span> <span class='patient-value'>${patient.contact_number}</span></p>`;
    details += `<p><span class='patient-label'>DOB:</span> <span class='patient-value'>${patient.dob}</span></p>`;
    details += `<p><span class='patient-label'>Gender:</span> <span class='patient-value'>${patient.gender}</span></p>`;
    details += `<p><span class='patient-label'>Address:</span> <span class='patient-value'>${patient.address}</span></p>`;
    details += `<p><span class='patient-label'>Emergency Contact Name:</span> <span class='patient-value'>${patient.emergency_contact_name}</span></p>`;
    details += `<p><span class='patient-label'>Emergency Contact Number:</span> <span class='patient-value'>${patient.emergency_contact_number}</span></p>`;
    details += `<p><span class='patient-label'>Medical History:</span> <span class='patient-value'>${patient.medical_history}</span></p>`;
    details += `<p><span class='patient-label'>Allergies:</span> <span class='patient-value'>${patient.allergies}</span></p>`;
    details += `<p><span class='patient-label'>Notes:</span> <span class='patient-value'>${patient.notes}</span></p>`;
    details += `<p><span class='patient-label'>Outstanding Balance:</span> <span class='patient-value'>${patient.outstanding_balance}</span></p>`;
    document.getElementById('patientDetails').innerHTML = details;
}

// Function to populate the modal with patient data and open it
function showPatient(patient) {
    document.getElementById('modalPatientId').value = patient.patient_id;
    document.getElementById('recPatientId').value = patient.patient_id;
    document.getElementById('editRecPatientId').value = patient.patient_id;

    formatPatientDetails(patient); // Populate the details section

    // Fetch files via AJAX
    fetchFiles(patient.patient_id);
    
    // Fetch recommendations
    fetchRecommendations(patient.patient_id);

    document.getElementById('fileDropText').textContent = "Choose a file or drag it here";
    document.getElementById('patientModal').style.display = 'block';
}

function fetchFiles(patientId) {
    fetch(`fetch_patient_files.php?patient_id=${patientId}`)
        .then(res => res.json())
        .then(data => {
            let fileHtml = '<h3>Uploaded Files:</h3>';
            if (data.length > 0) {
                data.forEach(f => {
                    fileHtml += `
                        <div class="file-item">
                            <a href="${f.file_path}" target="_blank">${f.file_name}</a>
                            <span style="color:#555; font-size: 14px;"> — Uploaded: ${f.uploaded_at}</span>
                        </div>`;
                });
            } else {
                fileHtml += '<p>No files uploaded.</p>';
            }
            document.getElementById('fileList').innerHTML = fileHtml;
        });
}

function fetchRecommendations(patientId) {
    fetch(`fetch_recommendations.php?patient_id=${patientId}`)
        .then(res => res.json())
        .then(recs => {
            let recHtml = "";
            if (recs.length > 0) {
                recs.forEach(r => {
                    const isDoctorRec = r.doctor_username === doctorUsername;
                    const recTextEscaped = escapeHtml(r.recommendation);
                    // Double-escape single quotes for JS function call parameters
                    const recTextRaw = r.recommendation.replace(/'/g, "\\'").replace(/"/g, "&quot;"); 

                    recHtml += `
                        <div class="rec-item">
                            <div class="meta">
                                <span><strong>${r.doctor_username}</strong> — <span>${r.created_at}</span></span>
                                ${isDoctorRec ? `
                                    <span class="rec-actions">
                                        <button class="edit-rec-btn" onclick="showEditModal(${r.id}, '${recTextRaw}', ${patientId})">Edit</button>
                                        <button class="delete-rec-btn" onclick="deleteRecommendation(${r.id}, ${patientId})">Delete</button>
                                    </span>` : ''}
                            </div>
                            <div class="body">${recTextEscaped}</div>
                        </div>
                    `;
                });
            } else {
                recHtml = "<p>No recommendations yet.</p>";
            }
            document.getElementById('recList').innerHTML = recHtml;
        });
}


// --- NEW: FETCH PATIENT DATA AND REOPEN MODAL AFTER REDIRECT ---
function fetchPatientDetails(patientId) {
    const tableRow = patientTable.querySelector(`tr[data-patient-id='${patientId}']`);
    if (tableRow) {
        // Find the JSON data stored in the 'View' button of the row
        const viewButton = tableRow.querySelector('.view-btn');
        if (viewButton) {
            const viewButtonOnClick = viewButton.getAttribute('onclick');
            const match = viewButtonOnClick.match(/showPatient\((.*)\)/);
            if (match && match[1]) {
                const patientDataJson = match[1];
                try {
                    // Temporarily decode HTML entities before parsing JSON
                    const tempElement = document.createElement('textarea');
                    tempElement.innerHTML = patientDataJson;
                    const patient = JSON.parse(tempElement.value);
                    
                    showPatient(patient); // Reopen modal with fresh data
                } catch (e) {
                    console.error("Could not parse patient JSON data:", e);
                }
            }
        }
    } else {
        console.error(`Patient with ID ${patientId} not found in table.`);
    }
}

// Check for redirect parameter on page load
document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const refetchPatientId = urlParams.get('refetch_patient_id');

    if (refetchPatientId) {
        fetchPatientDetails(refetchPatientId);
    }
    
    // Clean up the URL to prevent double submission on refresh
    history.replaceState(null, null, window.location.pathname);
});


// Show selected file name
const patientFile = document.getElementById('patientFile');
const fileDropText = document.getElementById('fileDropText');

patientFile.addEventListener('change', function() {
    if (this.files && this.files.length > 0) {
        fileDropText.textContent = this.files[0].name;
    } else {
        fileDropText.textContent = "Choose a file or drag it here";
    }
});

// Search filter
document.getElementById('patientSearch').addEventListener('keyup', function() {
    let filter = this.value.toLowerCase();
    let table = document.querySelector('.table');
    if (!table) return;
    let trs = table.getElementsByTagName('tr');

    for (let i = 1; i < trs.length; i++) {
        let tds = trs[i].getElementsByTagName('td');
        let show = false;
        // Search in Full Name, Email, and Contact No. columns (indices 1, 2, 3)
        for (let j = 1; j <= 3; j++) { 
            if (tds[j] && tds[j].textContent.toLowerCase().includes(filter)) {
                show = true;
                break;
            }
        }
        trs[i].style.display = show ? '' : 'none';
    }
});

// small helper to avoid XSS when inserting recommendation text
function escapeHtml(text) {
    if (!text) return '';
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;")
        .replace(/\n/g, "<br/>");
}
</script>

</main>
</body>
</html>