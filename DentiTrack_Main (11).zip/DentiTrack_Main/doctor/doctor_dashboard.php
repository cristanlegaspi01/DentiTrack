<?php
session_start();

// 1. Authentication and Authorization Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'doctor') {
    header('Location: doctor_login.php');
    exit();
}

// 2. Database Connection Includes
// This file is assumed to define the global $pdo variable for the main DB.
require_once '../config/db_pdo.php'; 

$doctor_username = $_SESSION['username'] ?? '';

// 3. Initialize Variables
$patients_count = 0;
$upcoming_appointments = 0;
$treatments_count = 0;
$lowStock = []; // This will be populated below
$announcements_count = 0;
$error_message = ''; 

try {
    // === RE-ADDED LOW STOCK QUERY (Using the global $pdo connection) ===
    try {
        // Querying the single table: dental_supplies
        $stmt = $pdo->query("
            SELECT 
                name,
                low_stock_threshold,
                quantity AS total_quantity 
            FROM dental_supplies 
            WHERE quantity <= low_stock_threshold
        ");
        $lowStock = $stmt->fetchAll();
    } catch (Exception $e) {
        // Fallback for missing 'dental_supplies' table or incorrect columns
        error_log("Dental Supplies table error: " . $e->getMessage());
        $error_message = "Error checking supplies. Ensure 'dental_supplies' table exists with columns: name, low_stock_threshold, quantity.";
    }
    // ===================================================================

    // Announcements count (uses $pdo)
    $stmt = $pdo->query("SELECT COUNT(*) FROM announcements");
    $announcements_count = $stmt->fetchColumn();

} catch (PDOException $e) {
    // This catches errors for the main $pdo connection (if the announcements query fails)
    error_log("Database query error: " . $e->getMessage());
    // Only set the generic error if the supplies error hasn't already been set
    if (empty($error_message)) {
        $error_message = "A main database error occurred. Check logs for details.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Doctor Dashboard - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" />
<style>
    /* ... (Existing CSS remains unchanged, except for adding .low-stock-alert) */
    html { scroll-behavior: smooth; }
    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background: #e6f0ff;
        color: #003366;
        height: 100vh;
        display: flex;
    }
    .sidebar {
        width: 220px;
        background: linear-gradient(to bottom, #3399ff, #0066cc);
        padding: 20px;
        color: white;
        box-shadow: 2px 0 10px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
    }
    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        font-weight: 700;
        user-select: none;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }
    .sidebar a {
        display: block;
        padding: 12px 20px;
        margin: 10px 0;
        color: #cce0ff;
        text-decoration: none;
        border-left: 4px solid transparent;
        font-weight: 600;
        transition: background-color 0.3s ease, border-left-color 0.3s ease;
    }
    .sidebar a:hover,
    .sidebar a.active {
        background-color: rgba(255,255,255,0.15);
        color: white;
        border-left: 4px solid #ffcc00;
    }
    .main-content {
        flex: 1;
        padding: 40px;
        background: white;
        overflow-y: auto;
    }
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }
    header h1 {
        font-size: 2rem;
        color: #004080;
        text-shadow: 1px 1px 2px #a3c2ff;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .welcome {
        font-size: 1.3rem;
        margin-bottom: 2rem;
        font-weight: 600;
    }
    .widgets {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 30px;
    }
    .widget {
        background: #f0f7ff;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        text-align: left;
        cursor: pointer;
        transition: transform 0.3s ease, background-color 0.3s ease;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }
    .widget:hover {
        transform: translateY(-5px);
        background-color: #d9e8ff;
    }
    .widget i {
        font-size: 36px;
        color: #004080;
        margin-bottom: 10px;
    }
    .widget .title {
        font-size: 18px;
        font-weight: 700;
        color: #003366;
    }
    .widget .value {
        font-size: 40px;
        font-weight: 900;
        color: #004080;
    }
    .widget .subtitle {
        font-size: 14px;
        color: #666;
        font-weight: 500;
    }
    /* === NEW CSS FOR LOW STOCK ALERT === */
    .low-stock-alert {
        margin-top: 40px;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        border: 2px solid #cc0000; /* Darker border for impact */
        background: #fffafa; /* Very light red background */
    }
    .low-stock-alert h2 {
        margin: 0 0 15px 0;
        color: #cc0000;
        font-size: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
        border-bottom: 1px dashed #ffb3b3;
        padding-bottom: 10px;
    }
    .low-stock-alert ul {
        list-style: none; /* Remove default bullets */
        padding: 0;
        margin: 0;
    }
    .low-stock-alert li {
        margin-bottom: 15px;
        padding: 10px;
        border-left: 5px solid #ff4d4d; /* Highlighting bar */
        background: #ffebeb; /* Lighter background for the list item */
        font-size: 16px;
        color: #333;
        font-weight: 500;
    }
    .low-stock-alert li strong {
        color: #cc0000;
        font-weight: 700;
        font-size: 1.1em;
    }
    .low-stock-alert p.success {
        color: #008000;
        font-weight: 600;
        text-align: center;
    }
    /* =================================== */
</style>
</head>
<body>
    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="doctor_dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a>
        <a href="my_patients.php"><i class="fas fa-users"></i> My Patients</a>
        <a href="my_appointments.php"><i class="fas fa-calendar-check"></i> My Appointments</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>

    <main class="main-content">
        <header>
            <h1><i class="fas fa-user-md"></i> Doctor Dashboard</h1>
        </header>
        
        <?php if (isset($error_message) && $error_message): ?>
            <p style="color: red; font-weight: bold; padding: 10px; border: 1px solid red; background: #ffebeb; border-radius: 5px;">
                <i class="fas fa-exclamation-triangle"></i> <?= $error_message ?>
            </p>
        <?php endif; ?>

        <p class="welcome">Welcome, <strong><?= htmlspecialchars($doctor_username) ?></strong>!</p>

        <div class="widgets">
            <div class="widget" onclick="location.href='my_patients.php'">
                <i class="fas fa-users"></i>
                <div class="title">My Patients</div>
                <div class="value"><?= $patients_count ?></div>
                <div class="subtitle">Click to view the patient list</div>
            </div>

            <div class="widget" onclick="location.href='my_appointments.php'">
                <i class="fas fa-calendar-check"></i>
                <div class="title">Upcoming Appointments</div>
                <div class="value"><?= $upcoming_appointments ?></div>
                <div class="subtitle">Your scheduled appointments</div>
            </div>

            <div class="widget" onclick="location.href='announcements.php'">
                <i class="fas fa-bullhorn"></i>
                <div class="title">Announcements</div>
                <div class="value"><?= $announcements_count ?></div>
                <div class="subtitle">Clinic updates and news</div>
            </div>
        </div>

        <div class="low-stock-alert">
            <h2>
                <i class="fas fa-exclamation-triangle"></i>
                Low Stock Supplies 
            </h2>

            <?php if (!empty($lowStock)): ?>
                <ul>
                    <?php foreach ($lowStock as $item): ?>
                        <li>
                            The supply <?= htmlspecialchars($item['name']) ?> is very low.
                            <br/>
                            Quantity: <span style="font-style:italic;"><?= $item['total_quantity'] ?></span> (Threshold: <?= $item['low_stock_threshold'] ?>).
                            Restock Immediately!
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="success">
                    <i class="fas fa-check-circle"></i> All checked dental supplies are currently well-stocked.
                </p>
            <?php endif; ?>
        </div>
        <?php include '../doctor/announcements.php'; ?>
    </main>
</body>
</html>