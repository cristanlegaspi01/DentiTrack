<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'doctor') {
    header('Location: doctor_login.php');
    exit();
}

require_once '../config/db_pdo.php'; // main DB PDO = $pdo

$doctor_username = $_SESSION['username'] ?? '';
$clinicDb = $_SESSION['clinic_db'] ?? ''; 

// Initialize counts
$patients_count = 0;
$upcoming_appointments = 0;
$announcements_count = 0;
$treatments_count = 0;

try {
    if ($clinicDb) {
        // Connect to clinic-specific DB
        $clinicPDO = new PDO("mysql:host=localhost;dbname=$clinicDb;charset=utf8mb4", "root", "", [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        // Count patients assigned to this doctor
        $stmt = $clinicPDO->prepare("SELECT COUNT(*) FROM patients WHERE assigned_doctor = :doctor_username");
        $stmt->execute(['doctor_username' => $doctor_username]);
        $patients_count = $stmt->fetchColumn();

        // Count upcoming appointments
        $stmt = $clinicPDO->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_username = :doctor_username AND appointment_date >= CURDATE()");
        $stmt->execute(['doctor_username' => $doctor_username]);
        $upcoming_appointments = $stmt->fetchColumn();

        // Count treatments
        $stmt = $clinicPDO->prepare("SELECT COUNT(*) FROM treatments WHERE doctor_username = :doctor_username");
        $stmt->execute(['doctor_username' => $doctor_username]);
        $treatments_count = $stmt->fetchColumn();
    }

    // Announcements are global from main DB
    $stmt = $pdo->query("SELECT COUNT(*) FROM announcements");
    $announcements_count = $stmt->fetchColumn();

} catch (PDOException $e) {
    error_log("Database query error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Doctor Dashboard - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" />
<style>
    /* ✅ Keeping your existing design */
    html {
        scroll-behavior: smooth;
    }
    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background: #e6f0ff;
        color: #003366;
        height: 100vh;
        display: flex;
    }
    .sidebar {
        width: 220px;
        background: linear-gradient(to bottom, #3399ff, #0066cc);
        padding: 20px;
        color: white;
        box-shadow: 2px 0 10px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
    }
    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        font-weight: 700;
        user-select: none;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }
    .sidebar a {
        display: block;
        padding: 12px 20px;
        margin: 10px 0;
        color: #cce0ff;
        text-decoration: none;
        border-left: 4px solid transparent;
        font-weight: 600;
        transition: background-color 0.3s ease, border-left-color 0.3s ease;
    }
    .sidebar a:hover,
    .sidebar a.active {
        background-color: rgba(255,255,255,0.15);
        color: white;
        border-left: 4px solid #ffcc00;
    }
    .main-content {
        flex: 1;
        padding: 40px;
        background: white;
        overflow-y: auto;
    }
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }
    header h1 {
        font-size: 2rem;
        color: #004080;
        text-shadow: 1px 1px 2px #a3c2ff;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .welcome {
        font-size: 1.3rem;
        margin-bottom: 2rem;
        font-weight: 600;
    }
    .widgets {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 30px;
    }
    .widget {
        background: #f0f7ff;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        text-align: left;
        cursor: pointer;
        transition: transform 0.3s ease, background-color 0.3s ease;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }
    .widget:hover {
        transform: translateY(-5px);
        background-color: #d9e8ff;
    }
    .widget i {
        font-size: 36px;
        color: #004080;
        margin-bottom: 10px;
    }
    .widget .title {
        font-size: 18px;
        font-weight: 700;
        color: #003366;
    }
    .widget .value {
        font-size: 40px;
        font-weight: 900;
        color: #004080;
    }
    .widget .subtitle {
        font-size: 14px;
        color: #666;
        font-weight: 500;
    }
</style>
</head>
<body>
    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="doctor_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="my_patients.php"><i class="fas fa-users"></i> My Patients</a>
        <a href="my_appointments.php" class="active"><i class="fas fa-calendar-check"></i> My Appointments</a>
        <a href="announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>

    <main class="main-content">
        <header>
            <h1><i class="fas fa-user-md"></i> Doctor Dashboard</h1>
        </header>

        <?php include '../calendar_function/doctor_calendar.php'; ?>

        
    </main>
</body>
</html>
