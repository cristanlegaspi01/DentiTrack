<?php
// IMPORTANT: Replace 'YOUR_API_KEY_HERE' with your actual Google AI Studio API key.
// Do NOT commit this key to any public repository.
define('GEMINI_API_KEY', 'AIzaSyDg-0ROG6qyOUgdS6U_Jddloj6eeUAEIXc'); 
?>